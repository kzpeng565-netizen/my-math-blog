const state={data:null,minutes:40,page:'focus',timer:null,selectedReward:null,selectedSpecies:null,plantMode:'basic',period:'all',catalogTier:'basic',systemStatus:null,recentContext:{notes:null,revision:0,editingId:null},taskCalendar:{data:null,mode:'week',selectedDate:null,activeContext:[]},nextAction:{active:null,pendingGeneration:false,pendingResponse:null,reportPath:null,generation:null,generationTimer:null,generationPolling:false,generationPollAt:0}};
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const titles={focus:'开始专注','next-action':'下一步行动','recent-context':'近期动态',tasks:'任务清单',garden:'我的花园',rewards:'奖励记录',catalog:'植物图鉴',settings:'系统状态'};
const typeMeta={intervention_accepted:['介','主动接受系统介入'],intervention_basic:['介','介入累计初级奖励'],steam_night_closed:['关','主动关闭 Steam'],advanced_unlock:['高','初级植物累计高级奖励'],daily_full_tomato_advanced:['✓','每日番茄全完成'],ai_help_completed:['AI','AI 建议完成闭环'],early_sleep:['眠','早睡估计达标'],focus_completed:['专','完成专注奖励']};
async function api(path,options={}){const res=await fetch(path,{cache:options.cache||'no-store',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});const text=await res.text();if(!text)throw new Error(`接口 ${path} 返回空响应`);let data;try{data=JSON.parse(text)}catch{throw new Error(`接口 ${path} 返回了非 JSON 数据`)}if(!res.ok){const error=new Error(data.error||`请求失败 (${res.status})`);error.payload=data;error.status=res.status;throw error}return data}
function toast(message,bad=false){const el=$('#toast');el.textContent=message;el.style.background=bad?'#8f3f39':'';el.classList.add('show');clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove('show'),3000)}
function formatTime(value){if(!value)return'—';try{return new Intl.DateTimeFormat('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(value))}catch{return value}}
function catalogMap(){return Object.fromEntries(state.data.catalog.map(x=>[x.id,x]))}
function navigate(page){state.page=page;$$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.page===page));$$('.page').forEach(x=>x.classList.toggle('active',x.id===`page-${page}`));$('#pageTitle').textContent=titles[page];$('#sidebar').classList.remove('open');$('#taskRefresh').classList.toggle('hidden',page!=='tasks');if(page==='garden')return renderGarden();if(page==='next-action')return loadNextActionPanel();if(page==='recent-context')return loadRecentContext();if(page==='tasks')return loadTasks();if(page==='settings')return loadSystemStatus();}
function rewardMeta(type){return typeMeta[type]||['奖',type]}
function render(){const d=state.data,stats=d.stats;$('#focusMinutes').textContent=stats.focus_minutes;$('#plantCount').textContent=stats.planted;$('#pendingCount').textContent=d.pending_rewards.length;$('#creditText').textContent=`${stats.focus_credit_minutes} / 40`;$('#creditBar').style.width=`${stats.focus_credit_minutes/40*100}%`;$('#sleepCutoff').textContent=d.settings.early_sleep_cutoff;$('#coldTurkeyMode').textContent=d.settings.cold_turkey_mode==='live'?'正式锁定':'安全模拟';renderProfiles();renderFocusPresets();renderFocus();renderFocusPlans();renderBridgeHealth();renderLatest();renderUsageFrequency();renderRewards();renderGarden();renderPlantingDock();renderCatalog();renderCounts()}
function renderFocusPresets(){const allowed=state.data.settings.allowed_focus_minutes||[5,20,30,40,45,60];if(!allowed.includes(state.minutes))state.minutes=allowed.includes(40)?40:allowed[0];const row=$('#presetRow');row.innerHTML=allowed.map(value=>`<button data-minutes="${value}" class="${value===state.minutes?'selected':''}">${value}</button>`).join('');$$('#presetRow button').forEach(button=>button.onclick=()=>{$$('#presetRow button').forEach(item=>item.classList.remove('selected'));button.classList.add('selected');state.minutes=Number(button.dataset.minutes);updateIdleTimer()})}
function renderProfiles(){const select=$('#profileSelect'),current=select.value;select.innerHTML=state.data.profiles.map(p=>`<option value="${p.id}">${p.name} · ${p.description}</option>`).join('');if(current)select.value=current}
function renderFocus(){clearInterval(state.timer);const focus=state.data.focus;const locked=Boolean(focus);$('#startBtn').classList.toggle('hidden',locked);$$('#presetRow button').forEach(b=>b.disabled=locked);$('#profileSelect').disabled=locked;if(!focus){$('#focusKicker').textContent='准备好种下一段专注了吗？';updateIdleTimer();return}$('#focusKicker').textContent=focus.task_title?`正在为「${focus.task_title}」安静生长。`:'专注正在生长，保持这一小片安静。';const tick=()=>{const seconds=Math.max(0,Math.ceil((new Date(focus.ends_at)-Date.now())/1000));$('#timerDisplay').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;if(seconds<=0){clearInterval(state.timer);setTimeout(load,2200)}};tick();state.timer=setInterval(tick,1000)}
function updateIdleTimer(){const m=state.minutes;$('#timerDisplay').textContent=`${String(m).padStart(2,'0')}:00`}
function renderFocusPlans(){const plans=state.data.focus_plans||[];$('#focusPlans').innerHTML=plans.length?plans.map(p=>{const phase=p.status==='break'?'休息中':p.status==='focus'?'第 '+p.current_round+' 轮专注中':'等待开始';const at=formatTime(p.next_action_at);return `<p>${p.kind==='cycle'?'连续':'预约'}：${p.focus_minutes} 分钟 × ${p.rounds} 轮 · ${phase} · ${at}</p>`}).join(''):'<p>没有待执行的预约或连续专注。</p>'}
function renderBridgeHealth(){const h=state.data.focus_bridge||{};if(h.state!=='stale'&&h.state!=='never')return;const key=`focus-bridge-notice-${h.last_seen_at||'never'}`;if(sessionStorage.getItem(key))return;sessionStorage.setItem(key,'1');toast(h.state==='never'?'手机 Focus Bridge 尚未建立心跳。请打开 App 并确认无障碍服务已启用。':'手机 Focus Bridge 心跳已暂停；下次手机解锁后打开 App 或重启无障碍服务。',true)}
function healthTone(value){return['active','ok','online','pass','qualified'].includes(value)?'ok':['inactive','failed','fail','stale','missing','never','degraded'].includes(value)?'bad':'warn'}
function healthAge(seconds){if(seconds===null||seconds===undefined)return'暂无时间';if(seconds<60)return'刚刚更新';if(seconds<3600)return`${Math.floor(seconds/60)} 分钟前`;return`${Math.floor(seconds/3600)} 小时前`}
function healthRow(label,value,detail=''){return`<div class="health-row"><i class="health-dot ${healthTone(value)}"></i><b>${escapeHtml(label)} · ${escapeHtml(value||'unknown')}</b><small>${escapeHtml(detail)}</small></div>`}
function renderSystemStatus(){const board=$('#systemStatusBoard'),summary=$('#systemStatusSummary'),s=state.systemStatus;if(!s){board.innerHTML='<article class="pixel-panel health-card wide"><p class="health-empty">等待健康数据…</p></article>';return}const services=(s.services||[]).map(x=>healthRow(x.name,x.state)).join('');const t=s.tasks||{},d=s.data||{},b=s.bridges||{};const taskRows=[healthRow('网页任务 queue',t.pending_mutation_count===0?'ok':`${t.pending_mutation_count} 条待写回`,t.revision===undefined?'未读取 revision':`revision ${t.revision}`),healthRow('Obsidian 快照',t.snapshot?.state,healthAge(t.snapshot?.age_seconds)),healthRow('同步检查',t.sync_heartbeat?.state,healthAge(t.sync_heartbeat?.age_seconds))].join('');const bridgeRows=[healthRow('Windows 介入 agent',b.windows?.state,healthAge(b.windows?.age_seconds)),healthRow('Android Focus Bridge',b.android?.state,healthAge(b.android?.age_seconds))].join('');const dataRows=[healthRow('行为上下文缓存',d.context_cache?.state,healthAge(d.context_cache?.age_seconds)),healthRow('最近半小时报告',d.latest_report?.state,healthAge(d.latest_report?.age_seconds)),healthRow('花园 SQLite 备份',d.archive_backup?.state,healthAge(d.archive_backup?.age_seconds))].join('');summary.textContent=`最后检查：${formatTime(s.generated_at)}。绿色表示正在运行或数据新鲜；红色表示陈旧、缺失或服务停止。`;board.innerHTML=`<article class="pixel-panel health-card wide"><p class="eyebrow">PI SERVICES</p><h3>Pi 核心服务</h3><div class="health-list">${services||'<p class="health-empty">未返回服务数据。</p>'}</div></article><article class="pixel-panel health-card"><p class="eyebrow">TASK SYNC</p><h3>任务与 Obsidian</h3><div class="health-list">${taskRows}</div></article><article class="pixel-panel health-card"><p class="eyebrow">DEVICE BRIDGES</p><h3>设备链路</h3><div class="health-list">${bridgeRows}</div></article><article class="pixel-panel health-card wide"><p class="eyebrow">DATA & RECOVERY</p><h3>数据与恢复</h3><div class="health-list">${dataRows}</div></article>`}
function renderSystemStatus(){const board=$('#systemStatusBoard'),summary=$('#systemStatusSummary'),s=state.systemStatus;if(!s){board.innerHTML='<article class="pixel-panel health-card wide"><p class="health-empty">等待健康数据…</p></article>';return}const services=(s.services||[]).map(x=>healthRow(x.name,x.state)).join('');const t=s.tasks||{},d=s.data||{},b=s.bridges||{},android=b.android||{},q=android.qualification||{};const taskRows=[healthRow('网页任务 queue',t.pending_mutation_count===0?'ok':`${t.pending_mutation_count} 条待写回`,t.revision===undefined?'未读取 revision':`revision ${t.revision}`),healthRow('Obsidian 快照',t.snapshot?.state,healthAge(t.snapshot?.age_seconds)),healthRow('同步检查',t.sync_heartbeat?.state,healthAge(t.sync_heartbeat?.age_seconds))].join('');const bridgeRows=[healthRow('Windows 介入 agent',b.windows?.state,healthAge(b.windows?.age_seconds)),healthRow('Android Focus Bridge',android.state,`${healthAge(android.age_seconds)}${q.app_version?' · v'+q.app_version:''}`)].join('');const qualificationRows=(q.checks||[]).map(check=>healthRow(check.label,check.state,check.detail)).join('');const dataRows=[healthRow('行为上下文缓存',d.context_cache?.state,healthAge(d.context_cache?.age_seconds)),healthRow('最近半小时报告',d.latest_report?.state,healthAge(d.latest_report?.age_seconds)),healthRow('花园 SQLite 备份',d.archive_backup?.state,healthAge(d.archive_backup?.age_seconds))].join('');summary.textContent=`最后检查：${formatTime(s.generated_at)}。绿色表示正在运行或数据新鲜；红色表示陈旧、缺失或服务停止。`;board.innerHTML=`<article class="pixel-panel health-card wide"><p class="eyebrow">PI SERVICES</p><h3>Pi 核心服务</h3><div class="health-list">${services||'<p class="health-empty">未返回服务数据。</p>'}</div></article><article class="pixel-panel health-card"><p class="eyebrow">TASK SYNC</p><h3>任务与 Obsidian</h3><div class="health-list">${taskRows}</div></article><article class="pixel-panel health-card"><p class="eyebrow">DEVICE BRIDGES</p><h3>设备链路</h3><div class="health-list">${bridgeRows}</div></article><article class="pixel-panel health-card wide"><p class="eyebrow">ANDROID BRIDGE ACCEPTANCE</p><h3>Focus Bridge 验收 · ${escapeHtml(q.label||'尚未验收')}</h3><p class="setting-help">${escapeHtml(q.summary||'等待新版状态协议。')}</p><div class="health-list">${qualificationRows||'<p class="health-empty">安装并启动 Focus Bridge 1.1.0 后开始累计验收证据。</p>'}</div></article><article class="pixel-panel health-card wide"><p class="eyebrow">DATA & RECOVERY</p><h3>数据与恢复</h3><div class="health-list">${dataRows}</div></article>`}
async function loadSystemStatus(){const summary=$('#systemStatusSummary');summary.textContent='正在检查 Pi 服务与数据新鲜度…';try{state.systemStatus=await api('/api/system-status');renderSystemStatus()}catch(error){state.systemStatus=null;renderSystemStatus();summary.textContent=`无法读取系统状态：${error.message}`;toast('系统状态读取失败',true)}}
function renderLatest(){const list=state.data.reward_history.slice(0,4);$('#latestRewards').innerHTML=list.length?list.map(r=>{const m=rewardMeta(r.type);return`<div class="mini-item"><span class="mini-icon">${m[0]}</span><div><p>${m[1]}</p><small>${formatTime(r.occurred_at)}</small></div></div>`}).join(''):'<p class="setting-help">同步后，奖励会出现在这里。</p>'}
function signedDelta(value,unit=''){const n=Number(value)||0;return `${n>0?'+':''}${n}${unit}`}
function renderUsageFrequency(){const data=state.data.usage_frequency||{},rows=[...(data.days||[]).map(day=>[day.label,'较上周同日',day]),['本周','较上周同期',data.this_week||{}]];const card=([label,comparison,period])=>{const current=period.current||{},previous=period.last_week_same_period||{};const delta={minutes:(current.focus_minutes||0)-(previous.focus_minutes||0),completed:(current.completed_suggestions||0)-(previous.completed_suggestions||0),accepted:(current.accepted_suggestions||0)-(previous.accepted_suggestions||0),asked:(current.asked_suggestions||0)-(previous.asked_suggestions||0)};return`<section class="frequency-period"><div class="frequency-title"><b>${label}</b><small>${comparison}</small></div><div class="frequency-metrics"><span><strong>${current.focus_minutes||0}</strong> 分钟</span><span><strong>${current.completed_suggestions||0}</strong> 完成</span><span><strong>${current.accepted_suggestions||0}</strong> 采纳</span><span><strong>${current.asked_suggestions||0}</strong> 询问</span></div><p>专注 ${signedDelta(delta.minutes,'分')} · 完成 ${signedDelta(delta.completed)} · 采纳 ${signedDelta(delta.accepted)} · 询问 ${signedDelta(delta.asked)}</p></section>`};$('#usageFrequency').innerHTML=rows.map(card).join('')}
function basicOpportunities(){return state.data.pending_rewards.filter(reward=>(reward.tier||'basic')==='basic')}
function directAdvancedOpportunities(){return state.data.pending_rewards.filter(reward=>reward.tier==='advanced')}
function renderPlantingDock(){const basic=basicOpportunities().length,direct=directAdvancedOpportunities().length,exchange=Math.floor(basic/3),advanced=direct+exchange;$('#basicPlantOpportunityCount').textContent=basic;$('#advancedPlantOpportunityCount').textContent=advanced;$('#plantBasicMenu').disabled=basic===0;$('#plantAdvancedMenu').disabled=advanced===0;$('#plantingDockHint').textContent=direct?`每日挑战奖励：可直接种植 ${direct} 株高级植物；另有 ${basic} 次初级机会。`:exchange?`已有 ${basic} 次初级机会；现在可消耗 3 次种植 1 株高级植物。`:`已积攒 ${basic} 次初级机会；再积攒 ${Math.max(0,3-basic)} 次即可兑换高级植物。`}
function renderCounts(){const s=state.data.stats;$('#interventionProgress').textContent=`${s.intervention_progress||0} / 3`;$('#basicProgress').textContent=s.basic_available||0;$('#advancedAvailable').textContent=s.advanced_available||0;$('#tierPlantCount').textContent=`${s.basic_planted||0} / ${s.advanced_planted||0}`}
function renderRewards(){const list=state.data.reward_history;$('#rewardList').innerHTML=list.length?list.map(r=>{const m=rewardMeta(r.type),tier=r.tier==='advanced'?'高级':'初级';return`<div class="reward-row"><span class="reward-icon">${m[0]}</span><div><h3>${m[1]}</h3><p>${escapeHtml(r.reason)} · ${tier}植物资格</p></div><time>${formatTime(r.occurred_at)}</time>${r.status==='pending'?`<button class="plant-action" data-plant="${encodeURIComponent(r.id)}">领取${tier}植物</button>`:'<span class="planted-badge">✓ 已种植</span>'}</div>`}).join(''):'<div class="garden-empty"><h3>暂无可领取奖励</h3><p>主动接受 3 次介入后，会出现初级植物资格。</p></div>';$$('[data-plant]').forEach(b=>b.onclick=()=>openPlant(decodeURIComponent(b.dataset.plant)))}
function inPeriod(date,period){if(period==='all')return true;const d=new Date(date),now=new Date();if(period==='day')return d.toDateString()===now.toDateString();if(period==='year')return d.getFullYear()===now.getFullYear();if(period==='month')return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth();if(period==='week'){const a=new Date(now);a.setHours(0,0,0,0);a.setDate(a.getDate()-((a.getDay()+6)%7));return d>=a}return true}
function renderGarden(){if(!state.data)return;const garden=state.data.garden,map=catalogMap(),plants=garden.plants.filter(p=>inPeriod(p.planted_at,state.period));const size=garden.size,r=size/2;$('#gardenSizeLabel').textContent=`${size} × ${size}`;$('#gardenPeriodLabel').textContent=({all:'全部种植记录',day:'今天',week:'本周',month:'本月',year:'今年'})[state.period];const byPos=Object.fromEntries(plants.map(p=>[`${p.x},${p.y}`,p]));let html='';for(let y=-Math.floor(r);y<=Math.floor(r);y++)for(let x=-Math.floor(r);x<=Math.floor(r);x++){const p=byPos[`${x},${y}`],species=p&&map[p.species_id];html+=`<div class="garden-tile">${p&&species?`<img src="/${species.sprite}" alt="${species.name}"><div class="tip"><b>${species.name}</b><br>${escapeHtml(p.reason)}<br>${formatTime(p.planted_at)}</div>`:''}</div>`}const grid=$('#gardenGrid');grid.style.gridTemplateColumns=`repeat(${size},1fr)`;grid.innerHTML=html;grid.classList.toggle('hidden',plants.length===0);$('#gardenEmpty').classList.toggle('hidden',plants.length!==0)}
function renderCatalog(){const names={flower:'花',tree:'树苗',mushroom:'蘑菇',decoration:'装饰'},tiers={basic:'初级',advanced:'高级'},tier=p=>p.tier==='advanced'?'advanced':'basic',selected=state.catalogTier==='advanced'?'advanced':'basic',basicCount=state.data.catalog.filter(p=>tier(p)==='basic').length,advancedCount=state.data.catalog.filter(p=>tier(p)==='advanced').length;$('#catalogTierTabs').innerHTML=`<button type="button" data-catalog-tier="basic" class="${selected==='basic'?'active':''}" role="tab" aria-selected="${selected==='basic'}">初级 <span>${basicCount}</span></button><button type="button" data-catalog-tier="advanced" class="${selected==='advanced'?'active':''}" role="tab" aria-selected="${selected==='advanced'}">高级 <span>${advancedCount}</span></button>`;$$('[data-catalog-tier]').forEach(button=>button.onclick=()=>{state.catalogTier=button.dataset.catalogTier;renderCatalog()});$('#catalogGrid').innerHTML=state.data.catalog.filter(p=>tier(p)===selected).map(p=>`<div class="catalog-card"><div class="sprite-box"><img src="/${p.sprite}" alt="${p.name}"></div><h3>${p.name}</h3><small>${tiers[tier(p)]} · ${names[p.category]||p.category} · ${p.id}</small></div>`).join('')}
function ensureGardenIsland(){const grid=$('#gardenGrid');let island=$('#gardenIsland');if(island)return island;island=document.createElement('div');island.id='gardenIsland';island.className='garden-island';grid.parentNode.insertBefore(island,grid);for(const cls of ['island-shadow','island-face island-face-left','island-face island-face-right']){const el=document.createElement('div');el.className=cls;island.appendChild(el)}grid.className='garden-top';island.appendChild(grid);const layer=document.createElement('div');layer.id='gardenPlants';layer.className='garden-plants';island.appendChild(layer);return island}
function renderGarden(){if(!state.data)return;const garden=state.data.garden,map=catalogMap(),plants=garden.plants.filter(p=>inPeriod(p.planted_at,state.period));const size=garden.size,offset=Math.floor(size/2),island=ensureGardenIsland();island.style.setProperty('--garden-size',size);$('#gardenSizeLabel').textContent=`${size} × ${size}`;$('#gardenPeriodLabel').textContent=({all:'全部种植记录',day:'今天',week:'本周',month:'本月',year:'今年'})[state.period];let tiles='';for(let row=0;row<size;row++)for(let col=0;col<size;col++){const left=50+(col-row-1)*50/size,top=(col+row)*50/size,unit=100/size;tiles+=`<div class="garden-tile" style="left:${left}%;top:${top}%;width:${unit}%;height:${unit}%"></div>`}$('#gardenGrid').innerHTML=tiles;$('#gardenPlants').innerHTML=plants.map(p=>{const species=map[p.species_id];if(!species)return'';const col=p.x+offset,row=p.y+offset,left=50+(col-row)*50/size,top=((col+row+1)*50/size)*.8065,z=100+col+row;return`<div class="garden-plant" style="left:${left}%;top:${top}%;z-index:${z}"><span class="plant-shadow"></span><img class="sprite-depth" src="/${species.sprite}" alt=""><img class="sprite-front" src="/${species.sprite}" alt="${escapeHtml(species.name)}"><div class="tip"><b>${escapeHtml(species.name)}</b><br>${escapeHtml(p.reason)}<br>${formatTime(p.planted_at)}</div></div>`}).join('');island.classList.toggle('is-empty',plants.length===0);$('#gardenEmpty').classList.toggle('hidden',plants.length!==0)}
function renderCubeGarden(){if(!state.data)return;const garden=state.data.garden,map=catalogMap(),plants=garden.plants.filter(p=>inPeriod(p.planted_at,state.period));const size=garden.size,offset=Math.floor(size/2),island=ensureGardenIsland(),logicalWidth=268*size+32,logicalHeight=134*size+164;island.classList.add('user-cube-garden');island.style.setProperty('--garden-size',size);island.style.aspectRatio=`${logicalWidth} / ${logicalHeight}`;$('#gardenSizeLabel').textContent=`${size} × ${size}`;$('#gardenPeriodLabel').textContent=({all:'全部种植记录',day:'今天',week:'本周',month:'本月',year:'今年'})[state.period];const byPos=Object.fromEntries(plants.map(p=>[`${p.x},${p.y}`,p]));let cells='';for(let row=0;row<size;row++)for(let col=0;col<size;col++){const left=134*(size-1+col-row)/logicalWidth*100,top=67*(col+row)/logicalHeight*100,width=300/logicalWidth*100,height=300/logicalHeight*100,p=byPos[`${col-offset},${row-offset}`],species=p&&map[p.species_id],plant=p&&species?`<div class="garden-plant" style="left:50%;top:22.34%"><span class="plant-shadow"></span><img class="sprite-depth" src="/${species.sprite}" alt=""><img class="sprite-front" src="/${species.sprite}" alt="${escapeHtml(species.name)}"><div class="tip"><b>${escapeHtml(species.name)}</b><br>${escapeHtml(p.reason)}<br>${formatTime(p.planted_at)}</div></div>`:'';cells+=`<div class="garden-cube-cell" style="left:${left}%;top:${top}%;width:${width}%;height:${height}%;z-index:${100+col+row}"><img class="garden-cube" src="/assets/blocks/grass_cube_user.png" alt="" aria-hidden="true">${plant}</div>`}$('#gardenGrid').innerHTML=cells;$('#gardenPlants').innerHTML='';island.classList.toggle('is-empty',plants.length===0);$('#gardenEmpty').classList.toggle('hidden',plants.length!==0)}
renderGarden=renderCubeGarden;
function ensurePlantCategoryTabs(){let tabs=$('#plantCategoryTabs');if(tabs)return tabs;tabs=document.createElement('div');tabs.id='plantCategoryTabs';tabs.className='plant-category-tabs';$('#plantPicker').before(tabs);return tabs}
function renderPlantCategory(tier){state.plantCategory=tier;state.selectedSpecies=null;$('#plantConfirm').disabled=true;const plantTier=p=>p.tier==='advanced'?'advanced':'basic',items=state.data.catalog.filter(p=>plantTier(p)===tier),label=tier==='advanced'?'高级':'初级',tabs=ensurePlantCategoryTabs();tabs.innerHTML=`<span class="plant-tier-lock">本次仅可领取${label}植物</span>`;$('#plantPicker').innerHTML=items.map(p=>`<button class="plant-option" data-species="${p.id}"><img src="/${p.sprite}" alt=""><span>${p.name}</span></button>`).join('');$$('[data-species]').forEach(button=>button.onclick=()=>{state.selectedSpecies=button.dataset.species;$$('[data-species]').forEach(item=>item.classList.toggle('selected',item===button));$('#plantConfirm').disabled=false})}
function openPlantTabbed(id){const reward=state.data.reward_history.find(r=>r.id===id);if(!reward)return;const tier=reward.tier==='advanced'?'advanced':'basic';state.plantMode='basic';state.selectedReward=id;state.selectedSpecies=null;$('#modalReason').textContent=`${reward.reason}（本次领取${tier==='advanced'?'高级':'初级'}植物）`;renderPlantCategory(tier);$('#plantModal').classList.remove('hidden')}
function openBasicPlanting(){const reward=basicOpportunities()[0];if(!reward){toast('暂时没有初级种植机会',true);return}openPlantTabbed(reward.id)}
function openAdvancedPlanting(){const direct=directAdvancedOpportunities()[0];if(direct){openPlantTabbed(direct.id);return}if(basicOpportunities().length<3){toast('暂时没有高级种植机会',true);return}state.plantMode='advanced-exchange';state.selectedReward=null;state.selectedSpecies=null;$('#modalReason').textContent='将消耗 3 次初级种植机会，兑换 1 次高级植物种植。';renderPlantCategory('advanced');$('#plantModal').classList.remove('hidden')}
openPlant=openPlantTabbed;
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function showNextActionLogin(show=true){$('#nextActionLogin').classList.toggle('hidden',!show)}
const NEXT_ACTION_GENERATION_KEY='focus-garden-next-action-generation-v1';
const NEXT_ACTION_GENERATION_MAX_AGE_MS=5*60*1000;
function nextActionStatus(message,bad=false){const el=$('#nextActionStatus');el.textContent=message;el.classList.toggle('bad',bad)}
function nextActionGenerationRecord(){try{const value=JSON.parse(sessionStorage.getItem(NEXT_ACTION_GENERATION_KEY)||'null');if(!value||!Number.isFinite(value.startedAt)||Date.now()-value.startedAt>NEXT_ACTION_GENERATION_MAX_AGE_MS){sessionStorage.removeItem(NEXT_ACTION_GENERATION_KEY);return null}return value}catch{sessionStorage.removeItem(NEXT_ACTION_GENERATION_KEY);return null}}
function formatNextActionWait(startedAt){const seconds=Math.max(0,Math.floor((Date.now()-startedAt)/1000)),minutes=Math.floor(seconds/60),remainder=seconds%60;return minutes?`${minutes}分${String(remainder).padStart(2,'0')}秒`:`${remainder}秒`}
function nextActionWaitingText(record){return `正在为你找下一步 · 已等待 ${formatNextActionWait(record.startedAt)}`}
function clearNextActionGeneration(){sessionStorage.removeItem(NEXT_ACTION_GENERATION_KEY);state.nextAction.generation=null;state.nextAction.generationPolling=false;state.nextAction.generationPollAt=0;clearInterval(state.nextAction.generationTimer);state.nextAction.generationTimer=null}
function renderNextActionWaiting(){const record=nextActionGenerationRecord();if(!record)return false;state.nextAction.generation=record;state.nextAction.active=null;$('#nextActionSuggestion').innerHTML=`<div class="next-action-empty"><div class="empty-sprout">✦</div><h2>正在为你找下一步</h2><p>${escapeHtml(nextActionWaitingText(record))}</p><p>切换到其他页面也不会中断；回来后会继续显示这里。</p></div>`;$('#nextActionFeedback').classList.add('hidden');$('#nextActionGenerate').disabled=true;nextActionStatus(nextActionWaitingText(record));return true}
async function pollNextActionGeneration(){const record=nextActionGenerationRecord();if(!record||state.nextAction.generationPolling)return;state.nextAction.generationPolling=true;try{const data=await api('/api/next-action/active');if(record.baselineSuggestionId&&data.suggestion_id===record.baselineSuggestionId)return;clearNextActionGeneration();renderNextAction(data);nextActionStatus('这一步已经准备好，先只做第一步。')}catch(error){if(error.status!==404&&error.status!==401)nextActionStatus(`仍在等待：${error.message}`,true)}finally{state.nextAction.generationPolling=false}}
function watchNextActionGeneration(){clearInterval(state.nextAction.generationTimer);const tick=()=>{const record=nextActionGenerationRecord();if(!record){clearInterval(state.nextAction.generationTimer);state.nextAction.generationTimer=null;return}if(state.page==='next-action')renderNextActionWaiting();if(Date.now()-state.nextAction.generationPollAt>=2000){state.nextAction.generationPollAt=Date.now();void pollNextActionGeneration()}};tick();state.nextAction.generationTimer=setInterval(tick,1000)}
function beginNextActionGeneration(){const record={startedAt:Date.now(),baselineSuggestionId:state.nextAction.active?.suggestion_id||''};sessionStorage.setItem(NEXT_ACTION_GENERATION_KEY,JSON.stringify(record));state.nextAction.generation=record;watchNextActionGeneration();return record}
function restoreNextActionGeneration(){if(!nextActionGenerationRecord())return false;renderNextActionWaiting();watchNextActionGeneration();return true}
function nextActionClarification(data){const value=data?.clarification||{};const rounds=Array.isArray(value.rounds)?value.rounds:[];return{rounds,maxRounds:Number(value.max_rounds)||2}}
function renderNextActionClarification(data){const {rounds,maxRounds}=nextActionClarification(data);const left=Math.max(0,maxRounds-rounds.length);const revision=Number(data.action_revision)||0;const accepted=data.accepted_action_revision!==undefined&&data.accepted_action_revision!==null;$('#nextActionAccept').disabled=accepted;$('#nextActionAccept').textContent=accepted?'已接受当前最后版本':(rounds.length?'接受最后更新的这一步':'开始这一步');$('#nextActionAcceptNote').textContent=accepted?`已接受行动版本 ${data.accepted_action_revision}；结束后请在下方记录结果。`:(rounds.length?`接受将记录第 ${rounds.length} 轮澄清后生成的行动版本 ${revision}；不会接受最初那一版。`:'如果你先说说卡点，接受只会指向最后生成的行动。');$('#nextActionClarify').disabled=accepted||left===0;$('#nextActionClarify').textContent=accepted?'已接受，等待结果':(left?`说说哪里卡住（还可 ${left} 轮）`:'已完成两轮澄清');$('#nextActionClarifyRound').textContent=`行动澄清 ${rounds.length}/${maxRounds}`;$('#nextActionClarifyHint').textContent=accepted?'当前行动已接受；请先记录结果，再生成新的建议。':(left?'写一句真实阻力；助手会给出更新后的行动。':'两轮已用完；现在可接受上方最后更新的一步，或换一个。');$('#nextActionClarifyHistory').innerHTML=rounds.length?rounds.map(item=>`<div class="next-action-dialogue"><p><b>你</b>${escapeHtml(item.user_message||'')}</p><p><b>助手</b>${escapeHtml(item.assistant_message||'')}</p></div>`).join(''):''}
function renderNextAction(data){clearNextActionGeneration();state.nextAction.active=data;const evidence=Array.isArray(data.evidence_points)?data.evidence_points.slice(0,4):[];const card=$('#nextActionSuggestion');card.innerHTML=`<div class="next-action-title"><div><p class="eyebrow">A SMALL, REAL START</p><h2>${escapeHtml(data.title||'当前建议')}</h2></div><div class="next-action-pills"><span>${escapeHtml(data.duration_minutes||'')} 分钟</span><span>${escapeHtml(data.decision_type||'行动')}</span></div></div><div class="next-action-first-step"><span>当前最后版本 · 先做这一件</span><strong>${escapeHtml(data.first_step||'')}</strong></div><div class="next-action-copy"><h3>为什么是现在</h3><p>${escapeHtml(data.reason_short||'')}</p><p>${escapeHtml(data.persuasive_explanation||'')}</p></div><div class="next-action-evidence"><h3>花园看到的线索</h3>${evidence.length?`<ul>${evidence.map(item=>`<li>${escapeHtml(item)}</li>`).join('')}</ul>`:'<p>这次没有可展示的线索。</p>'}</div><div class="next-action-reduced"><span>如果现在还是难</span><p>${escapeHtml(data.reduced_version||'')}</p></div>`;$('#nextActionFeedback').classList.toggle('hidden',!data.suggestion_id);if(data.suggestion_id)renderNextActionClarification(data);showNextActionLogin(false)}
function clearNextActionSuggestion(message='点击“为我找下一步”，或查看尚未结束的当前建议。'){state.nextAction.active=null;$('#nextActionSuggestion').innerHTML=`<div class="next-action-empty"><div class="empty-sprout">✦</div><h2>把今天的线索收拢成一步</h2><p>${escapeHtml(message)}</p></div>`;$('#nextActionFeedback').classList.add('hidden')}
async function loadNextActionActive(){try{renderNextAction(await api('/api/next-action/active'));nextActionStatus('当前建议会在这里安静等你。');return true}catch(error){if(error.status===404){clearNextActionSuggestion();return false}if(error.status===401){showNextActionLogin();nextActionStatus('请输入 Next Action 的访问密码后继续。');return false}nextActionStatus(error.message,true);return false}}
async function generateNextAction(exclude=''){if(restoreNextActionGeneration())return;beginNextActionGeneration();try{const data=await api('/api/next-action/generate',{method:'POST',body:JSON.stringify(exclude?{exclude_suggestion_id:exclude}:{})});state.nextAction.pendingGeneration=false;renderNextAction(data);nextActionStatus('这一步已经准备好，先只做第一步。')}catch(error){clearNextActionGeneration();if(error.payload&&error.payload.code==='pending_outcome_required'){state.nextAction.pendingGeneration=true;renderNextAction(error.payload.suggestion);nextActionStatus('先记下上一条建议的结果；保存后会继续生成这一次。');return}if(error.status===401)showNextActionLogin();nextActionStatus(`生成失败：${error.message}`,true)}finally{if(!nextActionGenerationRecord())$('#nextActionGenerate').disabled=false}}
async function saveNextActionResponse(result,withReason=false){const active=state.nextAction.active;if(!active)return;const body={result,expected_action_revision:Number(active.action_revision)||0};if(withReason){body.reason_code=$('#nextActionReason').value;body.detail=$('#nextActionDetail').value}try{const saved=await api(`/api/next-action/suggestion/${encodeURIComponent(active.suggestion_id)}/response`,{method:'POST',body:JSON.stringify(body)});$('#nextActionReasonBox').classList.add('hidden');if(result==='accepted'){active.accepted_action_revision=saved.accepted_action_revision;active.accepted_action_id=saved.accepted_action_id;renderNextAction(active)}nextActionStatus(withReason?'反馈已经存下，之后可以用来复盘。':(Number(active.action_revision)?'已接受最后更新的行动。':'已记下：开始。'));if(result==='alternative_requested')await generateNextAction(active.suggestion_id)}catch(error){nextActionStatus(error.message,true)}}
function openNextActionClarification(){const active=state.nextAction.active;if(!active)return;const {rounds,maxRounds}=nextActionClarification(active);if(rounds.length>=maxRounds){nextActionStatus('这条建议已经完成两轮澄清；请接受最后版本，或换一个。',true);return}$('#nextActionReasonBox').classList.add('hidden');$('#nextActionClarifyBox').classList.remove('hidden');$('#nextActionClarifyMessage').focus()}
async function submitNextActionClarification(){const active=state.nextAction.active;if(!active)return;const message=$('#nextActionClarifyMessage').value.trim();if(!message){nextActionStatus('先写一句你真正卡住的地方。',true);return}const button=$('#nextActionClarifySubmit');button.disabled=true;nextActionStatus('正在把这句阻力缩成更能开始的一步……');try{const data=await api(`/api/next-action/suggestion/${encodeURIComponent(active.suggestion_id)}/clarify`,{method:'POST',body:JSON.stringify({message,expected_action_revision:Number(active.action_revision)||0})});$('#nextActionClarifyMessage').value='';$('#nextActionClarifyBox').classList.add('hidden');renderNextAction(data);nextActionStatus('已更新为最后一版行动；“接受”只会接受这一步。')}catch(error){nextActionStatus(error.message,true)}finally{button.disabled=false}}
async function saveNextActionOutcome(result){const active=state.nextAction.active;if(!active)return;try{await api(`/api/next-action/suggestion/${encodeURIComponent(active.suggestion_id)}/outcome`,{method:'POST',body:JSON.stringify({result})});nextActionStatus(`已记录：${({completed:'完成了',still_doing:'正在做',not_started:'没开始'})[result]}。`);if(state.nextAction.pendingGeneration){state.nextAction.pendingGeneration=false;await generateNextAction()} }catch(error){nextActionStatus(error.message,true)}}
async function loginNextAction(){const password=$('#nextActionPassword').value;if(!password){nextActionStatus('请输入访问密码。',true);return}const button=$('#nextActionLoginBtn');button.disabled=true;try{await api('/api/next-action/login',{method:'POST',body:JSON.stringify({password})});$('#nextActionPassword').value='';showNextActionLogin(false);nextActionStatus('已解锁行动助手。');await loadNextActionPanel()}catch(error){nextActionStatus(error.message,true)}finally{button.disabled=false}}
async function loadNextActionReports(){try{const data=await api('/api/next-action/reports');const reports=Array.isArray(data.reports)?data.reports:[];$('#nextActionReportList').innerHTML=reports.length?reports.map(item=>`<button class="report-button" data-report-path="${encodeURIComponent(item.path)}">${escapeHtml(item.label||item.path)}</button>`).join(''):'<p class="setting-help">还没有可展示的报告。</p>';$$('[data-report-path]').forEach(button=>button.onclick=()=>loadNextActionReport(decodeURIComponent(button.dataset.reportPath)))}catch(error){if(error.status===401)showNextActionLogin();$('#nextActionReportList').innerHTML=`<p class="setting-help">${escapeHtml(error.message)}</p>`}}
async function loadNextActionReport(path){try{const data=await api(`/api/next-action/report?path=${encodeURIComponent(path)}`);state.nextAction.reportPath=path;$('#nextActionReportDetail').textContent=data.text||'报告为空。';$('#nextActionReportDetail').classList.remove('hidden');$('#nextActionReportFeedback').classList.remove('hidden')}catch(error){nextActionStatus(error.message,true)}}
async function submitNextActionReportFeedback(){if(!state.nextAction.reportPath){nextActionStatus('请先选择一条报告。',true);return}try{await api('/api/next-action/report-feedback',{method:'POST',body:JSON.stringify({category:$('#nextActionReportCategory').value,message:$('#nextActionReportMessage').value})});$('#nextActionReportMessage').value='';nextActionStatus('报告反馈已存档。')}catch(error){nextActionStatus(error.message,true)}}
async function loadNextActionIssues(){try{const data=await api('/api/next-action/issues');const issues=Array.isArray(data.issues)?data.issues:[];$('#nextActionIssueList').innerHTML=issues.length?issues.slice(0,4).map(item=>`<div><b>${escapeHtml(item.category||'问题')}</b><p>${escapeHtml(item.message||'')}</p></div>`).join(''):''}catch(error){if(error.status===401)showNextActionLogin()}}
async function submitNextActionIssue(){const message=$('#nextActionIssueMessage').value.trim();if(!message){nextActionStatus('先写下你遇到的问题。',true);return}try{await api('/api/next-action/issue-feedback',{method:'POST',body:JSON.stringify({category:$('#nextActionIssueCategory').value,severity:$('#nextActionIssueSeverity').value,message,page:'focus-garden-next-action',suggestion_id:state.nextAction.active?.suggestion_id||'',report_path:state.nextAction.reportPath||''})});$('#nextActionIssueMessage').value='';nextActionStatus('问题已收进 backlog。');await loadNextActionIssues()}catch(error){nextActionStatus(error.message,true)}}
function taskStatus(message,bad=false){const el=$('#taskStatus');el.textContent=message;el.classList.toggle('bad',bad)}
function taskId(){return `^${crypto.randomUUID().replace(/-/g,'').slice(0,8)}`}
function shanghaiDate(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function shiftCalendarDate(value,days){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))throw new Error('任务日期格式不正确。');const [year,month,day]=value.split('-').map(Number),shifted=new Date(Date.UTC(year,month-1,day+days));return shifted.toISOString().slice(0,10)}
function clearTaskForm(){state.nextAction.taskEditingId=null;$('#taskTitle').value='';$('#taskScheduledDate').value='';$('#taskDueDate').value='';$('#taskPriority').value='normal';$('#taskTomatoesTotal').value='';$('#taskSave').textContent='新建任务';$('#taskListView .task-composer').classList.remove('task-editor-target')}
function taskPayload(operation,taskIdValue){const total=$('#taskTomatoesTotal').value;return{operation,task_id:taskIdValue,title:$('#taskTitle').value.trim(),scheduled_date:$('#taskScheduledDate').value||null,due_date:$('#taskDueDate').value||null,priority:$('#taskPriority').value,tomatoes_total:total===''?null:Number(total)}}
function procrastinationBadge(task){if(task?.procrastinated!==true)return'';const days=Math.max(2,Number(task.postponed_days)||2);return`<span class="task-procrastination-badge" title="该任务已累计推迟 ${days} 天">拖延 · ${days}天</span>`}
function displayTaskGroups(data){
  const original=data.tasks||{},today=shanghaiDate(),groups={};
  for(const [key,value] of Object.entries(original))groups[key]=Array.isArray(value)?[...value]:[];
  const recurringToday=(groups.recurring||[]).filter(task=>task.scheduled_date===today);
  groups.recurring=(groups.recurring||[]).filter(task=>task.scheduled_date!==today);
  groups.today=[...(groups.today||[]),...recurringToday];
  return groups;
}
function renderTasks(data){
  const groups=displayTaskGroups(data),order=['unassigned','overdue','today','near_term','later','recurring'];
  const completed=Array.isArray(data.completed_today)?data.completed_today:[];
  const meta={unassigned:['待正式安排','仅有重要等级；会写入 ToDo-任务集合顶部'],overdue:['已逾期','需要重新决定日期'],today:['今天','含今天命中的循环任务'],near_term:['未来三天','即将到来'],later:['之后','尚未到执行窗口'],recurring:['后续循环任务','请在 Obsidian 中维护完成']};
  const items=order.flatMap(group=>(groups[group]||[]).map(task=>({...task,group})));
  state.nextAction.tasks=new Map(items.map(task=>[task.task_id,task]));
  $('#taskCount').textContent=`${items.length} 项待办 · ${completed.length} 项已完成`;
  const primaryEligible=task=>[shanghaiDate(),shiftCalendarDate(shanghaiDate(),1)].includes(task.scheduled_date);
  const renderTask=task=>`<div class="task-row${task.recurrence?' recurring':''}${task.is_primary?' is-primary':''}"><div class="task-row-copy"><div class="task-title-line"><b>${escapeHtml(task.title||'未命名任务')}</b>${task.is_primary?'<span class="task-primary-badge">主要</span>':''}${procrastinationBadge(task)}</div><p>${escapeHtml(task.scheduled_date||'未安排')}<span>优先级：${escapeHtml(task.priority||'normal')}</span>${task.tomatoes_total!=null?`<span>🍅 ${escapeHtml(task.tomatoes_completed||0)}/${escapeHtml(task.tomatoes_total)}</span>`:''}${task.recurrence?'<span class="task-repeat-badge">循环</span>':''}</p></div><div class="task-row-controls">${primaryEligible(task)?`<div class="task-primary-actions"><button class="${task.is_primary?'selected':''}" data-task-primary="${encodeURIComponent(task.task_id)}">${task.is_primary?'取消主要':'设为主要'}</button></div>`:''}<div class="task-row-actions"><button data-task-edit="${encodeURIComponent(task.task_id)}">编辑</button><button data-task-postpone="${encodeURIComponent(task.task_id)}">推迟一天</button><button class="danger" data-task-complete="${encodeURIComponent(task.task_id)}">${task.recurrence?'完成本次':'完成'}</button><button class="danger" data-task-delete="${encodeURIComponent(task.task_id)}">删除</button></div></div></div>`;
  const renderCompleted=task=>`<div class="task-row task-row-completed${task.recurring?' recurring':''}${task.is_primary?' is-primary':''}"><span class="task-complete-check">✓</span><div class="task-row-copy"><b>${escapeHtml(task.title||'未命名任务')}</b>${task.is_primary?'<span class="task-primary-badge">主要任务已完成</span>':''}<p>今天完成${task.tomatoes_total!=null?`<span>🍅 ${escapeHtml(task.tomatoes_completed||0)}/${escapeHtml(task.tomatoes_total)}</span>`:''}${task.recurring?'<span class="task-repeat-badge">本次循环</span>':''}${task.sync_pending?'<span>等待 Obsidian 同步</span>':''}</p></div></div>`;
  const visibleGroups=order.filter(group=>(groups[group]||[]).length||(group==='today'&&completed.length));
  $('#taskList').innerHTML=visibleGroups.length?visibleGroups.map(group=>`<section class="task-group"><div class="task-group-heading"><h3>${meta[group][0]}</h3><span>${meta[group][1]} · ${(groups[group]||[]).length}${group==='today'&&completed.length?` + ${completed.length} 已完成`:''}</span></div>${(groups[group]||[]).map(task=>renderTask({...task,group})).join('')}${group==='today'&&completed.length?`<div class="task-completed-divider">今日已完成 · ${completed.length}</div>${completed.map(renderCompleted).join('')}`:''}</section>`).join(''):'<div class="task-empty"><div>☷</div><h3>清单是空的</h3><p>在左侧写下下一件要做的事，或打开 Obsidian 同步已有任务。</p></div>';
  $$('[data-task-edit]').forEach(button=>button.onclick=()=>editTask(decodeURIComponent(button.dataset.taskEdit)));
  $$('[data-task-primary]').forEach(button=>button.onclick=()=>setPrimaryTask(decodeURIComponent(button.dataset.taskPrimary)));
  $$('[data-task-postpone]').forEach(button=>button.onclick=()=>postponeTask(decodeURIComponent(button.dataset.taskPostpone)));
  $$('[data-task-complete]').forEach(button=>button.onclick=()=>completeTask(decodeURIComponent(button.dataset.taskComplete)));
  $$('[data-task-delete]').forEach(button=>button.onclick=()=>deleteTask(decodeURIComponent(button.dataset.taskDelete)));
  taskStatus(data.pending_mutation_count?`Pi 有 ${data.pending_mutation_count} 条改动等待 Obsidian 写回。`:'已与 Pi 的有效任务视图同步。');
}
function calendarDate(value){const [y,m,d]=value.split('-').map(Number);return new Date(Date.UTC(y,m-1,d))}
function daysBetween(a,b){return Math.round((calendarDate(a)-calendarDate(b))/86400000)}
function calendarRange(mode){
  const today=shanghaiDate();
  if(mode==='week')return{start:today,end:shiftCalendarDate(today,5)};
  const [year,month]=today.split('-').map(Number),end=new Date(Date.UTC(year,month,0)).toISOString().slice(0,10);
  return{start:`${year}-${String(month).padStart(2,'0')}-01`,end};
}
function rangeDates(start,end){const dates=[];for(let value=start;value<=end;value=shiftCalendarDate(value,1))dates.push(value);return dates}
function effectiveTasks(data){return Object.values(data?.tasks||{}).flatMap(group=>Array.isArray(group)?group:[])}
function taskDatesInRange(task,start,end){
  const scheduled=task.scheduled_date||task.due_date;
  if(!scheduled)return[];
  if(!task.recurrence)return scheduled>=start&&scheduled<=end?[scheduled]:[];
  const match=String(task.recurrence).match(/every(?:\s+(\d+))?\s+weeks?\s+on\s+(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)/i);
  if(!match)return scheduled>=start&&scheduled<=end?[scheduled]:[];
  const interval=Number(match[1]||1),anchor=scheduled,weekdays={Sunday:0,Monday:1,Tuesday:2,Wednesday:3,Thursday:4,Friday:5,Saturday:6},wanted=weekdays[match[2][0].toUpperCase()+match[2].slice(1).toLowerCase()];
  return rangeDates(start,end).filter(date=>date>=anchor&&calendarDate(date).getUTCDay()===wanted&&Math.floor(daysBetween(date,anchor)/7)%interval===0);
}
function calendarEntries(data,start,end){
  const entries=[];
  for(const task of effectiveTasks(data))for(const date of taskDatesInRange(task,start,end))entries.push({...task,calendar_date:date});
  for(const task of (data.completed_today||[])){const date=task.occurrence_date||shanghaiDate();if(date>=start&&date<=end)entries.push({...task,calendar_date:date,completed:true})}
  const seen=new Set();
  return entries.filter(task=>{const key=`${task.task_id}|${task.calendar_date}`;if(seen.has(key))return false;seen.add(key);return true});
}
function priorityLabel(priority){return({highest:'最高',high:'高',medium:'中',normal:'普通',low:'低',lowest:'最低'})[priority]||priority||'普通'}
function calendarTaskCard(task,{showEdit=false}={}){const total=task.tomatoes_total,done=task.tomatoes_completed||0,id=encodeURIComponent(task.task_id||''),editable=!task.completed;return`<div class="calendar-task priority-${escapeHtml(task.priority||'normal')}${task.completed?' is-completed':''}${task.procrastinated?' is-procrastinated':''}" ${editable?`data-calendar-task-id="${id}" tabindex="0" title="双击编辑任务"`:''}>${task.completed?'<span class="calendar-complete-check">✓</span>':`<span class="priority-chip">${escapeHtml(priorityLabel(task.priority))}</span>`}<div><div class="task-title-line"><b>${escapeHtml(task.title||'未命名任务')}</b>${procrastinationBadge(task)}</div><p>${task.completed?'已完成 · ':task.recurrence?'↻ 循环任务 · ':''}${total!=null?`🍅 ${done}/${total}`:'未设置番茄钟'}</p></div>${showEdit&&editable?`<button class="calendar-task-edit" type="button" data-calendar-edit="${id}">编辑任务</button>`:''}</div>`}
function calendarDayTitle(date){return new Intl.DateTimeFormat('zh-CN',{timeZone:'UTC',month:'numeric',day:'numeric',weekday:'short'}).format(calendarDate(date))}
function calendarContextRange(note){
  const parsed=note?.parse||{},type=parsed.type;
  if((type==='day'||type==='daypart')&&parsed.date){const date=String(parsed.date).slice(0,10);return{start:date,end:date}}
  if(type==='range'&&parsed.start&&parsed.end)return{start:String(parsed.start).slice(0,10),end:String(parsed.end).slice(0,10)};
  return null;
}
function calendarContextSpan(note){const range=calendarContextRange(note);return range?Math.max(1,daysBetween(range.end,range.start)+1):Infinity}
function calendarContextsForDate(date){return(state.taskCalendar.activeContext||[]).filter(note=>{const range=calendarContextRange(note);return range&&date>=range.start&&date<=range.end})}
function calendarLongContexts(start,end){return(state.taskCalendar.activeContext||[]).filter(note=>{const range=calendarContextRange(note);if(!range)return true;return calendarContextSpan(note)>=3&&range.end>=start&&range.start<=end})}
function calendarContextCard(note,{showEdit=false}={}){const id=encodeURIComponent(note.id||''),scope=note.parse_text||'影响范围待系统确认';return`<div class="calendar-context-card" data-calendar-context-id="${id}" tabindex="0" title="双击编辑动态"><div><b>${escapeHtml(note.content||'未命名动态')}</b><p>${escapeHtml(scope)}</p></div>${showEdit?`<button class="calendar-context-edit" type="button" data-calendar-context-edit="${id}">编辑动态</button>`:''}</div>`}
function calendarAchievement(date){return(state.data?.daily_achievements||[]).find(item=>item.date===date&&Number(item.eligible)===1)||null}
function calendarAchievementBadge(date,compact=false){const item=calendarAchievement(date);return item?`<span class="calendar-achievement-check${compact?' compact':''}" title="${item.completed_tomatoes}/${item.planned_tomatoes} 个番茄钟全部完成">✓</span>`:''}
function closeCalendarDayModal(restoreFocus=true){
  $('#calendarModal').classList.add('hidden');
  document.body.classList.remove('calendar-modal-open');
  if(restoreFocus&&state.taskCalendar.modalTrigger?.isConnected)state.taskCalendar.modalTrigger.focus();
  state.taskCalendar.modalTrigger=null;
}
function openTaskEditorFromCalendar(id){
  const task=state.nextAction.tasks?.get(id);
  if(!task){toast('任务已经更新，请刷新清单后重试。',true);return}
  closeCalendarDayModal(false);
  setTaskView('list');
  editTask(id);
  const composer=$('#taskListView .task-composer');
  composer.classList.remove('task-editor-target');
  requestAnimationFrame(()=>{
    composer.classList.add('task-editor-target');
    composer.scrollIntoView({behavior:'smooth',block:'start'});
    $('#taskTitle').focus({preventScroll:true});
    setTimeout(()=>composer.classList.remove('task-editor-target'),1800);
  });
  taskStatus(task.recurrence?'正在编辑循环任务本体；保存会更新整个循环任务。':`已从日历打开「${task.title||'未命名任务'}」。`);
}
function bindCalendarTaskEditors(root=document){
  root.querySelectorAll('[data-calendar-task-id]').forEach(card=>{
    const edit=()=>openTaskEditorFromCalendar(decodeURIComponent(card.dataset.calendarTaskId));
    card.ondblclick=event=>{event.preventDefault();event.stopPropagation();edit()};
    card.onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();event.stopPropagation();edit()}};
  });
  root.querySelectorAll('[data-calendar-edit]').forEach(button=>button.onclick=event=>{event.stopPropagation();openTaskEditorFromCalendar(decodeURIComponent(button.dataset.calendarEdit))});
}
async function openRecentContextEditorFromCalendar(id){
  closeCalendarDayModal(false);
  await navigate('recent-context');
  const note=(state.recentContext.notes||[]).find(item=>item.id===id);
  if(!note){toast('动态已经更新，请刷新后重试。',true);return}
  editRecentContext(id);
  const composer=$('.rc-composer');
  composer.classList.remove('task-editor-target');
  requestAnimationFrame(()=>{
    composer.classList.add('task-editor-target');
    composer.scrollIntoView({behavior:'smooth',block:'start'});
    $('#rcContent').focus({preventScroll:true});
    setTimeout(()=>composer.classList.remove('task-editor-target'),1800);
  });
}
function bindCalendarContextEditors(root=document){
  root.querySelectorAll('[data-calendar-context-id]').forEach(card=>{
    const edit=()=>openRecentContextEditorFromCalendar(decodeURIComponent(card.dataset.calendarContextId));
    card.ondblclick=event=>{event.preventDefault();event.stopPropagation();edit()};
    card.onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();event.stopPropagation();edit()}};
  });
  root.querySelectorAll('[data-calendar-context-edit]').forEach(button=>button.onclick=event=>{event.stopPropagation();openRecentContextEditorFromCalendar(decodeURIComponent(button.dataset.calendarContextEdit))});
}
function openCalendarDayModal(date,entries,trigger=null){
  state.taskCalendar.selectedDate=date;
  state.taskCalendar.modalTrigger=trigger;
  const tasks=entries.filter(task=>task.calendar_date===date),contexts=calendarContextsForDate(date),tomatoes=tasks.reduce((sum,task)=>sum+(Number(task.tomatoes_total)||0),0),content=$('#calendarModalContent');
  const achievement=calendarAchievement(date);
  content.innerHTML=`<div class="calendar-modal-head"><div><p class="eyebrow">DAY DETAILS</p><h2 id="calendarModalTitle">${escapeHtml(calendarDayTitle(date))}</h2><p>${escapeHtml(date)} · ${tasks.length} 项任务 · 🍅 ${tomatoes}</p></div>${calendarAchievementBadge(date)}</div>${achievement?`<div class="calendar-achievement-summary"><b>✓ 全部完成</b><span>${achievement.completed_tomatoes} / ${achievement.planned_tomatoes} 个番茄钟 · 已发放高级植株机会</span></div>`:''}<p class="calendar-modal-hint">双击未完成任务或动态可前往对应页面编辑；手机请使用编辑按钮。</p><section class="calendar-modal-section"><h3>当天任务</h3><div class="calendar-detail-list">${tasks.length?tasks.map(task=>calendarTaskCard(task,{showEdit:true})).join(''):'<p class="setting-help">这一天没有待办。</p>'}</div></section><section class="calendar-modal-section"><h3>当天动态</h3><div class="calendar-context-list">${contexts.length?contexts.map(note=>calendarContextCard(note,{showEdit:true})).join(''):'<p class="setting-help">这一天没有可映射的动态。</p>'}</div></section>`;
  bindCalendarTaskEditors(content);
  bindCalendarContextEditors(content);
  $('#calendarModal').classList.remove('hidden');
  document.body.classList.add('calendar-modal-open');
  $('#calendarModalClose').focus();
}
function renderWeekCalendar(entries,start,end){
  $('#calendarRangeLabel').textContent=`${start} 至 ${end} · 完整展示每天的任务、优先级与番茄钟。`;
  const longContexts=calendarLongContexts(start,end);
  $('#calendarBody').innerHTML=`<div class="calendar-week">${rangeDates(start,end).map(date=>{const tasks=entries.filter(task=>task.calendar_date===date),contexts=calendarContextsForDate(date).filter(note=>calendarContextSpan(note)<=2);return`<section class="pixel-panel calendar-week-day${date===shanghaiDate()?' is-today':''}" data-calendar-open="${date}" tabindex="0" role="button" aria-label="查看 ${escapeHtml(calendarDayTitle(date))} 的任务与动态"><header><span>${calendarDayTitle(date)}${calendarAchievementBadge(date,true)}</span><b>${tasks.length} 任务${contexts.length?` · ${contexts.length} 动态`:''}</b></header><div>${tasks.length?tasks.map(task=>calendarTaskCard(task)).join(''):'<p class="calendar-empty-day">这一天没有待办。</p>'}${contexts.map(note=>calendarContextCard(note,{showEdit:true})).join('')}</div></section>`}).join('')}</div>${longContexts.length?`<section class="pixel-panel calendar-long-contexts"><div class="panel-heading"><div><p class="eyebrow">CONTINUING CONTEXT</p><h2>持续影响动态</h2></div></div><div class="calendar-context-list">${longContexts.map(note=>calendarContextCard(note,{showEdit:true})).join('')}</div></section>`:''}`;
  $$('[data-calendar-open]').forEach(card=>{const open=event=>{if(event.target.closest('[data-calendar-task-id],[data-calendar-context-id]'))return;openCalendarDayModal(card.dataset.calendarOpen,entries,card)};card.onclick=open;card.onkeydown=event=>{if((event.key==='Enter'||event.key===' ')&&event.target===card){event.preventDefault();open(event)}}});
  bindCalendarTaskEditors($('#calendarBody'));
  bindCalendarContextEditors($('#calendarBody'));
}
function renderMonthCalendar(entries,start,end){
  const dates=rangeDates(start,end),offset=(calendarDate(start).getUTCDay()+6)%7;
  $('#calendarRangeLabel').textContent=`${start.slice(0,7)} · 缩略图显示任务数与预计番茄钟；黄点数字表示 highest 任务数量。`;
  $('#calendarBody').innerHTML=`<div class="calendar-month-weekdays">${['一','二','三','四','五','六','日'].map(day=>`<span>周${day}</span>`).join('')}</div><div class="calendar-month">${'<span class="calendar-month-blank"></span>'.repeat(offset)}${dates.map(date=>{const tasks=entries.filter(task=>task.calendar_date===date),tomatoes=tasks.reduce((sum,task)=>sum+(Number(task.tomatoes_total)||0),0),highestCount=tasks.filter(task=>task.priority==='highest').length;return`<button type="button" class="calendar-month-day${date===shanghaiDate()?' is-today':''}${tasks.length?' has-tasks':''}${calendarAchievement(date)?' has-achievement':''}" data-calendar-date="${date}"><span class="calendar-month-date"><strong>${Number(date.slice(-2))}</strong>${highestCount?`<em class="calendar-highest-count" aria-label="${highestCount} 项最高优先级任务"><i></i>${highestCount}</em>`:''}</span>${calendarAchievementBadge(date)}<b>🍅 ${tomatoes}</b><small>${tasks.length} 项任务</small></button>`}).join('')}</div>`;
  $$('[data-calendar-date]').forEach(button=>button.onclick=()=>openCalendarDayModal(button.dataset.calendarDate,entries,button));
}
function renderCalendar(){
  const data=state.taskCalendar.data;if(!data)return;
  const {start,end}=calendarRange(state.taskCalendar.mode),entries=calendarEntries(data,start,end);
  if(state.taskCalendar.mode==='month')renderMonthCalendar(entries,start,end);else renderWeekCalendar(entries,start,end);
}
function renderCalendarContext(notes){
  state.taskCalendar.activeContext=(notes||[]).filter(note=>!note.archived&&(note.status==='active'||note.status==='upcoming'));
  renderCalendar();
}
async function loadCalendarContext(){try{const data=await api(`/api/recent-context?refresh=${Date.now()}`);renderCalendarContext(data.notes)}catch(error){state.taskCalendar.activeContext=[];renderCalendar();toast(`近期动态暂不可用：${error.message}`,true)}}
function setTaskView(view){
  $$('[data-task-view]').forEach(button=>button.classList.toggle('active',button.dataset.taskView===view));
  $('#taskListView').classList.toggle('hidden',view!=='list');$('#taskCalendarView').classList.toggle('hidden',view!=='calendar');
  if(view==='calendar'){renderCalendar();loadCalendarContext()}
}
function setCalendarMode(mode){state.taskCalendar.mode=mode;$$('[data-calendar-mode]').forEach(button=>button.classList.toggle('active',button.dataset.calendarMode===mode));renderCalendar()}
async function loadTasks(){try{const data=await api(`/api/tasks?refresh=${Date.now()}`);state.taskCalendar.data=data;renderTasks(data);renderCalendar()}catch(error){taskStatus(error.message,true)}}
function editTask(id){const task=state.nextAction.tasks?.get(id);if(!task)return;state.nextAction.taskEditingId=id;$('#taskTitle').value=task.title||'';$('#taskScheduledDate').value=task.scheduled_date||'';$('#taskDueDate').value=task.due_date||'';$('#taskPriority').value=task.priority||'normal';$('#taskTomatoesTotal').value=task.tomatoes_total??'';$('#taskSave').textContent='保存修改';taskStatus(`正在编辑 ${id}。`)}
async function applyTaskMutation(body,successMessage){const result=await api('/api/tasks/mutations',{method:'POST',body:JSON.stringify(body)});if(!result.effective||!result.effective.tasks)throw new Error('Pi 没有返回更新后的有效任务视图。');renderTasks(result.effective);await loadTasks();taskStatus(successMessage)}
async function setPrimaryTask(id){const task=state.nextAction.tasks?.get(id);if(!task)return;try{const result=await api('/api/tasks/primary',{method:'POST',body:JSON.stringify({task_id:id,clear:Boolean(task.is_primary)})});renderTasks(result);renderCalendar();taskStatus(task.is_primary?'已取消主要任务。':'已设为主要任务；完成后再累计至少 6 个番茄钟，Steam 才会解锁。')}catch(error){taskStatus(error.message,true)}}
async function saveTask(){const id=state.nextAction.taskEditingId||taskId();if(!$('#taskTitle').value.trim()){taskStatus('请先写任务描述。',true);return}try{const operation=state.nextAction.taskEditingId?'update':'create';await applyTaskMutation(taskPayload(operation,id),'清单和 Next Action 已立即更新；Obsidian 将在后台写回。');clearTaskForm()}catch(error){taskStatus(error.message,true)}}
async function postponeTask(id){const task=state.nextAction.tasks?.get(id);if(!task)return;const nextDate=shiftCalendarDate(task.scheduled_date||shanghaiDate(),1);try{await applyTaskMutation({operation:'postpone',task_id:id,scheduled_date:nextDate},`已推迟到 ${nextDate}；累计推迟满 2 天后会标记“拖延”，并由 Next Action 优先安排。`)}catch(error){taskStatus(error.message,true)}}
async function completeTask(id){const task=state.nextAction.tasks?.get(id),recurring=Boolean(task?.recurrence);if(!confirm(recurring?'完成今天这一次循环任务？Pi 会保留完成记录，并让 Obsidian 将任务推进到下一次。':'完成这个任务？它会在今天栏目中打勾变灰，并由 Obsidian 在后台归档。'))return;try{await applyTaskMutation({operation:'complete',task_id:id},recurring?'本次循环已完成；日期与番茄进度将在 Obsidian 后台推进。':'任务已完成；今天仍会保留灰色记录。')}catch(error){taskStatus(error.message,true)}}
async function deleteTask(id){if(!confirm('删除后会在下次 Obsidian 同步时从任务 Markdown 移除，且无法自动恢复。继续吗？'))return;try{await applyTaskMutation({operation:'delete',task_id:id},'已从有效清单移除；Obsidian 将在后台写回。')}catch(error){taskStatus(error.message,true)}}
function rcStatus(message,bad=false){const el=$('#rcStatus');el.textContent=message;el.classList.toggle('bad',bad)}
function rcGroupLabel(status){return status==='active'?'当前影响中':status==='upcoming'?'即将开始':status==='needs_review'?'需要确认':status==='conditional'?'条件性/待确认':status==='ended'?'已经过时':'已归档'}
function rcRow(note){
  const editable=!note.archived;
  const actions=[];
  actions.push(`<button data-rc-edit="${encodeURIComponent(note.id)}">编辑</button>`);
  if(editable&&!note.pinned)actions.push(`<button data-rc-pin="${encodeURIComponent(note.id)}">置顶</button>`);
  if(editable&&note.pinned)actions.push(`<button data-rc-unpin="${encodeURIComponent(note.id)}">取消置顶</button>`);
  if(editable&&(note.status==='conditional'||note.status==='needs_review'))actions.push(`<button data-rc-confirm="${encodeURIComponent(note.id)}">仍然相关</button>`);
  if(editable)actions.push(`<button data-rc-archive="${encodeURIComponent(note.id)}">归档</button>`);
  if(note.archived)actions.push(`<button data-rc-unarchive="${encodeURIComponent(note.id)}">恢复</button>`);
  const badges=[];
  if(note.pinned)badges.push('<span class="rc-badge rc-badge-pin">置顶</span>');
  if(note.status==='needs_review')badges.push('<span class="rc-badge rc-badge-review">需要确认</span>');
  if(note.status==='conditional')badges.push('<span class="rc-badge rc-badge-conditional">取决于外部事件</span>');
  return `<div class="rc-row"><div class="rc-row-copy"><b>${escapeHtml(note.content)}</b><p><span>记录时间：${formatTime(note.created_at)}</span><span>影响时段：${escapeHtml(note.impact_text||'未填写')}</span><span>系统理解：${escapeHtml(note.parse_text||'等待解析')}</span>${badges.join('')}</p></div><div class="rc-row-actions">${actions.join('')}</div></div>`;
}
function renderRecentContext(data){
  state.recentContext.notes=data.notes||[];
  state.recentContext.revision=data.revision;
  const groups={current:[],conditional:[],ended:[],archived:[]};
  (data.notes||[]).forEach(note=>{
    if(note.archived){groups.archived.push(note);return}
    if(note.status==='active'||note.status==='upcoming'){groups.current.push(note);return}
    if(note.status==='conditional'||note.status==='needs_review'){groups.conditional.push(note);return}
    groups.ended.push(note);
  });
  const section=(key,title,emptyText)=>`<section class="rc-group"><div class="rc-group-heading"><h3>${title}</h3><span>${groups[key].length}</span></div>${groups[key].length?groups[key].map(rcRow).join(''):`<p class="rc-empty">${emptyText}</p>`}</section>`;
  $('#rcLists').innerHTML=[
    section('current','当前及即将相关','还没有正在影响或即将开始的动态。'),
    section('conditional','需要确认','没有需要人工确认的动态。'),
    section('ended','已经过时','没有已过时的动态。已过时不会被删除，也不会进入 AI 判断。'),
    section('archived','已归档','没有已归档的动态。')
  ].join('');
  $$('[data-rc-edit]').forEach(b=>b.onclick=()=>editRecentContext(decodeURIComponent(b.dataset.rcEdit)));
  $$('[data-rc-pin]').forEach(b=>b.onclick=ev=>rcMutate(decodeURIComponent(b.dataset.rcPin),'pin',ev.currentTarget));
  $$('[data-rc-unpin]').forEach(b=>b.onclick=ev=>rcMutate(decodeURIComponent(b.dataset.rcUnpin),'unpin',ev.currentTarget));
  $$('[data-rc-confirm]').forEach(b=>b.onclick=ev=>rcMutate(decodeURIComponent(b.dataset.rcConfirm),'confirm',ev.currentTarget));
  $$('[data-rc-archive]').forEach(b=>b.onclick=ev=>rcMutate(decodeURIComponent(b.dataset.rcArchive),'archive',ev.currentTarget));
  $$('[data-rc-unarchive]').forEach(b=>b.onclick=ev=>rcMutate(decodeURIComponent(b.dataset.rcUnarchive),'unarchive',ev.currentTarget));
}
async function loadRecentContext(){try{renderRecentContext(await api('/api/recent-context'));rcStatus('已与 Pi 同步。')}catch(error){rcStatus(error.message,true)}}
function clearRecentContextForm(){state.recentContext.editingId=null;$('#rcContent').value='';$('#rcImpact').value='';$('#rcSave').textContent='记录'}
function editRecentContext(id){
  const note=(state.recentContext.notes||[]).find(n=>n.id===id);
  if(!note)return;
  state.recentContext.editingId=id;
  $('#rcContent').value=note.content;
  $('#rcImpact').value=note.impact_text||'';
  $('#rcSave').textContent='保存修改';
  rcStatus(`正在编辑 ${note.id}；保存时会用当前 revision 做冲突检测。`);
}
async function saveRecentContext(){
  const content=$('#rcContent').value.trim();
  if(!content){rcStatus('请先写动态内容。',true);return}
  const editing=state.recentContext.editingId;
  const button=$('#rcSave');button.disabled=true;
  const body={content,impact_text:$('#rcImpact').value.trim(),expected_revision:state.recentContext.revision};
  try{
    if(editing){
      await api(`/api/recent-context/${encodeURIComponent(editing)}/update`,{method:'POST',body:JSON.stringify(body)});
      rcStatus('修改已保存；系统正在重新解析影响时段。');
    }else{
      await api('/api/recent-context',{method:'POST',body:JSON.stringify(body)});
      rcStatus('已记录；系统正在解析影响时段。');
    }
    clearRecentContextForm();
    await loadRecentContext();
  }catch(error){
    if(error.status===409){
      // Keep the local draft; do NOT clear or overwrite.
      rcStatus('这条动态在别处刚被修改过。已刷新服务器版本，请确认后再保存。',true);
      await loadRecentContext();
    }else{
      rcStatus(`保存失败：${error.message}`,true);
    }
  }finally{button.disabled=false}
}
async function rcMutate(id,action,button){
  if(!button)return;button.disabled=true;
  try{
    await api(`/api/recent-context/${encodeURIComponent(id)}/${action}`,{method:'POST',body:JSON.stringify({expected_revision:state.recentContext.revision})});
    await loadRecentContext();
  }catch(error){
    if(error.status===409){rcStatus('内容刚被修改，已刷新版本，请重试。',true);await loadRecentContext()}
    else rcStatus(`${action} 失败：${error.message}`,true);
  }finally{button.disabled=false}
}
function renderNextActionContext(data){
  const items=(data.items||[]).slice(0,3);
  $('#nextActionContextList').innerHTML=items.length?items.map(item=>`<div class="rc-context-item"><p>${escapeHtml(item.content)}</p><small>影响时段：${escapeHtml(item.impact_text||'未填写')} · ${escapeHtml(item.parse_text||'')}</small></div>`).join(''):'<p class="setting-help">暂时没有需要纳入判断的近期动态。</p>';
}
async function loadNextActionContext(){try{renderNextActionContext(await api('/api/recent-context/relevant'))}catch(error){$('#nextActionContextList').innerHTML=`<p class="setting-help">${escapeHtml(error.message)}</p>`}}
async function loadNextActionPanel(){if(!restoreNextActionGeneration())await loadNextActionActive();await Promise.all([loadNextActionReports(),loadNextActionIssues(),loadNextActionContext()])}
function openPlant(id){openPlantTabbed(id)}
function closePlant(){$('#plantModal').classList.add('hidden');state.selectedReward=null;state.selectedSpecies=null;state.plantMode='basic'}
function bindGardenPlantTips(){const grid=$('#gardenGrid');if(!grid)return;const closeAll=()=>$$('.garden-plant.is-tip-open').forEach(plant=>{plant.classList.remove('is-tip-open');plant.setAttribute('aria-expanded','false')});const toggle=plant=>{const open=plant.classList.contains('is-tip-open');closeAll();if(!open){plant.classList.add('is-tip-open');plant.setAttribute('aria-expanded','true')}};grid.addEventListener('click',event=>{const plant=event.target.closest('.garden-plant');if(plant){event.stopPropagation();toggle(plant)}else closeAll()});document.addEventListener('click',event=>{if(!event.target.closest('#gardenIsland'))closeAll()})}
async function plant(){try{$('#plantConfirm').disabled=true;const exchange=state.plantMode==='advanced-exchange',directAdvanced=!exchange&&state.data.reward_history.find(r=>r.id===state.selectedReward)?.tier==='advanced';await api(exchange?'/api/rewards/advanced-plant':`/api/rewards/${encodeURIComponent(state.selectedReward)}/plant`,{method:'POST',body:JSON.stringify({species_id:state.selectedSpecies})});closePlant();await load();toast(exchange?'已消耗 3 次初级机会，种下高级植物！':directAdvanced?'每日挑战奖励已种成高级植物！':'初级植物已经种下了');navigate('garden')}catch(e){toast(e.message,true);$('#plantConfirm').disabled=false}}
async function load(){state.data=await api('/api/bootstrap');render();if(state.page==='settings')loadSystemStatus()}
async function sync(){const btn=$('#syncBtn');btn.classList.add('loading');$('#syncText').textContent='同步中';try{const result=await api('/api/rewards/sync',{method:'POST',body:'{}'});await load();toast(result.inserted?`新增 ${result.inserted} 份奖励`:'奖励已是最新')}catch(e){toast(e.message,true)}finally{btn.classList.remove('loading');$('#syncText').textContent='同步奖励'}}
function bind(){$$('.nav-item').forEach(b=>b.onclick=()=>navigate(b.dataset.page));$$('[data-go]').forEach(b=>b.onclick=()=>navigate(b.dataset.go));$('#menuBtn').onclick=()=>$('#sidebar').classList.toggle('open');$('#syncBtn').onclick=sync;$('#modalClose').onclick=closePlant;$('#plantModal').onclick=e=>{if(e.target.id==='plantModal')closePlant()};$('#plantConfirm').onclick=plant;$('#plantBasicMenu').onclick=openBasicPlanting;$('#plantAdvancedMenu').onclick=openAdvancedPlanting;$$('#presetRow button').forEach(b=>b.onclick=()=>{$$('#presetRow button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');state.minutes=Number(b.dataset.minutes);updateIdleTimer()});$$('.period-tabs button').forEach(b=>b.onclick=()=>{$$('.period-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.period=b.dataset.period;renderGarden()});$('#nextActionGenerate').onclick=()=>generateNextAction();$('#nextActionLoad').onclick=loadNextActionActive;$('#nextActionLoginBtn').onclick=loginNextAction;$('#nextActionAccept').onclick=()=>saveNextActionResponse('accepted');$('#nextActionClarify').onclick=openNextActionClarification;$('#nextActionClarifySubmit').onclick=submitNextActionClarification;$('#nextActionAlternative').onclick=()=>{$('#nextActionReasonBox').classList.remove('hidden');state.nextAction.pendingResponse='alternative_requested'};$('#nextActionDecline').onclick=()=>{$('#nextActionReasonBox').classList.remove('hidden');state.nextAction.pendingResponse='declined'};$('#nextActionReasonSubmit').onclick=()=>saveNextActionResponse(state.nextAction.pendingResponse,true);$$('[data-next-outcome]').forEach(button=>button.onclick=()=>saveNextActionOutcome(button.dataset.nextOutcome));$('#nextActionReportSubmit').onclick=submitNextActionReportFeedback;$('#nextActionIssueSubmit').onclick=submitNextActionIssue;$('#scheduleBtn').onclick=createSchedule;$('#cycleBtn').onclick=createContinuousFocus;$('#taskSave').onclick=saveTask;$('#taskClear').onclick=clearTaskForm;$('#taskRefresh').onclick=loadTasks;$$('[data-task-view]').forEach(button=>button.onclick=()=>setTaskView(button.dataset.taskView));$$('[data-calendar-mode]').forEach(button=>button.onclick=()=>setCalendarMode(button.dataset.calendarMode));$('#rcSave').onclick=saveRecentContext;$('#rcRefresh').onclick=loadRecentContext}
bind();$('#calendarModalClose').onclick=()=>closeCalendarDayModal();$('#calendarModal').onclick=event=>{if(event.target.id==='calendarModal')closeCalendarDayModal()};document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('#calendarModal').classList.contains('hidden'))closeCalendarDayModal()});$('#systemStatusRefresh').onclick=loadSystemStatus;bindGardenPlantTips();load().then(()=>sync()).catch(e=>toast(e.message,true));

// The main action is deliberately dual-device.  Single-device execution is
// available only from the small "more" menu, never from shadow intervention.
state.targets=['windows','phone'];
state.focusTask=null;
function focusTargetLabel(){const labels={windows:'\u7535\u8111',phone:'\u624b\u673a'};return state.targets.length?state.targets.map(x=>labels[x]).join('\uff0b'):'\u4e0d\u9501\u673a'}
function setFocusTask(task){state.focusTask=task||null;const label=task?(task.title||'\u672a\u547d\u540d\u4efb\u52a1'):'\u4e0d\u5173\u8054\u4efb\u52a1';$('#focusTaskPicker').querySelector('span').textContent=label;$('#focusTaskPanel').classList.add('hidden')}
function focusTaskOptions(effective){const groups=effective?.tasks||{},items=['overdue','today','near_term','later','recurring'].flatMap(group=>groups[group]||[]);const seen=new Set(),chosen=[];for(const task of items){if(!task?.task_id||seen.has(task.task_id))continue;seen.add(task.task_id);chosen.push(task);if(chosen.length>=10)break}const list=$('#focusTaskList');if(!chosen.length){list.innerHTML='<p>\u6682\u65e0\u53ef\u5173\u8054\u7684\u5f85\u529e\u3002</p>';return}list.innerHTML=chosen.map(task=>`<button class="focus-task-choice" type="button" data-focus-task="${encodeURIComponent(task.task_id)}"><b>${escapeHtml(task.title||'\u672a\u547d\u540d\u4efb\u52a1')}</b><small>${task.tomatoes_total!=null?`\ud83c\udf45 ${task.tomatoes_completed||0}/${task.tomatoes_total}`:'\u672a\u8bbe \ud83c\udf45 \u9884\u4f30\uff0c\u4ec5\u8bb0\u5f55\u5173\u8054'}</small></button>`).join('');$$('[data-focus-task]').forEach(button=>button.onclick=()=>{const id=decodeURIComponent(button.dataset.focusTask);setFocusTask(chosen.find(task=>task.task_id===id)||null)})}
async function openFocusTaskPicker(){const panel=$('#focusTaskPanel');panel.classList.toggle('hidden');if(panel.classList.contains('hidden'))return;try{focusTaskOptions(await api('/api/tasks'))}catch(error){$('#focusTaskList').innerHTML=`<p>\u4efb\u52a1\u6682\u4e0d\u53ef\u7528\uff1a${escapeHtml(error.message)}</p>`}}
startFocusWithTargets=async function(){const duration=state.minutes,destination=focusTargetLabel(),task=state.focusTask,association=task?`\n\u5173\u8054\u4efb\u52a1\uff1a${task.title||'\u672a\u547d\u540d\u4efb\u52a1'}`:'\n\u4e0d\u5173\u8054\u4efb\u52a1',lockNote=state.targets.length?'\u5df2\u5f00\u59cb\u7684\u9501\u5b9a\u901a\u5e38\u65e0\u6cd5\u63d0\u524d\u89e3\u9664\u3002':'\u672c\u6b21\u4ec5\u8ba1\u65f6\uff0c\u4e0d\u4f1a\u9501\u5b9a\u8bbe\u5907\u3002';if(!confirm(`\u5c06\u5f00\u59cb ${duration} \u5206\u949f\u4e13\u6ce8\uff0c${destination}\u3002${association}\n${lockNote}\n\u662f\u5426\u7ee7\u7eed\uff1f`))return;try{$('#startBtn').disabled=true;await api('/api/focus/start',{method:'POST',body:JSON.stringify({duration,profile_id:$('#profileSelect').value,targets:state.targets,task_id:task?.task_id||null,task_title:task?.title||null,source:'garden'})});await load();toast(`\u4e13\u6ce8\u5df2\u5165\u56ed\uff1a${destination}${task?' \u00b7 \u5df2\u5173\u8054\u4efb\u52a1':''}`)}catch(error){toast(error.message,true)}finally{$('#startBtn').disabled=false}}
async function startFocusWithTargets(){
  const duration=state.minutes;
  const labels={windows:'电脑',phone:'手机'};
  const destination=state.targets.map(x=>labels[x]).join('＋');
  if(!confirm(`将开始 ${duration} 分钟专注，并介入：${destination}。已开始的锁定通常无法提前解除。是否继续？`))return;
  try{
    $('#startBtn').disabled=true;
    await api('/api/focus/start',{method:'POST',body:JSON.stringify({duration,profile_id:$('#profileSelect').value,targets:state.targets})});
    await load();toast(`专注已入队：${destination}`);
  }catch(error){toast(error.message,true)}finally{$('#startBtn').disabled=false}
}
async function createSchedule(){
  const raw=$('#scheduleAt').value;
  if(!raw){toast('请先选择预约开始时间',true);return}
  const startsAt=new Date(raw).toISOString();
  if(!confirm(`预约在 ${raw.replace('T',' ')} 开始 ${state.minutes} 分钟专注，并介入当前所选设备。是否继续？`))return;
  try{await api('/api/focus/schedule',{method:'POST',body:JSON.stringify({duration:state.minutes,profile_id:$('#profileSelect').value,targets:state.targets,starts_at:startsAt})});await load();toast('预约专注已创建')}catch(error){toast(error.message,true)}
}
async function createContinuousFocus(){
  const focusMinutes=Number($('#cycleFocusMinutes').value),restMinutes=Number($('#cycleRestMinutes').value),rounds=Number($('#cycleRounds').value);
  if(!confirm(`将开始 ${rounds} 轮：每轮专注 ${focusMinutes} 分钟，休息 ${restMinutes} 分钟。休息时不会解除已经开始的锁定。是否继续？`))return;
  try{await api('/api/focus/continuous',{method:'POST',body:JSON.stringify({focus_minutes:focusMinutes,rest_minutes:restMinutes,rounds,profile_id:$('#profileSelect').value,targets:state.targets})});await load();toast('连续专注已创建，第一轮即将开始')}catch(error){toast(error.message,true)}
}
$('#startBtn').onclick=startFocusWithTargets;
$('#targetMore').onclick=()=>$('#targetMenu').classList.toggle('hidden');
$('#focusTaskPicker').onclick=openFocusTaskPicker;
$('#focusTaskClear').onclick=()=>setFocusTask(null);
$$('[data-focus-target]').forEach(button=>button.onclick=()=>{
  state.targets=button.dataset.focusTarget?button.dataset.focusTarget.split(','):[];
  $('#targetMenu').classList.add('hidden');
  $('#startBtn').textContent=state.targets.length===2?'开始专注 · 电脑＋手机':`开始专注 · 仅${state.targets[0]==='windows'?'电脑':'手机'}`;
});

function controlDate(value){
  if(!value)return '尚未冻结';
  const parsed=new Date(value);
  return Number.isNaN(parsed.getTime())?'尚未冻结':parsed.toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
}
function controlMetricValue(value){
  if(value===null||value===undefined||Number.isNaN(Number(value)))return '—';
  const numeric=Number(value);
  return Number.isInteger(numeric)?String(numeric):numeric.toFixed(1);
}
async function syncControlStatus(){
  const button=$('#controlSyncBtn');
  if(!button)return;
  button.disabled=true;
  button.textContent='同步中…';
  try{
    const control=await api('/api/control/sync',{method:'POST',body:'{}'});
    state.systemStatus={...(state.systemStatus||{}),control};
    renderSystemStatus();
    toast(control.snapshot_state==='synced_live'?'状态数据已同步，本周决策保持冻结':'状态数据已同步，等待下次周评审');
  }catch(error){
    toast(`状态同步失败：${error.message}`,true);
  }finally{
    const current=$('#controlSyncBtn');
    if(current){current.disabled=false;current.textContent='同步状态'}
  }
}
function renderControlReview(control){
  const root=$('#controlReview');
  if(!root)return;
  if(!control||!control.state){
    root.innerHTML='<article class="pixel-panel control-state-card control-tone-unknown"><div class="control-state-code">S?</div><div class="control-state-copy"><p class="eyebrow">WEEKLY CONTROL</p><h2>控制快照尚未生成</h2><p>每日推迟债务与周级基线正在建立；现有硬规则不会因此改变。</p></div></article>';
    return;
  }
  const snapshot=control.snapshot_state==='frozen'?'已冻结':control.snapshot_state==='synced_live'?'数据已同步 · 决策冻结':control.snapshot_state==='synced_preview'?'数据已同步 · 待周评审':'临时预览';
  const tone=['stable','plan','attention','risk','unknown'].includes(control.state.tone)?control.state.tone:'unknown';
  const evidence=(control.state.evidence||[]).slice(0,3).map(item=>`<li>${escapeHtml(item)}</li>`).join('')||'<li>没有触发显著变化阈值。</li>';
  const qualityLabels={high:'可靠',medium:'代理',low:'低样本',collecting:'积累中'};
  const metrics=(control.metrics||[]).map(metric=>{
    const quality=['high','medium','low','collecting'].includes(metric.quality)?metric.quality:'low';
    const baseline=metric.baseline===null||metric.baseline===undefined?'基线积累中':`基线 ${controlMetricValue(metric.baseline)} ${escapeHtml(metric.unit||'')}`;
    const delta=metric.delta_percent===null||metric.delta_percent===undefined?'':` · ${Number(metric.delta_percent)>=0?'+':''}${controlMetricValue(metric.delta_percent)}%`;
    return`<article class="control-metric"><div class="control-metric-head"><span class="control-metric-id">${escapeHtml(metric.id||'?')}</span><span class="control-quality quality-${quality}">${qualityLabels[quality]}</span></div><h3>${escapeHtml(metric.label||'未命名指标')}</h3><div class="control-metric-value">${controlMetricValue(metric.value)} <small>${escapeHtml(metric.unit||'')}</small></div><p class="control-metric-compare">${baseline}${delta}</p><p class="control-metric-coverage">${escapeHtml(metric.role||'诊断')} · ${escapeHtml(metric.coverage||'未提供覆盖说明')}</p></article>`;
  }).join('');
  const ai=control.ai||{},windowData=control.window||{},currentWindow=windowData.current||{},baselineWindow=windowData.baseline||{},policy=control.policy||{};
  root.innerHTML=`<article class="pixel-panel control-state-card control-tone-${tone}"><div class="control-state-code">${escapeHtml(control.state.code||'S?')}</div><div class="control-state-copy"><p class="eyebrow">WEEKLY CONTROL · ${snapshot}</p><h2>${escapeHtml(control.state.name||'未判定')}</h2><p>${escapeHtml(control.state.summary||'')}</p></div><div class="control-freeze"><small>策略冻结至</small><b>${controlDate(control.frozen_until)}</b><button id="controlSyncBtn" class="control-sync-button" type="button" title="重新汇总当前指标并更新今日 D；不会改写冻结中的周结论">同步状态</button></div></article><div class="control-decision-row"><article class="pixel-panel control-adjustment"><p class="eyebrow">ONE CHANGE ONLY</p><h3>本周期唯一调整</h3><p>${escapeHtml(control.state.single_adjustment||'本周期不调整核心参数。')}</p></article><article class="pixel-panel control-evidence"><p class="eyebrow">EVIDENCE</p><h3>识别证据</h3><ol>${evidence}</ol></article></div><div class="control-metrics">${metrics||'<article class="pixel-panel control-empty">还没有主指标。</article>'}</div><div class="control-aux"><article class="pixel-panel control-ai"><p class="eyebrow">AI STRUCTURE · 辅助诊断</p><h3>AI 用途结构</h3><div class="control-ai-values"><span>任务相关<b>${controlMetricValue(ai.task_minutes)} min</b></span><span>游离使用<b>${controlMetricValue(ai.free_minutes)} min</b></span><span>未判定<b>${controlMetricValue(ai.unknown_minutes)} min</b></span></div></article><article class="pixel-panel control-policy"><p class="eyebrow">CONTROL BOUNDARY</p><h3>控制边界</h3><p>${escapeHtml(policy.note||'只读识别；不自动改变硬规则。')}</p></article></div><p class="control-window">当前 ${escapeHtml(currentWindow.start||'—')}—${escapeHtml(currentWindow.end||'—')}（${Number(currentWindow.report_days||0)}/7 日报） · 基线 ${escapeHtml(baselineWindow.start||'—')}—${escapeHtml(baselineWindow.end||'—')}（${Number(baselineWindow.report_days||0)} 日报）${control.synced_at?` · 最近同步 ${controlDate(control.synced_at)}`:''}</p>`;
  const syncButton=$('#controlSyncBtn');
  if(syncButton)syncButton.onclick=syncControlStatus;
}
const renderOperationalSystemStatus=renderSystemStatus;
renderSystemStatus=function(){renderOperationalSystemStatus();renderControlReview(state.systemStatus?.control)};
