from __future__ import annotations

from datetime import datetime
from statistics import median
from typing import Any
from zoneinfo import ZoneInfo

from common import parse_timestamp, rounded_minutes


def _intervals(
    timeline: list[dict[str, Any]],
    key: str,
    expected: str,
    timezone_name: str,
) -> list[tuple[float, float]]:
    result: list[tuple[float, float]] = []
    for item in timeline:
        if item.get(key) != expected:
            continue
        start = parse_timestamp(item["start"], timezone_name).timestamp()
        end = parse_timestamp(item["end"], timezone_name).timestamp()
        if end > start:
            result.append((start, end))
    return result


def _overlap_seconds(
    left: list[tuple[float, float]], right: list[tuple[float, float]]
) -> float:
    return sum(
        max(0.0, min(left_end, right_end) - max(left_start, right_start))
        for left_start, left_end in left
        for right_start, right_end in right
        if left_start < right_end and left_end > right_start
    )


def _union_seconds(intervals: list[tuple[float, float]]) -> float:
    merged: list[list[float]] = []
    for start, end in sorted(intervals):
        if end <= start:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return sum(end - start for start, end in merged)


def _intersection_intervals(
    left: list[tuple[float, float]], right: list[tuple[float, float]]
) -> list[tuple[float, float]]:
    intersections = [
        (max(left_start, right_start), min(left_end, right_end))
        for left_start, left_end in left
        for right_start, right_end in right
        if left_start < right_end and left_end > right_start
    ]
    merged: list[list[float]] = []
    for start, end in sorted(intersections):
        if end <= start:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [(start, end) for start, end in merged]


def _confirmed_rest_intervals(
    computer_afk: list[tuple[float, float]],
    phone_off: list[tuple[float, float]],
    minimum_seconds: float,
) -> list[tuple[float, float]]:
    return [
        (start, end)
        for start, end in _intersection_intervals(computer_afk, phone_off)
        if end - start >= minimum_seconds
    ]


def _computer_context_metrics(
    timeline: list[dict[str, Any]], timezone_name: str
) -> dict[str, Any]:
    meaningful = [
        item for item in timeline if float(item.get("duration_seconds", 0)) >= 5
    ]
    durations = [float(item["duration_seconds"]) for item in meaningful]
    switch_count = max(0, len(meaningful) - 1)
    active_seconds = sum(durations)
    context_blocks = [
        {
            "start": item["start"],
            "end": item["end"],
            "minutes": rounded_minutes(float(item["duration_seconds"])),
            "app": item.get("app_display", ""),
            "title": item.get("title", ""),
            "domain": item.get("domain", ""),
        }
        for item in meaningful
    ]
    return {
        "minimum_context_seconds": 5,
        "meaningful_context_blocks": len(meaningful),
        "context_switch_count": switch_count,
        "switches_per_active_hour": round(
            switch_count / active_seconds * 3600, 2
        )
        if active_seconds
        else 0.0,
        "short_context_blocks_under_60_seconds": sum(
            duration < 60 for duration in durations
        ),
        "sustained_context_blocks_at_least_5_minutes": sum(
            duration >= 300 for duration in durations
        ),
        "longest_context_minutes": rounded_minutes(max(durations, default=0.0)),
        "median_context_minutes": rounded_minutes(median(durations))
        if durations
        else 0.0,
        "context_blocks": context_blocks,
        "interpretation_note": (
            "这些是前台电脑上下文的客观切换指标；切换次数不直接等于分心。"
        ),
    }


def compare_devices(
    computer: dict[str, Any],
    phone: dict[str, Any],
    settings: dict[str, Any],
    tablet: dict[str, Any] | None = None,
) -> dict[str, Any]:
    timezone_name = settings["timezone"]
    computer_active = _intervals(
        computer.get("status_timeline", []), "status", "not-afk", timezone_name
    )
    computer_afk = _intervals(
        computer.get("status_timeline", []), "status", "afk", timezone_name
    )
    phone_on = _intervals(
        phone.get("screen_timeline", []), "state", "on", timezone_name
    )
    phone_off = _intervals(
        phone.get("screen_timeline", []), "state", "off", timezone_name
    )
    tablet_on: list[tuple[float, float]] = []
    tablet_off: list[tuple[float, float]] = []
    tablet_on_minutes: float = 0.0
    tablet_off_minutes: float = 0.0
    if tablet is not None:
        tablet_on = _intervals(
            tablet.get("screen_timeline", []), "state", "on", timezone_name
        )
        tablet_off = _intervals(
            tablet.get("screen_timeline", []), "state", "off", timezone_name
        )
        tablet_on_minutes = tablet.get("screen", {}).get("on_minutes", 0) if tablet else 0.0
        tablet_off_minutes = tablet.get("screen", {}).get("off_minutes", 0) if tablet else 0.0
    period_start = parse_timestamp(computer["period"]["start"], timezone_name)
    period_end = parse_timestamp(computer["period"]["end"], timezone_name)
    period_seconds = (period_end - period_start).total_seconds()
    any_device_interaction_seconds = _union_seconds(computer_active + phone_on)
    # Tablet is auxiliary: screen-on does not equal active interaction
    tablet_context_seconds = _union_seconds(tablet_on)

    rest_rules = settings.get("state_rules", {})
    rest_minimum_seconds = float(
        rest_rules.get("rest_minimum_continuous_inactive_seconds", 180)
    )
    primary_inactive = _intersection_intervals(computer_afk, phone_off)
    confirmed_rest = _confirmed_rest_intervals(
        computer_afk,
        phone_off,
        rest_minimum_seconds,
    )
    # Likely rest: primary devices inactive (tablet may still be on)
    likely_rest_intervals = [
        (s, e) for s, e in primary_inactive
        if e - s >= rest_minimum_seconds
    ]
    likely_rest_seconds = _union_seconds(likely_rest_intervals)

    timezone = ZoneInfo(timezone_name)
    confirmed_rest_seconds = _union_seconds(confirmed_rest)

    return {
        "schema_version": 3,
        "source": "deterministic_cross_device_overlap",
        "period": computer["period"],
        "tablet": {
            "connected": tablet is not None,
            "screen_on_seconds": _union_seconds(tablet_on),
            "screen_off_seconds": _union_seconds(tablet_off),
            "confidence": "low",
            "note": "平板为辅助数据源。亮屏不等于确认使用。",
        },
        "time_accounting_observed": {
            "period_minutes": rounded_minutes(period_seconds),
            "computer_not_afk_minutes": computer.get("activity", {}).get(
                "not_afk_minutes", 0
            ),
            "computer_afk_minutes": computer.get("activity", {}).get(
                "afk_minutes", 0
            ),
            "phone_screen_on_minutes": phone.get("screen", {}).get(
                "on_minutes", 0
            ),
            "tablet_screen_on_minutes": tablet_on_minutes,
            "any_device_interaction_minutes": rounded_minutes(
                any_device_interaction_seconds
            ),
            "no_detected_device_interaction_minutes": rounded_minutes(
                max(0.0, period_seconds - any_device_interaction_seconds)
            ),
            "likely_rest_minutes": rounded_minutes(likely_rest_seconds),
            "confirmed_rest_minutes": rounded_minutes(confirmed_rest_seconds),
            "note": (
                "any_device_interaction_minutes基于电脑活跃和手机亮屏的并集。"
                "平板亮屏不加入主要交互时间。"
                "likely_rest_minutes基于电脑AFK且手机熄屏（平板亮屏不否决休息，仅降低置信度）。"
            ),
        },
        "rest_rule": {
            "minimum_continuous_inactive_seconds": rest_minimum_seconds,
            "primary_devices_evaluated": ["computer", "phone"],
            "tablet_role": "auxiliary_context_only",
            "condition": (
                "电脑连续AFK达到阈值，且手机熄屏。"
                "平板亮屏不否决休息，仅降低置信度。"
            ),
            "likely_rest_intervals": [
                {
                    "start": datetime.fromtimestamp(start, timezone).isoformat(
                        timespec="seconds"
                    ),
                    "end": datetime.fromtimestamp(end, timezone).isoformat(
                        timespec="seconds"
                    ),
                    "minutes": rounded_minutes(end - start),
                    "tablet_on_during": any(
                        s < end and e > start for s, e in tablet_on
                    ),
                }
                for start, end in likely_rest_intervals
            ],
            "confirmed_rest_intervals": [
                {
                    "start": datetime.fromtimestamp(start, timezone).isoformat(
                        timespec="seconds"
                    ),
                    "end": datetime.fromtimestamp(end, timezone).isoformat(
                        timespec="seconds"
                    ),
                    "minutes": rounded_minutes(end - start),
                }
                for start, end in confirmed_rest
            ],
        },
        "computer_fragmentation_metrics": _computer_context_metrics(
            computer.get("timeline", []), timezone_name
        ),
        "overlap_minutes": {
            "computer_not_afk_and_phone_on": rounded_minutes(
                _overlap_seconds(computer_active, phone_on)
            ),
            "computer_afk_and_phone_on": rounded_minutes(
                _overlap_seconds(computer_afk, phone_on)
            ),
            "computer_not_afk_and_phone_off": rounded_minutes(
                _overlap_seconds(computer_active, phone_off)
            ),
            "computer_afk_and_phone_off": rounded_minutes(
                _overlap_seconds(computer_afk, phone_off)
            ),
        },
        "limitations": [
            "这里只计算时间重叠，不推断分心、休息或行为动机。",
            "休息由用户确认的跨设备无操作规则确定；工作和其他活动仍由AI结合上下文估计。",
            "平板为辅助数据源：亮屏不等于确认活动，不加入主要交互时间。",
            "likely_rest基于电脑AFK且手机熄屏；平板亮屏降低置信度但不否决休息。",
        ],
    }
