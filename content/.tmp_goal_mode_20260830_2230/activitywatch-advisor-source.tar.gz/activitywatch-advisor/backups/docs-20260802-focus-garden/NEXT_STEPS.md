# Next Steps

1. 人工完成并核验 Syncthing 的 Send Only / Receive Only 文件夹配置。
2. 安装 Windows 定时导出任务，通过 PushPlus 观察至少 3 天影子候选。
3. 检查正常数学学习、持续知乎、合理休息和上下文回退样本。
4. 检查每日 09:00/10:00/11:00 睡眠边界重试和周一 09:05 的统计消息是否足够清晰。
5. 只有人工确认误报可接受后，另行设计并启用正式有限提醒；当前不要关闭 shadow mode。
6. 积累数据后复核现有 60 分钟预筛选，并扩展到 120 分钟历史与正式冷却期。
7. 完整版验收时确认全设备无活动路径仍不调用 AI，但归档没有中断。
8. 用手机桌面快捷方式提交一条真实异常反馈，并在
   `data/user_annotations/UNREVIEWED.md` 与当日 `data/user_annotations/daily/YYYY-MM-DD.md`
   核对记录。
9. 人工复核若确认反馈已处理，再另行设计显式的 status 更新流程；当前不要自动改状态。
10. 把 `https://pi.taild4d3f7.ts.net:8450` 添加到手机桌面，连续试用“下一步”建议；
    重点观察建议解释是否足够说服、反馈原因是否方便填写。
11. 下一步建议第一版只记录手动执行结果；不要启用自动执行观察，除非先定义清晰的
    “设备行为只能作为可能证据、不能覆盖用户反馈”的规则。
# 2026-07-29 Next Steps 补充

1. 将 `https://pi.taild4d3f7.ts.net:8450` 添加到手机桌面，连续试用“下一步”按钮。
2. 重点观察建议文本是否真的能说服用户开始行动，而不只是给出正确但冷冰冰的命令。
3. 对“换一个”“现在不做”尽量填写原因和一句具体说明，用于后续分析建议失败原因。
4. 暂时不要启用自动执行观察；第一版只使用用户手动结果：完成了、正在做、没开始。
5. 连续使用一到两周后，再决定是否加入“根据下一份半小时报告做弱关联观察”的第二版执行观察。
6. 检查 09:00/10:00/11:00 日报重试是否符合真实起床情况，尤其是 10:00 前仍未醒时是否正确 pending。
7. 如果网页反馈足够顺手，再考虑为 `data/user_annotations/UNREVIEWED.md` 增加人工 review/status 更新界面；当前不要让 AI 自动改 raw JSON 或配置。
8. 后续若修改建议 prompt，必须保留“工作建议匹配当天任务”“不回写 Obsidian”“不自动干预”三条硬约束。
# 2026-07-29 Next Action v1.1 试用事项

1. 在 12:00-13:00 主动点一次“下一步”，确认系统推荐吃饭/午休而不是学习任务。
2. 观察建议语言是否更像“帮我启动”的助手，而不是通用生产力文案。
3. 特别检查番茄钟表述：应使用“预估还剩”“记录显示接近收尾”，不得使用“只剩一个番茄即可完成”。
4. 暂时不拆分大任务标题；如果仍然觉得建议复读标题，后续再考虑给任务增加 `next_step` 字段。
# 2026-07-29 Next Action thinking/trace 后续观察

- 连续试用几次 Next Action，检查 thinking 开启后建议是否更稳、更少粗糙复读任务标题。
- 如果出现空响应或超时，优先调低输出要求或把 `decision_model.max_tokens` 继续提高，而不是立刻关闭 thinking。
- 检查 `data/next_action/suggestions/YYYY-MM-DD/*.json` 中的 `decision_trace` 是否足够解释选择依据。
- 仍不要保存完整思维链草稿；只保留审计摘要。
# 2026-07-29 Next Action public Funnel follow-up

- Test `https://pi.taild4d3f7.ts.net:10000` from the phone with Clash Meta enabled and Tailscale disabled.
- If login state is lost often, consider extending cookie duration or using a stronger token-based login.
- If unwanted traffic appears in logs, add rate limiting before keeping the Funnel entry long-term.
- Do not expose Cockpit, File Browser, Monaco Lite, SSH, or raw data folders through Funnel.
## 2026-07-30 后续事项：问题反馈 backlog

### 1. 从手机提交一条真实问题反馈

打开 Next Action Web，进入“问题反馈”，提交一条真实或半真实问题，确认网页显示成功，并能在最近问题列表中看到。

### 2. 积累后交给 Codex 批处理

之后可以直接要求：

```text
使用 pi-ops-system-context，处理 Next Action 网页问题反馈 backlog
```

Codex 应从：

```text
data/issue_feedback/UNREVIEWED.md
```

开始，先聚类，再决定是否修改规则、prompt、网页、接口或文档。

### 3. 观察 skill 是否足够“听懂”

如果后续 Codex 仍需要反复询问系统架构，继续补充 `pi-ops-system-context` 的 reading routes 和 service map。
