# 2026-07-31 影子干预确认休息阈值

- 单个半小时窗口只有 `confirmed_rest_minutes > 12` 才视为明确休息并豁免影子干预；12 分钟整不豁免。
- 该阈值只影响影子干预及其后续电脑端请求，不改变原始行为事实或半小时 AI 解读。

- 影子介入仅由高刺激严格大于 10 分钟、学习—娱乐—学习有效交替，或深夜娱乐触发；低效、无主线和单纯活跃不再单独触发。
- 有效交替只统计超过 30 秒且确属工作偏离的娱乐段；至少 2 次此类合格工作/娱乐切换才触发。

# Decisions

- Obsidian 是唯一任务权威源；树莓派只读，不回写任务。
- 不要求任务 ID，不建立第二份任务状态，也不要求精确时间表。
- Windows 只负责本地确定性导出；网络传输继续由 Syncthing 完成。
- 番茄钟日志为低置信度参考；缺失不是负面证据，也不用于具体任务归因。
- 番茄钟 `end - begin` 可包含暂停时间；工作量按声明 `duration` 统计，较长墙钟跨度不作负面解释。
- 设备行为和既有事实层优先于 Profile、任务计划和番茄钟。
- 先运行 3—7 天影子模式并人工复核，再考虑有限提醒。
- last-known-good 只保证主流程韧性；陈旧上下文不产生强任务建议。
- 影子判断与原半小时核验合并为一条 PushPlus 消息，避免通知数量翻倍。
- 每日和每周统计独立发送并保存回执；已接受的同周期统计默认不重复发送。
- DeepSeek 输出损坏时保留事实层并生成可见的降级报告，而不是中断归档和通知。
- 电脑无非 AFK 活动且手机、平板无亮屏时，不调用 AI、不发 PushPlus，但继续归档。
- 完整版必须保留上述短路，以节省 token；日报和周报改在 09:00/周一 09:05 发送。
- 手机端异常反馈只提交分类索引和可选说明；时间、编号和上下文关联由树莓派接收端补全。
- `/annotation` 复用现有手机上传 token，但使用 `Authorization: Bearer <token>`；旧 `/upload/`
  的 `X-Upload-Token` 协议不变。
- 人工反馈是调试标注，不直接触发配置修改、任务修改、DeepSeek 调用或自动修复。
- 反馈 raw JSON 永久保留；daily Markdown 和 `UNREVIEWED.md` 是从 raw JSON 原子重建的派生视图。
- 第一版不实现网页处理界面，不自动修改反馈 `status`。
# 2026-07-29 Next Action Web 决策补充

- 新增“下一步行动助手”作为独立系统部件，定位为用户主动请求时的决策入口，不替代半小时行为解读系统。
- 决策状态生成器只在用户点击网页按钮时运行，不做后台自动建议，不做自动推送，不做自动干预。
- 下一步建议使用 `settings.json` 中的 `decision_model`，当前为 `deepseek-v4-pro`；半小时报告主流程仍保持原模型配置。
- AI 输出不再限制为极短命令，而是允许较丰富的说服性解释：行动、时长、第一步、简短理由、数据依据、说服说明、可能阻力、缩小版行动。
- 工作/学习类建议必须匹配当天 Obsidian 任务标题；AI 不得凭空创造新项目，也不得回写 Obsidian Tasks。
- 番茄钟全局解释调整为中等可靠性正向证据：有记录可证明投入过时间；缺失记录不能作为未学习或低效的证据。
- 第一版执行观察只记录用户手动反馈，不根据设备活动自动判定完成、失败或拖延。
- 半小时报告继续通过 PushPlus 推送到微信，同时新增网页查看与网页反馈入口；网页反馈复用 `data/user_annotations/`，与 Automate 反馈同源归档。
- Next Action Web 使用独立 loopback 服务和 tailnet-only Tailscale Serve 入口，不复用公开 Funnel。
- 睡眠日报改为 09:00/10:00/11:00 重试：边界未出现时先 pending，11:00 仍未出现则 possible_fault 后生成低置信日报。
# 2026-07-29 Next Action v1.1 决策补充

- 下一步行动助手版本命名为 `next-action-v1.1`。
- v1.1 优先改进建议语言，而不解决任务标题粒度过大的结构问题。
- 建议语气应有适度亲近感：像熟悉用户节奏的助手，不像训诫者、心理咨询师或鸡汤文案。
- 说服逻辑应降低启动阻力：承认真实阻力、给出低成本第一步、说明短期具体收益；避免羞耻感、道德评价、夸张鼓励和空泛生产力话术。
- 每天 12:00-13:00 固定为吃饭和午休时间；该窗口默认不推荐数学/项目工作，除非用户明确覆盖规则。
- 番茄钟数量是预估任务预算或进度标记，不是完成保证；实际所需番茄可以大于预估，AI 不得说“只剩一个番茄即可完成”。
- 2026-07-29 修正：本系统中 `1 🍅 = 40 分钟`，不是常见 25 分钟。Next Action prompt、状态 JSON 和输出验证器都必须防止把 15/25/30 分钟启动片段称为“一个番茄钟”。
# 2026-07-29 Next Action decision_model thinking

- Next Action 的 `decision_model` 改为 `deepseek-v4-pro` + `thinking=enabled`。
- 因 thinking 会占用更多生成预算，`max_tokens` 调整为 3500，`timeout_seconds` 调整为 90。
- 不保存完整思维链或草稿 JSON；建议归档新增 `decision_trace`，只保存证据、规则、排除项、数据质量提示和模型 thinking 状态。
- `decision_trace.model.full_reasoning_saved` 固定为 `false`，用于区分“可审计摘要”和“隐藏推理链”。
# 2026-07-29 Next Action public Funnel and login

- Next Action Web may be accessed publicly through Tailscale Funnel on `https://pi.taild4d3f7.ts.net:10000`.
- Existing public `443` Funnel remains dedicated to `phone-usage-receiver`; it was not repointed.
- Next Action Web now requires simple password login before serving pages or APIs.
- Login password and cookie signing secret live in `/home/conrad/.config/activitywatch-advisor/web.env`, outside project files and docs.
- Half-hour report web access is limited to the latest 3 reports both in the listing API and in the detail-reading API.
## 2026-07-30 新增决策

### D34. Next Action Web 增加独立“问题反馈”入口【有效】

问题反馈不混入“开始 / 换一个 / 现在不做”执行反馈。它专门记录系统本身的问题，包括 AI 建议质量、数据缺失、网页界面、通知、规则不匹配、安全访问、文档交接和其它异常。

### D35. 问题反馈以 raw JSON 为事实源【有效】

每条反馈先写入 `data/issue_feedback/raw/`，再由程序重建 `daily/*.md` 和 `UNREVIEWED.md`。Markdown 是审阅视图，raw JSON 是事实源。

### D36. 新增 `pi-ops-system-context` Codex skill【有效】

后续涉及树莓派行为顾问系统、Next Action、半小时报告、Automate、Funnel、Obsidian context、番茄钟、睡眠统计或问题反馈 backlog 时，Codex 应先使用该 skill 读取固定运维文档和服务地图，再执行修改。

### D51. 新建议生成必须先完成上一条建议的人工闭环【有效】

当 active suggestion 没有 outcome，且最近 response 不是 `alternative_requested` 或 `declined` 时，`POST /api/next-action` 返回 `409 pending_outcome_required`，不得直接生成并覆盖新建议。网页先展示旧建议，保存“完成了/正在做/没开始”后自动恢复本次生成请求。“开始”仍需后续 outcome；“换一个/现在不做”本身构成关闭响应。

### D52. 主动点击生成按钮是用户已醒的直接证据【有效】

Next Action 由用户主动操作网页触发。该交互证据优先于仍为 pending 的早晨睡眠边界；系统不得询问是否起床或醒来。此规则进入决策状态、模型 prompt 和确定性输出验证器。
## 2026-07-31 电脑端 Cold Turkey 介入决策

- 半小时系统可以从影子候选生成电脑端介入请求，但 Pi 端只负责判断、归档和提供 API，不远程执行任意 Windows 命令。
- Windows agent 以拉取方式获取 pending request，执行前必须用本地 allowlist 校验 block 名；当前仅允许 `常刷网站` 与 `bilibili`。
- 较新的半小时影子候选为“不介入”时，API 必须抑制此前仍在 TTL 内的 pending request；请求文件保留以供审计。
- 用户连续两次点击“不介入”后，第三次仍触发时强制执行 30 分钟 Cold Turkey 介入；点击介入、强制介入成功、agent 判断目标已处于封锁状态、观察到有意义活动恢复或确认休息，都会重置拒绝计数。
- 弹窗超时未响应记为 `ignored`，不计入连续拒绝。
- B 站 block 在周六全天、周日全天、周一 00:00-12:00 Asia/Shanghai 作为备课例外，不执行封锁且不计入拒绝。
- 电脑 ActivityWatch 无活动不阻止介入请求生成；手机/平板沉迷也可以触发电脑端 Cold Turkey 封锁。
