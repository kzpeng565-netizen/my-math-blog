# 2026-07-31 Handoff：影子干预确认休息阈值

- `config/settings.json` 的 `behavior_advisor.confirmed_rest_exemption_minutes` 当前为 `12`。
- 只有单个半小时窗口的 `confirmed_rest_minutes > 12` 才豁免影子干预；恰好 12 分钟不豁免。

- 影子介入触发仅保留：高刺激严格大于 10 分钟、学习—娱乐—学习有效交替，或深夜娱乐；确认休息超过 12 分钟仍豁免。
- 有效交替由 `mixing_metrics.qualified_work_entertainment_transition_count` 确定：仅超过 30 秒的娱乐偏离参与切换计数，至少 2 次才触发。
- 候选 JSON 的 `observations` 记录阈值及 `has_explicit_rest`，便于审计。
# Pi Server Handoff

项目位于 `/home/conrad/workspace/activitywatch-advisor`，Syncthing 接收目录为
`/home/conrad/workspace/behavior-context-sync`。上下文缓存和归档均在项目 `data/`
下，后者已被 Git 忽略。

运行服务前可检查：

```bash
python3 -m unittest discover -s tests -v
systemctl status syncthing@conrad.service --no-pager
systemctl status activitywatch-advisor.timer --no-pager
```

上下文同步文件夹必须为 Receive Only。不要在树莓派编辑同步内容；不要把它放入
`activitywatch-sync`。半小时核验 PushPlus 消息包含 AI 状态解释和影子判断，但
影子判断不会执行干预。每日和每周统计由独立 timer 发送。

AI 状态解释归档在 `data/ai_reports/YYYY-MM-DD/HH-MM.json` 和 `.md`；语义切段、
混杂指标及 PushPlus 回执均有独立目录。DeepSeek 无效 JSON 会使用本地降级报告。

电脑没有非 AFK 活动且手机、平板没有亮屏时，系统不调用 DeepSeek、不发 PushPlus，
但仍写入事实、上下文、本地报告和影子候选。日报 09:00、周报周一 09:05 发送。

手机异常反馈入口复用 `phone-usage-receiver.service` 和 Tailscale Funnel：

```text
POST https://pi.taild4d3f7.ts.net/annotation
Authorization: Bearer <现有手机上传 token>
Content-Type: application/x-www-form-urlencoded

category=0..4
message=可选说明
```

`/upload/` 仍使用原有 `X-Upload-Token`，不要改变手机数据上传协议。`/annotation`
同时支持 JSON 请求体，但手机 Automate 的正式协议是表单提交。反馈保存在
`data/user_annotations/raw/YYYY-MM-DD/<annotation_id>.json`；当日汇总和未处理总表分别是
`data/user_annotations/daily/YYYY-MM-DD.md` 与 `data/user_annotations/UNREVIEWED.md`。
接收器只记录人工调试标注，不调用 DeepSeek，不自动修改任务或配置。

## Next Action Web

私有网页入口为 `https://pi.taild4d3f7.ts.net:8450`，Tailscale Serve tailnet only，
代理到 `activitywatch-advisor-web.service` 的 `127.0.0.1:8767`。公网 Funnel 仍只给
手机上传/annotation 接收器使用。

网页包含两个入口：

- “下一步”：用户点击后才生成决策状态，调用 `settings.json` 中的 `decision_model`
  DeepSeek V4 Pro。建议归档在 `data/next_action/`，包括状态快照、建议、用户响应和
  手动执行结果。第一版执行观察只做手动回填，不自动根据设备活动判定完成。
- “半小时报告”：读取 `data/ai_reports/` 的归档报告，并可提交报告反馈。该反馈复用
  `data/user_annotations/`，与 Automate HTTP 反馈进入同一套 raw/daily/UNREVIEWED 文件。

日报 timer 现在在 09:00、10:00、11:00 运行。09:00/10:00 若早晨手机边界仍未出现，
只写 `data/state/daily_life_morning/YYYY-MM-DD.json` pending 状态，不推送日报；
11:00 仍未观察到则以 possible_fault 低置信状态生成并推送。
# 2026-07-29 Handoff 补充：Next Action Web

新增私有网页入口：

```text
https://pi.taild4d3f7.ts.net:8450
```

该入口为 Tailscale Serve tailnet only，代理到：

```text
http://127.0.0.1:8767
```

对应 systemd 服务：

```bash
systemctl status activitywatch-advisor-web.service --no-pager
journalctl -u activitywatch-advisor-web.service --no-pager -n 80
```

关键文件：

```text
/home/conrad/workspace/activitywatch-advisor/src/web_app.py
/home/conrad/workspace/activitywatch-advisor/src/next_action.py
/home/conrad/workspace/activitywatch-advisor/systemd/activitywatch-advisor-web.service
/home/conrad/workspace/activitywatch-advisor/docs/next-action-web-architecture.md
```

数据归档：

```text
data/next_action/state_snapshots/
data/next_action/suggestions/
data/next_action/responses/
data/next_action/outcomes/
data/next_action/active.json
```

半小时报告网页反馈复用：

```text
data/user_annotations/raw/
data/user_annotations/daily/
data/user_annotations/UNREVIEWED.md
```

部署/验证命令：

```bash
cd /home/conrad/workspace/activitywatch-advisor
python3 -m unittest discover -s tests
sudo systemctl restart activitywatch-advisor-web.service
curl -fsS http://127.0.0.1:8767/api/half-hour/reports
```

注意：下一步行动助手不是自动干预系统。它只在用户主动点击时调用 V4 Pro；第一版执行结果只采用用户手动反馈，不自动根据设备活动判定完成或失败。
# 2026-07-29 Handoff 补充：Next Action v1.1

当前 prompt/version：

```text
next-action-v1.1
```

v1.1 修改点：

- `src/next_action.py` 中加入 `routine_context=lunch_rest`，12:00-13:00 默认禁止 task 类型建议。
- 后端校验会拒绝午休窗口内的 task suggestion，并回退到吃饭/离屏休息 fallback。
- `hard_rules.pomodoro_role` 明确：番茄钟是中等可靠性正向证据，番茄数量是预估预算/进度标记，不是完成保证。
- `hard_rules.pomodoro_minutes = 40`；本系统 `1 🍅 = 40 分钟`，不是 25 分钟。若模型把 15/25/30 分钟启动片段说成一个番茄钟，`_validate_suggestion()` 会拒绝该输出。
- 模型 system message 新增 v1.1 addendum：语气需温和、具体、适度亲近；说服重点是启动最小动作，而非完成大任务。

修改后需要重启：

```bash
sudo systemctl restart activitywatch-advisor-web.service
```
# 2026-07-29 Handoff: Next Action thinking/trace

- Next Action suggestion generation now uses `config/settings.json` `decision_model.thinking=enabled`.
- Effective model merge is still `{**settings["model"], **settings["decision_model"]}`; endpoint comes from base `model`, while name/thinking/token/timeout are overridden by `decision_model`.
- `src/next_action.py` normalizes every suggestion with `decision_trace`.
- `decision_trace` is an auditable summary, not chain-of-thought. It records evidence, applied rules, excluded option categories, data-quality notes, and model thinking status. `full_reasoning_saved=false`.
- If thinking causes empty output with finish_reason `length`, `src/deepseek_client.py` already retries with thinking disabled for that request.
# 2026-07-29 Handoff: Next Action public Funnel

- Public Next Action URL: `https://pi.taild4d3f7.ts.net:10000`.
- Tailscale Funnel `:10000` proxies to `http://127.0.0.1:8767`.
- Existing Funnel `:443` remains for phone usage upload receiver on `127.0.0.1:8765`.
- `activitywatch-advisor-web.service` reads `/home/conrad/.config/activitywatch-advisor/web.env` for simple login password and cookie signing secret. Do not store these values in docs.
- `src/web_app.py` requires login for all pages and APIs except `/login` and `/api/login`.
- Half-hour report details are restricted to the latest 3 report paths, matching the list API.
## 2026-07-30 接管补充：Next Action 问题反馈入口

Next Action Web 新增问题反馈入口。它用于记录系统问题，方便后续 Codex 统一处理。

服务与入口：

```text
activitywatch-advisor-web.service
127.0.0.1:8767
https://pi.taild4d3f7.ts.net:10000
```

登录凭据仍在私有环境文件中：

```text
/home/conrad/.config/activitywatch-advisor/web.env
```

不要输出或写入该文件中的密码、cookie secret 或其它 token。

新增代码与数据：

```text
src/issue_feedback.py
tests/test_issue_feedback.py
data/issue_feedback/raw/YYYY-MM-DD/<issue_id>.json
data/issue_feedback/daily/YYYY-MM-DD.md
data/issue_feedback/UNREVIEWED.md
```

新增 API：

```text
POST /api/issue-feedback
GET  /api/issue-feedback/recent
```

两者都要求登录。2026-07-30 验证：主测试 87 项 OK，服务 active，未登录访问最近问题列表返回 401。

## 2026-07-30 Handoff：Next Action v1.2

当前版本为 `next-action-v1.2`。

- `src/next_action.py` 新增 `pending_active_suggestion()`。active suggestion 没有 outcome，且最近 response 不是 `alternative_requested`/`declined` 时，视为未闭环。
- `src/web_app.py` 在生成前执行该检查；未闭环时返回 HTTP 409、`code=pending_outcome_required` 和旧建议。
- 网页先显示旧建议并暂存生成意图；用户提交“完成了/正在做/没开始”后自动重新生成。
- `build_decision_state()` 写入 `request_context.user_is_awake_for_decision_purposes=true`；prompt 与 `_reject_awake_clarification()` 禁止询问是否起床或醒来。

验证结果：Next Action tests 9 OK；全部 tests 90 OK；两段网页 JavaScript 语法通过；服务 active；`127.0.0.1:8767` 正常监听；未登录返回 401；未闭环登录请求返回 409。

部署前备份：

```text
/home/conrad/workspace/backups/activitywatch-advisor-20260730-next-action-v12/
```
## 2026-07-31 Handoff：电脑端 Cold Turkey 介入

半小时行为解释器在影子候选 `would_intervene=true` 且未使用 `--no-push` 时，会额外生成电脑端介入请求：

```text
data/computer_interventions/requests/YYYY-MM-DD/<request_id>.json
data/computer_interventions/responses/YYYY-MM-DD/*.json
data/computer_interventions/state/windows-main.json
```

Next Action Web 服务新增给 Windows agent 使用的登录后 API：

```text
GET  /api/computer-interventions/pending?computer_id=windows-main
POST /api/computer-interventions/ack
POST /api/computer-interventions/response
```

若比某个 pending request 更新的影子候选为 `would_intervene=false`，pending API 会抑制该旧请求；JSON 仍留在 requests 目录供审计。

公网/尾网入口仍复用现有 Next Action Web，不新增端口。Windows 端 agent 位于：

```text
D:\tools\computer-intervention-agent\agent.py
D:\tools\computer-intervention-agent\config.json
D:\tools\computer-intervention-agent\state.json
```

agent 只允许执行本地 allowlist 中的 Cold Turkey block：`常刷网站` 与 `bilibili`。默认命令路径为 `D:\Cold Turkey\Cold Turkey Blocker.exe`，执行 `-start <block> -lock 30`。拒绝两次后第三次强制介入；封锁命令成功、agent 认为 block 已经处于本地估计封锁状态、或系统观察到恢复，都会重置拒绝计数。B 站 block 在周六全天、周日全天、周一 00:00-12:00 Asia/Shanghai 例外，不执行封锁且不计入拒绝。
