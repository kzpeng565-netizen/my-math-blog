# 树莓派行为数据与接口索引

<!-- ai_provenance: source=codex; date=2026-07-29; verification=checked; retrieved_notes="none; inspected Pi project files and service status" -->

这份文档用于回答一个很实际的问题：树莓派现在到底收集了哪些数据、加工出了哪些中间产物、有哪些接口可以被手机端或后续 AI 调用。

当前结论是：数据已经足够多，下一阶段的重点不是继续加传感器，而是把数据整理成少数几个稳定摘要，避免每次让 AI 在一堆原始日志里重新找线索。

## 电脑端 Cold Turkey 介入请求

==半小时解释器仍以 `data/intervention_candidates/` 作为影子候选事实源。当候选满足 `would_intervene=true` 且本次运行不是 `--no-push` 时，会生成一个结构化电脑端请求：==

```text
data/computer_interventions/requests/YYYY-MM-DD/<request_id>.json
```

==Windows agent 通过 Next Action Web 的登录后 API 拉取最新未完成请求，先提交 ack，再在用户选择、忽略、已封锁或 Cold Turkey 命令执行后提交最终回执：==

```text
GET  /api/computer-interventions/pending?computer_id=windows-main
POST /api/computer-interventions/ack
POST /api/computer-interventions/response
```

==回执归档在 `data/computer_interventions/responses/YYYY-MM-DD/`，agent 服务端状态在 `data/computer_interventions/state/windows-main.json`。规则配置在 `config/settings.json` 的 `computer_intervention` 段；Windows 本地 agent 还有 allowlist，拒绝执行未知 block。B 站在周六全天、周日全天、周一 00:00-12:00 Asia/Shanghai 被视为备课例外。==

==若较新的半小时影子候选为 `would_intervene=false`，API 不会再返回此前仍在 TTL 内的请求；旧请求保留在归档中，仅作为审计记录。==

<!-- ai_provenance: source=codex; date=2026-07-31; verification=checked; retrieved_notes="非笔记内容/工作流程与系统运维/树莓派行为数据与接口索引.md" -->

### 电脑端介入回执字段

==Windows agent 的 final 回执至少包含：==

```json
{
  "computer_id": "windows-main",
  "request_id": "2026-07-31-13-00_13-30",
  "agent_version": "0.1",
  "status": "final",
  "final": true,
  "decision": "accepted",
  "decline_streak_before": 0,
  "decline_streak_after": 0,
  "executions": [
    {
      "block": "常刷网站",
      "cold_turkey_block": "常刷网站",
      "action": "cold_turkey_start_lock",
      "lock_minutes": 30,
      "exit_code": 0,
      "status": "success"
    }
  ]
}
```

==`decision` 可能为 `accepted`、`declined`、`ignored`、`forced`、`already_locked`、`skipped`。其中 `ignored` 会完成请求但不增加拒绝计数；`accepted/forced/already_locked` 满足封锁目标后重置拒绝计数。==

==`data/computer_interventions/state/windows-main.json` 只记录服务端视角最近 ack/final 后的状态。目前没有独立 heartbeat；没有新请求时 `last_seen_at` 不会刷新。若要判断 Windows agent 当前是否在线，优先查本机进程。==

## 一句话总览

```text
手机 / 平板 / 电脑活动
  → 原始上传与 ActivityWatch 同步
  → 半小时 facts 清洗
  → tagged facts
  → semantic timeline
  → mixing metrics
  → half-hour AI report
  → user annotations / next action
```

另外一条线是：

```text
Obsidian / Tasks / Profile / Pomodoro
  → behavior-context-sync/context_snapshot.json
  → data/context_cache/current.json
  → Next Action decision_state
```

## 数据源与可靠性

| 数据源 | 位置 | 用途 | 当前可靠性判断 |

影子干预中，单个半小时窗口的 `confirmed_rest_minutes` 必须严格大于
`behavior_advisor.confirmed_rest_exemption_minutes`（当前为 12）才算明确休息并豁免干预；恰好 12 分钟不豁免。

影子介入仅由以下任一条件触发：高刺激严格大于 10 分钟、至少一次学习→娱乐→学习的有效交替
（不少于 2 次工作/娱乐切换且有超过 30 秒的娱乐偏离）、或深夜有娱乐。低效、无主线和单纯活跃不再单独触发。

`mixing_metrics.work_entertainment_transition_count` 保留所有工作/娱乐切换作审计；影子介入使用
`qualified_work_entertainment_transition_count`，其中每一段娱乐均须严格超过 30 秒并构成工作偏离。

|---|---|---|---|
| 电脑 ActivityWatch | `/home/conrad/workspace/activitywatch-sync`，加工后进 `data/computer_facts/` | 判断电脑是否工作、AFK、窗口标题、应用类别 | 高，尤其适合识别电脑端工作活动 |
| 手机 Automate 上传 | `/home/conrad/phone_usage/incoming/` 与 `/home/conrad/phone_usage/archive/`，加工后进 `data/phone_facts/` | 判断手机亮屏、前台应用、娱乐/通信/桌面 | 中高，依赖 Automate 正常运行 |
| 平板监控 | 同手机上传体系，或加工后进 `data/tablet_facts/` | 辅助判断是否存在另一台设备活动 | 中等，刚恢复监控，缺失时不要过度推断 |
| Obsidian context | `/home/conrad/workspace/behavior-context-sync/context_snapshot.json` | Profile、Tasks、番茄钟、学习计划摘要 | 中高；若同步刚检查过且源文件未变化，content age 很大也正常 |
| 番茄钟 | Obsidian context 内的 pomodoro 字段 | 作为任务进度和投入证据 | 中等可靠的正向证据；本系统 1 🍅 = 40 分钟；番茄数是预估预算，不保证剩余工作量 |
| 睡眠/日常统计 | `data/statistics/daily_life/` | 判断恢复状态、早晨边界、作息 | 中等；9/10/11 点重试，11 点仍无边界则可能故障 |
| 用户反馈 | `data/user_annotations/` 与 `data/next_action/responses/` | 校正 AI 解读和建议质量 | 高，应该优先用于系统改进 |

## 树莓派项目根目录

```text
/home/conrad/workspace/activitywatch-advisor
```

主要配置：

```text
config/settings.json
```

重要私有配置，不要写入文档或仓库：

```text
/home/conrad/.config/activitywatch-advisor/env
/home/conrad/.config/activitywatch-advisor/web.env
/home/conrad/.config/activitywatch-advisor/ntfy.env
/home/conrad/.config/activitywatch-advisor/ntfy-halfhour.env
/home/conrad/.config/activitywatch-advisor/pushplus.env
/home/conrad/phone_usage/token.txt
```

## 核心数据目录

以下统计为 2026-07-29 下午检查时的数量级，只用于说明系统规模：

| 目录 | 文件数 | 含义 |
|---|---:|---|
| `data/computer_facts/` | 228 | 每半小时电脑清洗事实 |
| `data/phone_facts/` | 228 | 每半小时手机清洗事实 |
| `data/tablet_facts/` | 124 | 每半小时平板清洗事实 |
| `data/combined_facts/` | 226 | 多设备合并事实 |
| `data/tagged_facts/` | 18 | 应用/窗口打标签后的事实 |
| `data/semantic_timelines/` | 222 | DeepSeek 语义时间线 |
| `data/mixing_metrics/` | 222 | 工作—娱乐混杂指标 |
| `data/ai_reports/` | 452 | 半小时 AI 解读，`.md` 与 `.json` |
| `data/context_snapshots/` | 77 | Obsidian context 历史快照 |
| `data/intervention_candidates/` | 77 | 影子干预候选，不自动执行 |
| `data/statistics/` | 12 | 日/周/生活统计与回执 |
| `data/next_action/` | 10 | 下一步行动状态、建议、反馈 |
| `data/user_annotations/` | 7 | 人工纠错反馈 |

## 半小时行为解读数据链

### 1. 原始与清洗 facts

```text
data/computer_facts/YYYY-MM-DD/HH-MM.json
data/phone_facts/YYYY-MM-DD/HH-MM.json
data/tablet_facts/YYYY-MM-DD/HH-MM.json
data/combined_facts/YYYY-MM-DD/HH-MM.json
```

用途：

- 判断设备是否活跃；
- 判断应用/窗口/标题；
- 合并手机、电脑、平板活动；
- 为后续标签、语义时间线和报告提供事实基础。

不建议直接给下一步行动 AI 全量读取。它们适合做审计和回放，不适合每次请求时原样塞给模型。

### 2. 标签与语义时间线

```text
data/tagged_facts/YYYY-MM-DD/HH-MM.json
data/semantic_timelines/YYYY-MM-DD/HH-MM.json
```

用途：

- `tagged_facts`：根据 `config/tag_rules.json` 给应用/窗口打标签；
- `semantic_timelines`：把设备事实整理成更接近人类理解的时间段。

下一步行动系统更适合读取它们的摘要，而不是读取原始窗口事件。

### 3. 混杂指标

```text
data/mixing_metrics/YYYY-MM-DD/HH-MM.json
```

用途：

- 工作分钟；
- 娱乐分钟；
- 通信分钟；
- 休息分钟；
- 工作中娱乐偏离；
- 最长连续工作；
- 最长娱乐段。

注意：原始 mixing level 有时会和最终解释冲突。例如没有工作活动时，“娱乐偏离”本质上是纯娱乐，不是“工作中偏离”。决策时应优先看最终状态和解释，而不是单独看某个 high 标签。

### 4. 半小时 AI 报告

```text
data/ai_reports/YYYY-MM-DD/HH-MM.md
data/ai_reports/YYYY-MM-DD/HH-MM.json
```

用途：

- `.md` 给人阅读；
- `.json` 给机器读取；
- PushPlus 目前仍会推送半小时报告到微信；
- Next Action Web 只暴露最新 3 条，并且网页展示时会转成非 Markdown 的手机阅读版。

## Obsidian context 与任务数据

接收路径：

```text
/home/conrad/workspace/behavior-context-sync/context_snapshot.json
```

缓存与历史：

```text
data/context_cache/current.json
data/context_snapshots/YYYY-MM-DD/*.json
```

包含内容：

- Profile；
- 当天 Tasks；
- 近期任务；
- 番茄钟；
- Obsidian 相关文件状态；
- 用于 AI 的压缩上下文。

关键规则：

- `obsidian_snapshot_content_age_minutes` 很大，不一定代表同步坏了；
- 如果 `obsidian_sync_checked_age_minutes` 很小，且 `obsidian_source_changed_at_last_check=false`，说明只是源文件没变；
- 番茄钟是中等可靠的正向证据，不是完成保证；本系统 1 🍅 = 40 分钟，不是 25 分钟，15/25 分钟建议只能叫启动片段或缩小版；
- Tasks 是按日计划，不是按小时计划，不要强行推断“现在几点应该做哪个任务”。

## 生活统计与睡眠

主要路径：

```text
data/statistics/daily_life/
data/statistics/ntfy_receipts/daily_life/
```

服务：

```text
activitywatch-advisor-daily-life.timer
activitywatch-advisor-daily-life.service
```

当前策略：

- 09:00 尝试生成前一日生活统计；
- 如果早晨边界未出现，10:00 再试；
- 如果仍未出现，11:00 再试；
- 11:00 后仍无边界，标记为可能故障。

用途：

- 判断睡眠和恢复；
- 给 Next Action 提供“今天适合高强度还是低阻力启动”的背景；
- 不应单独决定“今天完全不学习”。

## 用户反馈数据

### 半小时报告纠错

路径：

```text
data/user_annotations/raw/YYYY-MM-DD/*.json
data/user_annotations/daily/YYYY-MM-DD.json
```

入口：

```text
POST /annotation
```

公网入口：

```text
https://pi.taild4d3f7.ts.net/annotation
```

认证：

```text
Authorization: Bearer <phone_usage_token>
```

可提交字段：

```json
{
  "category": 0,
  "message": "这段判断哪里不对"
}
```

分类：

| category | 含义 |
|---:|---|
| 0 | AI 行为判断错误 |
| 1 | 数据缺失或设备状态错误 |
| 2 | AI 输出数据不符合要求 |
| 3 | 推荐任务或建议不合适 |
| 4 | 其他问题 |

系统会自动关联最近的半小时报告，以及对应的 facts、semantic timeline、mixing metrics。

### 下一步行动反馈

路径：

```text
data/next_action/responses/YYYY-MM-DD/*.json
data/next_action/outcomes/YYYY-MM-DD/*.json
```

用途：

- 记录建议是否接受；
- 记录换一个/拒绝原因；
- 记录完成、仍在做、没开始。

这类反馈应该成为后续优化建议质量的核心依据。

## Next Action 数据

路径：

```text
data/next_action/state_snapshots/*.json
data/next_action/suggestions/YYYY-MM-DD/*.json
data/next_action/active.json
data/next_action/responses/YYYY-MM-DD/*.json
data/next_action/outcomes/YYYY-MM-DD/*.json
```

含义：

| 文件 | 含义 |
|---|---|
| `state_snapshots` | 每次请求时整理出的决策状态 |
| `suggestions` | AI 或 fallback 生成的建议归档 |
| `active.json` | 当前建议 |
| `responses` | 用户对建议的即时反馈 |
| `outcomes` | 用户之后对执行结果的反馈 |

当前模型：

```text
decision_model = deepseek-v4-pro
thinking = enabled
max_tokens = 3500
timeout_seconds = 90
```

建议归档中有：

```text
decision_trace
```

它只保存可审计摘要，不保存完整思维链：

```text
evidence_used
rules_applied
excluded_options
data_quality_notes
model.full_reasoning_saved = false
```

## Web 与 HTTP 接口

### 手机上传服务

服务：

```text
phone-usage-receiver.service
```

本地监听：

```text
127.0.0.1:8765
```

公网 Funnel：

```text
https://pi.taild4d3f7.ts.net
```

接口：

```text
GET  /health
POST /upload/foreground.jsonl
POST /upload/screen.jsonl
POST /upload/heartbeat.jsonl
POST /upload/tablet_foreground.jsonl
POST /upload/tablet_screen.jsonl
POST /upload/tablet_heartbeat.jsonl
POST /annotation
```

上传认证：

```text
X-Upload-Token: <token>
```

annotation 认证：

```text
Authorization: Bearer <token>
```

上传后写入：

```text
/home/conrad/phone_usage/incoming/
/home/conrad/phone_usage/archive/YYYY-MM-DD/
```

### Next Action Web

服务：

```text
activitywatch-advisor-web.service
```

本地监听：

```text
127.0.0.1:8767
```

公网 Funnel：

```text
https://pi.taild4d3f7.ts.net:10000
```

tailnet-only Serve：

```text
https://pi.taild4d3f7.ts.net:8450
```

登录：

```text
GET  /login
POST /api/login
```

页面：

```text
GET /
GET /next
```

建议接口：

```text
POST /api/next-action
GET  /api/next-action/active
POST /api/next-action/{suggestion_id}/response
POST /api/next-action/{suggestion_id}/outcome
```

半小时报告接口：

```text
GET  /api/half-hour/reports
GET  /api/half-hour/report?path=...
POST /api/half-hour/feedback
```

限制：

- 所有页面和 API 除 `/login`、`/api/login` 外都需要登录；
- 半小时报告列表只返回最新 3 条；
- 半小时报告详情只能读取最新 3 条里的路径；
- 网页展示会把报告转换成非 Markdown 的手机阅读版；
- 不暴露 Cockpit、File Browser、Monaco、SSH 或原始数据目录。

## 定时服务与触发机制

| 服务/Timer | 频率 | 作用 |
|---|---|---|
| `activitywatch-advisor.timer` | 每小时 08、38 分 | 生成半小时行为解读 |
| `activitywatch-advisor-daily-life.timer` | 09:00、10:00、11:00 | 生成生活/睡眠日报，处理早晨边界 |
| `activitywatch-advisor-weekly-summary.timer` | 周一 09:05 | 周总结 |
| `bedtime-reminder.timer` | 00:00–04:59 每分钟检查 | 深夜设备提醒 |
| `sysadmin-time-guard.timer` | 每 5 分钟 | 系统运维时间提醒 |
| `phone-usage-maintenance.timer` | 每日约 03:30 | 手机归档压缩和清理 |

## 对后续 AI 调用的建议

### 推荐读取

下一步行动或日内决策 AI 优先读取：

```text
data/next_action/state_snapshots/最新一个
data/context_cache/current.json
data/ai_reports/当天最新 1–3 个 json
data/mixing_metrics/当天最新 1–3 个 json
data/semantic_timelines/当天最新 1–3 个 json
data/user_annotations/daily/当天 json
data/next_action/responses/当天
data/next_action/outcomes/当天
```

### 不推荐直接读取

除非调试，不建议每次读取：

```text
data/computer_facts/全量
data/phone_facts/全量
data/tablet_facts/全量
data/combined_facts/全量
data/ai_reports/全部 Markdown
所有历史 context_snapshots
```

原因：

- token 成本高；
- 模型容易被局部噪声带偏；
- 旧报告里可能有已被后续规则修正的解释；
- 原始 facts 更适合审计，不适合直接决策。

## 建议形成一个统一 current_state

后续最值得做的是稳定生成：

```text
data/current_state/next_action_context.json
```

它可以包含：

```json
{
  "generated_at": "...",
  "time_context": {},
  "data_quality": {},
  "recent_30m": {},
  "recent_90m": {},
  "today_totals": {},
  "tasks": [],
  "pomodoro": {},
  "sleep_or_recovery": {},
  "recent_annotations": [],
  "recent_next_action_feedback": []
}
```

这样以后网页、手机按钮、日报、下一步建议都可以调用同一个状态文件，而不是各自重新拼数据。

## 当前判断

数据不是少了，而是已经进入“需要分层”的阶段：

```text
原始日志层：保留、可审计
事实清洗层：供程序计算
语义摘要层：供 AI 理解
决策状态层：供 Next Action 使用
反馈层：供系统改进
```

以后新增功能时，优先问：

1. 它应该读取哪一层？
2. 是否真的需要原始日志？
3. 是否已经有同类摘要？
4. 用户反馈是否应该比模型推断优先？

只要守住这个分层，系统就不会因为数据越来越多而变得越来越乱。
## 2026-07-30 更新：问题反馈 backlog

Next Action Web 现在额外收集“系统问题反馈”。它不同于半小时报告纠错和下一步建议执行反馈：

| 类型 | 主要问题 | 数据路径 |
|---|---|---|
| 半小时报告纠错 | AI 对某个半小时窗口解释得对不对 | `data/user_annotations/` |
| 下一步建议反馈 | 这个建议是否接受、是否执行、哪里不适合 | `data/next_action/responses/` 与 `data/next_action/outcomes/` |
| 系统问题反馈 | 网页、规则、数据、通知、文档或建议系统本身哪里需要修 | `data/issue_feedback/` |

新增路径：

```text
data/issue_feedback/raw/YYYY-MM-DD/<issue_id>.json
data/issue_feedback/daily/YYYY-MM-DD.md
data/issue_feedback/UNREVIEWED.md
```

新增接口：

```text
POST /api/issue-feedback
GET  /api/issue-feedback/recent
```

字段：

```text
category: ai_suggestion_quality | data_wrong_or_missing | web_ui | notification | rule_mismatch | security_or_access | docs_or_handoff | other
severity: low | medium | high | blocking
message: 用户填写的具体问题描述
page: 当前网页 section
suggestion_id: 可选，关联当前建议
report_path: 可选，关联当前半小时报告
```

处理原则：

- raw JSON 是事实源。
- daily Markdown 和 `UNREVIEWED.md` 是人类/AI 审阅视图。
- 后续 Codex 批处理从 `UNREVIEWED.md` 进入，不直接扫全部历史 raw。
- 问题反馈不自动修改 prompt、规则或 Obsidian 任务，只作为后续人工授权修改的输入。
