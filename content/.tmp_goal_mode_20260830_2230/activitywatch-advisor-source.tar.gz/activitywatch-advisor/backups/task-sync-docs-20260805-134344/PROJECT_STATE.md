# Project State

2026-07-28：已接入只读 Obsidian 上下文、last-known-good 缓存、实际上下文归档和
影子干预候选。影子判断随原有半小时 PushPlus 核验消息发送；每日和每周统计分别由
独立 systemd timer 在白天发送。正式干预未启用，`shadow_mode` 保持为 `true`。

设备事实、语义时间线和确定性混杂指标仍是行为判断的主要事实源。上下文损坏或缺失
不会中断半小时主流程。

AI 状态解释同时归档为 `data/ai_reports/...json` 和 `.md`；DeepSeek 无效 JSON 会
降级成本地低置信度报告，不再导致服务整体失败。

全设备无活动时不调用 DeepSeek、不发 PushPlus，但继续归档本地报告及全部事实层。
这也是完整版必须保留的 token 节省规则。

2026-07-28：手机端系统异常反馈已接入现有 `phone-usage-receiver.service`。
手机只上传 `category` 和可选 `message`；接收时间、编号、半小时窗口与相关报告/事实层
关联全部由树莓派生成。原始反馈保存为不可由 AI 自动改写的 JSON，Markdown 日汇总和
`UNREVIEWED.md` 只是可从 raw JSON 重建的派生视图。
# 2026-07-29 Project State 补充：Next Action Web 已上线

树莓派端已新增私有网页入口 `https://pi.taild4d3f7.ts.net:8450`，由 `activitywatch-advisor-web.service` 提供服务，loopback 端口为 `127.0.0.1:8767`。该入口包含“下一步”和“半小时报告”两个视图。

“下一步”功能已经完成第一版闭环：用户点击后临时整理决策状态，调用 DeepSeek V4 Pro 生成较丰富的建议文本，并把状态快照、建议、响应和手动执行结果归档到 `data/next_action/`。已实测成功生成一条 V4 Pro 建议，模型调用成本记录在 `_generation.usage_total` 中。

半小时报告网页查看已可用，PushPlus 微信推送保留不变。网页反馈已接入原 `data/user_annotations/` 体系，与 Automate HTTP 反馈进入同一个 raw/daily/UNREVIEWED 归档。

日报睡眠边界已改为 09:00、10:00、11:00 三次检测。09:00/10:00 若早晨边界仍未出现，只写 pending 状态，不推送日报；11:00 仍未观察到则标记 possible_fault 并生成低置信日报。

测试状态：`python3 -m unittest discover -s tests` 通过 82 项。当前仍未启用自动执行观察，也未启用正式自动干预。
# 2026-07-29：Next Action v1.1

下一步行动助手已更新为 `next-action-v1.1`。本版不处理任务标题粒度过大的问题，只调整决策规则和输出语言：增强心理学上的启动说服力，保持适度亲近感，避免鸡汤、训诫和过度确定。

新增午休硬规则：12:00-13:00 为吃饭和午休时间，默认不推荐数学或项目工作。番茄钟规则已补充为“中等可靠性正向证据 + 预估预算/进度标记”，不得把剩余番茄数说成完成保证。
# 2026-07-29 Next Action thinking/trace 状态

- Next Action Web 的建议生成已开启 DeepSeek V4 Pro thinking：`decision_model.thinking=enabled`。
- 当前建议归档会包含 `decision_trace`，但不会保存完整思维链。
- `decision_trace` 只用于调试：证据使用、硬规则、排除项、数据质量提示、模型名称和 thinking 状态。
- Web 服务仍为 `activitywatch-advisor-web.service`，入口仍是 tailnet-only `https://pi.taild4d3f7.ts.net:8450`。
# 2026-07-29 Next Action public access state

- Next Action Web is protected by simple login and can be exposed through public Funnel on `https://pi.taild4d3f7.ts.net:10000`.
- Backend remains loopback-only on `127.0.0.1:8767`; Funnel proxies to this local service.
- Public `443` Funnel remains for phone upload service on `127.0.0.1:8765`.
- Half-hour report web access is constrained to latest 3 reports only.
## 2026-07-30 状态更新：问题反馈入口与 Codex skill

已完成 Next Action Web 的“问题反馈”入口，部署在 `activitywatch-advisor-web.service` 内，仍只监听 `127.0.0.1:8767`，通过现有登录保护后访问。

新增代码：

```text
src/issue_feedback.py
tests/test_issue_feedback.py
```

新增数据：

```text
data/issue_feedback/raw/YYYY-MM-DD/<issue_id>.json
data/issue_feedback/daily/YYYY-MM-DD.md
data/issue_feedback/UNREVIEWED.md
```

新增 API：

```text
POST /api/issue-feedback
GET  /api/issue-feedback/recent
```

部署后验证：

- `python3 -m unittest discover -s tests`：87 项 OK。
- `activitywatch-advisor-web.service` 重启后 active。
- 未登录访问 `/api/issue-feedback/recent` 返回 401。

同时，本地 Codex 新增 `pi-ops-system-context` skill，用于之后自动读取运维文档、服务地图、更新协议和问题反馈 backlog。

## 2026-07-30 Project State：Next Action v1.2

Next Action 已更新为 `next-action-v1.2`。生成新建议前，后端会检查当前 active suggestion 是否已通过 outcome，或已用“换一个/现在不做”明确关闭。未闭环时返回 `409 pending_outcome_required`，网页先展示旧建议，用户填写结果后自动继续本次生成请求。

用户主动点击“生成建议”被定义为已醒且能够交互的直接证据。决策状态、prompt 和输出验证器均禁止询问用户是否起床、醒来或仍在睡。

验证：Next Action 9 项测试、项目 90 项测试通过；网页 JavaScript 2 段通过语法检查；Web 服务 active；未登录 API 返回 401；登录后未闭环场景实测返回 409 和待处理建议。

## 2026-08-02：我的专注花园本地客户端

Windows 新增 `D:\MyFocusGarden` 本地像素风专注游戏。它只监听 `127.0.0.1:8838`，通过 SSH 只读聚合既有介入回执、Next Action response/outcome 和 daily_life 睡眠边界；树莓派没有新增端口、服务或公开 API。奖励在 Windows SQLite 中以稳定事件 ID 去重，游戏不回写本项目数据。

## 2026-08-03：我的专注花园迁移至 Pi

正式运行端已迁移到 `/home/conrad/services/focus-garden`。`focus-garden.service` 只监听 `127.0.0.1:8838`，Tailscale Serve 在 `https://pi.taild4d3f7.ts.net:8460/` 提供 tailnet-only HTTPS；没有为专注花园启用 Funnel。

权威数据库在 Pi。`focus-garden-backup.timer` 每分钟生成一致性快照到 `/home/conrad/workspace/focus-garden-archive/`，再由 Syncthing send-only 同步到 Windows receive-only 的 `D:\MyFocusGardenArchive`。迁移验收为 9 条奖励、8 株植物、1 份待种、无运行中计时，Python 7 项测试通过。

## 2026-08-04：Focus Garden 内嵌 Next Action 已部署

==已将花园原生“下一步行动”菜单部署到 `/home/conrad/services/focus-garden`。花园只向 `127.0.0.1:8767` 转发固定 Next Action 接口并透传浏览器登录 cookie；不保存密码、不读取私有配置，不新增端口或 Serve/Funnel 路由。Pi 上 8 项 Focus Garden Python 测试通过，`focus-garden.service` 已重启、8838 健康检查正常，未登录代理请求返回既有 Next Action 401；真实登录、生成建议和反馈闭环待用户手动验收。==

<!-- ai_provenance: source=codex; date=2026-08-04; verification=checked; retrieved_notes="local deployment verification" -->
## 2026-08-04: Next Action password disabled, Tailnet-only

`NEXT_ACTION_WEB_PASSWORD` was removed from the private web environment after taking a private backup, and `activitywatch-advisor-web.service` was restarted. The Next Action active endpoint and Focus Garden proxy now return HTTP 200 without login.

The public `:10000` Funnel was removed at the same time. Next Action remains available only via tailnet-only Tailscale Serve on `:8450` and through Focus Garden on `:8460`; both application listeners remain loopback-only. Do not restore public access without independent authentication.
## 2026-08-04：专注花园电脑＋手机正式启用

==Focus Garden 已切换为 FOCUS_GARDEN_DRY_RUN=0；电脑＋手机专注会同时触发 Windows Cold Turkey 与手机快速番茄。手机桥接 v1.0.0 每 5 分钟写入无障碍心跳，超过 20 分钟未见心跳时网页加载会提示。专注限定 5/10/20/30/40/45/60 分钟，并新增预约和连续专注。==
