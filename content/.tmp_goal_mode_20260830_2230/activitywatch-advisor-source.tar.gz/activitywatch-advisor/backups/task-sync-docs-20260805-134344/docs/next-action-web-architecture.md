# Next Action Web Architecture

## 2026-07-29 更新：手机展示去 Markdown

网页展示层不再把建议和半小时报告作为 Markdown 原文直接显示给手机：

- Next Action 建议使用结构化字段渲染为彩色卡片，少量 emoji，仅用于提示重点。
- `display_text` 也改为纯文本风格，不再使用 Markdown `-` 列表。
- 半小时报告的原始 `.md` 文件继续保留用于审计和回溯。
- `/api/half-hour/report` 返回给网页的是去 Markdown 后的手机阅读版：去掉 `#` 标题、Markdown 表格、代码块标记、粗体标记和普通 Markdown 列表符号。
- 最新 3 条报告的访问限制保持不变。

## 2026-07-29 更新：公网 Funnel 与简单登录

Next Action Web 增加公网 Funnel 入口：

```text
https://pi.taild4d3f7.ts.net:10000
```

该入口代理到本机 `127.0.0.1:8767`，不占用既有 `443 -> phone-usage-receiver` 上传入口。网页服务自身增加简单登录；密码与签名 secret 存放在树莓派私有文件 `/home/conrad/.config/activitywatch-advisor/web.env`，不写入项目文档或仓库文件。

公开入口只连接 Next Action Web 服务。该服务暴露：

- `GET /`、`GET /next`、`GET /login`
- `POST /api/login`
- `POST /api/next-action`
- `GET /api/next-action/active`
- `POST /api/next-action/{id}/response`
- `POST /api/next-action/{id}/outcome`
- `GET /api/half-hour/reports`
- `GET /api/half-hour/report?path=...`
- `POST /api/half-hour/feedback`

半小时报告接口进一步收紧：列表只返回最新 3 条，读取详情时也只允许读取这 3 条中的路径，不能通过猜旧路径访问全部历史报告。

## 2026-07-29 更新：DeepSeek V4 Pro thinking 与 decision trace

Next Action v1.1 之后，`decision_model` 使用 `deepseek-v4-pro` 且开启 `thinking`。因为 thinking 会占用更多生成预算，`max_tokens` 调整为 3500，`timeout_seconds` 调整为 90。

系统不保存完整思维链或草稿 JSON。建议归档中新增 `decision_trace`，只保存可审计摘要：

```text
trace_type: auditable_summary_not_chain_of_thought
evidence_used
rules_applied
excluded_options
data_quality_notes
model.provider/name/thinking
model.full_reasoning_saved = false
```

这个 trace 用于调试“它为什么选这项行动”，不是让模型暴露隐藏推理。完整输入状态仍保存在 `data/next_action/state_snapshots/`；最终建议仍保存在 `data/next_action/suggestions/` 和 `active.json`。

本文记录 2026-07-29 新增的“下一步行动助手”系统部件。它建立在现有数据采集、半小时行为解读、Obsidian context 导出和人工反馈系统之上，目标是在用户主动询问“我现在该做什么”时，把已有数据转化为一个可执行且有说服力的下一步建议。

## 目标

这个部件不是树莓派版通用聊天，也不是自动管控系统。它只做一件事：当用户主动点击网页按钮时，临时整理当前状态，调用 DeepSeek V4 Pro，返回一个具体行动，并允许用户记录接受、拒绝、换一个以及执行结果。

AI 输出允许比半小时报告更有说服力。建议需要包含行动、时长、第一步、简短理由、数据依据、较完整的说服说明、可能阻力和缩小版行动。这样做的目的不是多写分析，而是在用户犹豫时降低启动阻力。

## 服务边界

入口：

```text
https://pi.taild4d3f7.ts.net:8450
```

Tailscale Serve 配置：

```text
https://pi.taild4d3f7.ts.net:8450 -> http://127.0.0.1:8767
```

systemd 服务：

```text
activitywatch-advisor-web.service
```

代码位置：

```text
src/web_app.py
src/next_action.py
```

它与公开手机上传入口分离。公开 Funnel `https://pi.taild4d3f7.ts.net` 仍然只代理到 `127.0.0.1:8765` 的上传/annotation 接收器；Next Action Web 只通过 tailnet-only 的 `:8450` 访问。

## 数据流

用户在网页点击“生成建议”后才触发流程：

```text
网页按钮
  -> POST /api/next-action
  -> build_decision_state()
  -> 保存 state snapshot
  -> 调用 DeepSeek V4 Pro decision_model
  -> 校验建议 JSON
  -> 保存 suggestion 与 active.json
  -> 返回网页展示
```

状态生成器读取：

```text
data/ai_reports/
data/statistics/daily_life/
data/context_cache/current.json
behavior-context-sync/context_snapshot.json
data/next_action/responses/
```

状态生成器只读这些数据，不写 Obsidian，不修改 Tasks，不改变番茄钟日志。

## AI 约束

AI 必须只输出一个行动。`decision_type` 只能是：

```text
task
break
exercise
sleep
clarify
no_action
```

工作/学习类建议必须匹配当前 Obsidian context 中的任务标题。AI 不得创造新项目，不得要求用户执行未列入当天任务的学习/项目工作。

允许时长来自：

```text
5, 10, 15, 25, 40
```

建议 JSON 会经过后端校验。若模型输出非法，系统使用本地 fallback suggestion，并把错误写入建议归档。

## 输出格式

建议归档至少包含：

```text
suggestion_id
decision_type
title
duration_minutes
first_step
task_title
reason_short
evidence_points
persuasive_explanation
anticipated_resistance
reduced_version
confidence
display_text
state_snapshot
_generation
```

其中 `display_text` 是网页直接展示的文本。`_generation` 记录模型、token 用量和估算成本。

## 反馈与执行结果

下一步建议反馈写入：

```text
data/next_action/responses/YYYY-MM-DD/
data/next_action/outcomes/YYYY-MM-DD/
```

第一版按钮：

```text
开始
换一个
现在不做
完成了
正在做
没开始
```

“换一个”和“现在不做”可以附带原因码和具体说明。原因码用于后续分析建议失败原因，但不会自动修改 prompt、任务或配置。

第一版不做自动执行观察。设备活动最多可以在未来作为弱证据加入复盘，但不能覆盖用户手动反馈。

## 半小时报告网页反馈

网页的“半小时报告”视图只列出最新 3 条报告，避免把全部半小时检测日志暴露到网页界面。报告来源为：

```text
data/ai_reports/YYYY-MM-DD/HH-MM.md
```

报告反馈通过：

```text
POST /api/half-hour/feedback
```

后端复用 `user_annotations.receive_annotation()`，因此网页反馈与 Automate HTTP 反馈进入同一套归档：

```text
data/user_annotations/raw/
data/user_annotations/daily/
data/user_annotations/UNREVIEWED.md
```

这类反馈只表示“半小时解读系统可能有问题”，不会自动触发 DeepSeek、自动改配置或自动改 raw JSON。

## 睡眠日报重试

日报 timer 现在在：

```text
09:00
10:00
11:00
```

运行。09:00/10:00 若早晨手机边界仍是 pending，则只写：

```text
data/state/daily_life_morning/YYYY-MM-DD.json
```

不推送日报。11:00 仍未观察到早晨边界时，睡眠边界标记为 `possible_fault`，并生成低置信日报。

## 验证

部署后已验证：

```bash
python3 -m unittest discover -s tests
systemctl is-active activitywatch-advisor-web.service
curl -fsS http://127.0.0.1:8767/api/half-hour/reports
curl -fsS https://pi.taild4d3f7.ts.net:8450/api/half-hour/reports
```

82 项测试通过。实际调用 `POST /api/next-action` 成功生成 DeepSeek V4 Pro 建议，并保存状态快照、建议归档和 active suggestion。

## 后续方向

近期只需要观察建议是否足够有说服力、是否会被用户执行，以及拒绝原因是否容易填写。不要急于做自动执行观察。若要做第二版，应先定义清楚设备行为与用户反馈的优先级：用户手动反馈优先，设备行为只能作为可能证据。
# Version 1.1

`next-action-v1.1` 在 2026-07-29 增加四类规则。

第一，语言风格更重视心理启动。建议应温和、具体、有适度亲近感，像熟悉用户节奏的助手。说服重点是降低启动阻力，而不是训诫、鼓励或要求完成整个大任务。

第二，12:00-13:00 是固定吃饭和午休窗口。这个时间段默认推荐吃饭、离屏、午睡或轻恢复，不推荐数学和项目工作。后端校验会拒绝午休窗口内的 `task` 建议。

第三，番茄钟是中等可靠性正向证据。番茄数量表示预估预算或进度标记，不保证实际工作能按预估完成。AI 不得说“只剩一个番茄即可完成”，应改为“记录显示接近收尾”或“预估还剩约一个番茄”。

本系统里的番茄钟单位必须明确：`1 🍅 = 40 分钟`，不是常见的 25 分钟。若建议时长是 5、10、15 或 25 分钟，只能称为“启动片段”“缩小版”或“小块”，不能说“刚好一个番茄”或暗示“一个番茄可以用 25 分钟完成”。

第四，任务粒度过大暂不在本版解决。AI 仍从当天任务标题中选择，但 `first_step` 与 `reduced_version` 必须切到 5-10 分钟可启动的小动作。
## 2026-07-30 更新：问题反馈入口

Next Action Web 新增“问题反馈”入口。它不是建议执行反馈，而是系统问题 backlog，用于记录：

- AI 建议质量问题；
- 数据错误或缺失；
- 网页界面问题；
- 通知问题；
- 规则不匹配；
- 安全或访问问题；
- 文档或交接问题；
- 其它系统异常。

用户在网页中选择分类和严重程度，并写下具体问题。后端记录当前页面、可选的 `suggestion_id` 和 `report_path`，便于之后回溯。

新增接口：

```text
POST /api/issue-feedback
GET  /api/issue-feedback/recent
```

两个接口都需要登录。数据写入：

```text
data/issue_feedback/raw/YYYY-MM-DD/<issue_id>.json
data/issue_feedback/daily/YYYY-MM-DD.md
data/issue_feedback/UNREVIEWED.md
```

`raw` 是事实源；daily Markdown 和 `UNREVIEWED.md` 是审阅视图。之后让 Codex 统一处理时，应从 `UNREVIEWED.md` 开始，而不是扫描所有历史 raw。

# Version 1.2：建议闭环与显式交互证据

## 未完成建议优先

`POST /api/next-action` 先检查 `data/next_action/active.json`。当前建议已有 outcome，或最近 response 为“换一个/现在不做”，才允许生成下一条；否则返回 HTTP 409：

```json
{
  "code": "pending_outcome_required",
  "suggestion": {}
}
```

网页收到后展示上一条建议并暂存本次生成意图。用户填写“完成了/正在做/没开始”后，outcome 先落盘，网页再自动恢复生成请求。设备活动不参与完成状态判定。

## 用户点击即为已醒证据

用户主动点击“生成建议”直接证明用户已醒且能交互。睡眠边界 pending/possible_fault 不得覆盖这条实时证据。防线包括：

```text
request_context.user_is_awake_for_decision_purposes=true
prompt 禁止询问是否起床或醒来
validator 拒绝相关 clarify 输出
```

验证：Next Action 9 项测试、完整 90 项测试通过；服务 active；真实未闭环请求返回 `409 pending_outcome_required`。

## 2026-08-04：Focus Garden 内嵌 Next Action 已部署

==已将花园原生“下一步行动”菜单部署到 `/home/conrad/services/focus-garden`。花园只向 `127.0.0.1:8767` 转发固定 Next Action 接口并透传浏览器登录 cookie；不保存密码、不读取私有配置，不新增端口或 Serve/Funnel 路由。Pi 上 8 项 Focus Garden Python 测试通过，`focus-garden.service` 已重启、8838 健康检查正常，未登录代理请求返回既有 Next Action 401；真实登录、生成建议和反馈闭环待用户手动验收。==

<!-- ai_provenance: source=codex; date=2026-08-04; verification=checked; retrieved_notes="local deployment verification" -->
## 2026-08-04: Next Action password disabled, Tailnet-only

`NEXT_ACTION_WEB_PASSWORD` was removed from the private web environment after taking a private backup, and `activitywatch-advisor-web.service` was restarted. The Next Action active endpoint and Focus Garden proxy now return HTTP 200 without login.

The public `:10000` Funnel was removed at the same time. Next Action remains available only via tailnet-only Tailscale Serve on `:8450` and through Focus Garden on `:8460`; both application listeners remain loopback-only. Do not restore public access without independent authentication.