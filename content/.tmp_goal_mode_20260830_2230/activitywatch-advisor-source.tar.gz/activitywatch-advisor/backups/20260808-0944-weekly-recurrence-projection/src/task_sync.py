"""Pi-side task intent queue.

The Pi never writes the Obsidian vault.  It keeps a small durable queue of
web mutations and overlays it on the latest exported task snapshot so that
Next Action can react immediately.  The desktop Obsidian plugin is the only
Markdown writer and acknowledges a mutation only after the matching snapshot
has reached this Pi.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from common import atomic_write_json


TASK_ID_RE = re.compile(r"^\^[A-Za-z0-9-]{4,32}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
PRIORITIES = {"highest", "high", "medium", "normal", "low", "lowest"}
EDITABLE_FIELDS = {
    "title",
    "scheduled_date",
    "due_date",
    "priority",
    "tomatoes_completed",
    "tomatoes_total",
    "recurrence",
    "category",
}


def _now(timezone_name: str) -> datetime:
    return datetime.now(ZoneInfo(timezone_name))


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}


def _snapshot_hash(path: Path) -> str | None:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return None


def _state_path(output_root: Path) -> Path:
    return output_root / "task_sync" / "state.json"


def _load_state(output_root: Path) -> dict[str, Any]:
    state = _read_json(_state_path(output_root))
    if state.get("schema_version") != 1 or not isinstance(state.get("mutations"), list):
        return {"schema_version": 1, "revision": 0, "mutations": []}
    state["revision"] = int(state.get("revision", 0) or 0)
    return state


def _save_state(output_root: Path, state: dict[str, Any]) -> None:
    atomic_write_json(_state_path(output_root), state)


def _bucket(task: dict[str, Any], today: date) -> str:
    if task.get("recurrence"):
        return "recurring"
    scheduled = task.get("scheduled_date")
    if not isinstance(scheduled, str) or not DATE_RE.fullmatch(scheduled):
        if task.get("task_source") == "collection":
            return "unassigned"
        return "later"
    scheduled_day = date.fromisoformat(scheduled)
    if scheduled_day < today:
        return "overdue"
    if scheduled_day == today:
        return "today"
    if scheduled_day <= date.fromordinal(today.toordinal() + 3):
        return "near_term"
    return "later"


def _snapshot_tasks(snapshot: dict[str, Any], today: date) -> dict[str, dict[str, Any]]:
    task_groups = snapshot.get("tasks", {})
    if not isinstance(task_groups, dict):
        return {}
    tasks: dict[str, dict[str, Any]] = {}
    for source_bucket in (
        "overdue_tasks",
        "today_tasks",
        "near_term_tasks",
        "later_tasks",
        "recurring_tasks",
        "unassigned_tasks",
    ):
        for raw in task_groups.get(source_bucket, []):
            if not isinstance(raw, dict):
                continue
            task_id = raw.get("task_id")
            if not isinstance(task_id, str) or not TASK_ID_RE.fullmatch(task_id):
                continue
            task = dict(raw)
            task["task_id"] = task_id
            task["task_source"] = str(task.get("task_source") or "planned")
            task["status"] = "open"
            task["bucket"] = _bucket(task, today)
            tasks[task_id] = task
    return tasks


def _clean_text(value: Any, *, limit: int = 500) -> str:
    return " ".join(str(value or "").split())[:limit]


def _clean_date(value: Any) -> str | None:
    if value in (None, ""):
        return None
    result = str(value)
    if not DATE_RE.fullmatch(result):
        raise ValueError("date must use YYYY-MM-DD")
    date.fromisoformat(result)
    return result


def _clean_tomato(value: Any) -> int | None:
    if value in (None, ""):
        return None
    result = int(value)
    if result < 0 or result > 999:
        raise ValueError("tomato count must be between 0 and 999")
    return result


def _clean_changes(payload: dict[str, Any], *, creating: bool) -> dict[str, Any]:
    changes: dict[str, Any] = {}
    for key in EDITABLE_FIELDS:
        if key not in payload and not (creating and key == "priority"):
            continue
        value = payload.get(key)
        if key == "title":
            value = _clean_text(value)
            if creating and not value:
                raise ValueError("title is required")
        elif key in {"scheduled_date", "due_date"}:
            value = _clean_date(value)
        elif key in {"tomatoes_completed", "tomatoes_total"}:
            value = _clean_tomato(value)
        elif key == "priority":
            value = str(value or "normal")
            if value not in PRIORITIES:
                raise ValueError("invalid priority")
        elif key in {"recurrence", "category"}:
            value = _clean_text(value, limit=120) or None
        changes[key] = value
    if creating:
        total = changes.get("tomatoes_total")
        completed = changes.get("tomatoes_completed")
        if total is not None and completed is not None and completed > total:
            raise ValueError("completed tomatoes cannot exceed total tomatoes")
    return changes


def _apply_mutation(tasks: dict[str, dict[str, Any]], mutation: dict[str, Any], today: date) -> None:
    operation = mutation.get("operation")
    task_id = mutation.get("task_id")
    payload = mutation.get("payload", {})
    if not isinstance(task_id, str) or not isinstance(payload, dict):
        return
    if operation == "create":
        if task_id in tasks:
            return
        task = {
            "task_id": task_id,
            "title": "",
            "category": None,
            "planning_batch": None,
            "priority": "normal",
            "scheduled_date": None,
            "due_date": None,
            "recurrence": None,
            "tomatoes_completed": None,
            "tomatoes_total": None,
            "source_order": 10**9,
            "raw_line": None,
            "status": "open",
            "created_on_pi": True,
            "task_source": "collection",
        }
        task.update(payload)
        task["task_source"] = "planned" if task.get("scheduled_date") else "collection"
        task["bucket"] = _bucket(task, today)
        tasks[task_id] = task
    elif operation == "update" and task_id in tasks:
        tasks[task_id].update(payload)
        tasks[task_id]["task_source"] = "planned" if tasks[task_id].get("scheduled_date") else "collection"
        tasks[task_id]["bucket"] = _bucket(tasks[task_id], today)
    elif operation == "complete" and task_id in tasks:
        tasks[task_id]["status"] = "completed"
        tasks[task_id]["completed_on_pi"] = mutation.get("created_at")
    elif operation == "advance_tomatoes" and task_id in tasks:
        # This is an absolute, monotonic target rather than an increment.  A
        # desktop retry can therefore safely reapply the same mutation after
        # a write/export interruption without creating an extra tomato.
        target = payload.get("target_completed")
        if isinstance(target, int):
            current = tasks[task_id].get("tomatoes_completed")
            current = current if isinstance(current, int) else 0
            total = tasks[task_id].get("tomatoes_total")
            if isinstance(total, int):
                target = min(target, total)
            tasks[task_id]["tomatoes_completed"] = max(current, target)
    elif operation == "delete":
        tasks.pop(task_id, None)


def effective_state(
    context_path: Path, output_root: Path, *, timezone_name: str = "Asia/Shanghai", now: datetime | None = None
) -> dict[str, Any]:
    current = now or _now(timezone_name)
    snapshot = _read_json(context_path)
    if not snapshot:
        snapshot = _read_json(output_root / "context_cache" / "current.json")
    tasks = _snapshot_tasks(snapshot, current.date())
    state = _load_state(output_root)
    for mutation in state["mutations"]:
        if isinstance(mutation, dict):
            _apply_mutation(tasks, mutation, current.date())
    open_tasks = [task for task in tasks.values() if task.get("status") == "open"]
    open_tasks.sort(key=lambda task: (task.get("source_order", 10**9), task["task_id"]))
    grouped = {key: [] for key in ("unassigned", "overdue", "today", "near_term", "later", "recurring")}
    for task in open_tasks:
        grouped[_bucket(task, current.date())].append(task)
    return {
        "schema_version": 1,
        "generated_at": current.isoformat(timespec="seconds"),
        "revision": state["revision"],
        "pending_mutation_count": len(state["mutations"]),
        "snapshot_sha256": _snapshot_hash(context_path),
        "tasks": grouped,
        "mutations": state["mutations"],
    }


def compact_for_next_action(effective: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "task_id", "title", "category", "priority", "scheduled_date", "due_date", "task_source",
        "tomatoes_completed", "tomatoes_total", "source_order", "recurrence",
    )
    return {
        "tasks": {
            key: [{field: task.get(field) for field in fields} for task in effective["tasks"][key]]
            for key in ("unassigned", "overdue", "today", "near_term", "later", "recurring")
        },
        "task_sync": {
            "revision": effective["revision"],
            "pending_mutation_count": effective["pending_mutation_count"],
            "effective_generated_at": effective["generated_at"],
            "snapshot_sha256": effective["snapshot_sha256"],
        },
    }


def enqueue_mutation(
    context_path: Path,
    output_root: Path,
    payload: dict[str, Any],
    *,
    timezone_name: str = "Asia/Shanghai",
) -> dict[str, Any]:
    operation = str(payload.get("operation", ""))
    if operation not in {"create", "update", "complete", "delete", "advance_tomatoes"}:
        raise ValueError("operation must be create, update, complete, delete, or advance_tomatoes")
    task_id = str(payload.get("task_id", ""))
    if not TASK_ID_RE.fullmatch(task_id):
        raise ValueError("task_id must be an Obsidian block ID")
    changes = _clean_changes(payload, creating=operation == "create") if operation not in {"complete", "delete", "advance_tomatoes"} else {}
    current_effective = effective_state(context_path, output_root, timezone_name=timezone_name)
    current_tasks = {
        task["task_id"]: task
        for group in current_effective["tasks"].values()
        for task in group
    }
    if operation == "create" and task_id in current_tasks:
        raise ValueError("task_id already exists")
    if operation in {"update", "complete", "delete"} and task_id not in current_tasks:
        raise ValueError("task_id does not exist in the effective task view")
    if operation == "complete" and current_tasks.get(task_id, {}).get("recurrence"):
        raise ValueError("recurring tasks cannot be completed from the web in v1")
    state = _load_state(output_root)
    if operation == "advance_tomatoes":
        target = _clean_tomato(payload.get("target_completed"))
        settlement_id = str(payload.get("settlement_id", ""))
        if target is None:
            raise ValueError("target_completed is required")
        if not re.fullmatch(r"[A-Za-z0-9-]{8,80}", settlement_id):
            raise ValueError("settlement_id must be a stable focus session ID")
        task = current_tasks.get(task_id)
        if not task:
            raise ValueError("task_id does not exist in the effective task view")
        total = task.get("tomatoes_total")
        if not isinstance(total, int) or total <= 0:
            raise ValueError("task must have a positive tomato estimate")
        target = min(target, total)
        for existing in state["mutations"]:
            if (existing.get("operation") == "advance_tomatoes"
                    and existing.get("payload", {}).get("settlement_id") == settlement_id):
                return {"mutation": existing, "effective": effective_state(context_path, output_root, timezone_name=timezone_name)}
        changes = {"target_completed": target, "settlement_id": settlement_id}
    current = _now(timezone_name)
    mutation = {
        "mutation_id": uuid.uuid4().hex,
        "operation": operation,
        "task_id": task_id,
        "payload": changes,
        "created_at": current.isoformat(timespec="seconds"),
        "base_snapshot_sha256": _snapshot_hash(context_path),
    }
    state["mutations"].append(mutation)
    state["revision"] += 1
    state["updated_at"] = mutation["created_at"]
    _save_state(output_root, state)
    return {"mutation": mutation, "effective": effective_state(context_path, output_root, timezone_name=timezone_name)}


def acknowledge_mutations(
    context_path: Path,
    output_root: Path,
    payload: dict[str, Any],
    *,
    timezone_name: str = "Asia/Shanghai",
) -> dict[str, Any]:
    expected_hash = str(payload.get("snapshot_sha256", ""))
    actual_hash = _snapshot_hash(context_path)
    if not expected_hash or expected_hash != actual_hash:
        raise ValueError("Pi has not received the expected exported snapshot")
    mutation_ids = payload.get("mutation_ids")
    if not isinstance(mutation_ids, list) or not all(isinstance(item, str) for item in mutation_ids):
        raise ValueError("mutation_ids must be a list of strings")
    selected = set(mutation_ids)
    state = _load_state(output_root)
    snapshot = _read_json(context_path)
    snapshot_tasks = _snapshot_tasks(snapshot, _now(timezone_name).date())
    selected_mutations = [
        item for item in state["mutations"] if item.get("mutation_id") in selected
    ]
    for mutation in selected_mutations:
        operation = mutation.get("operation")
        task_id = mutation.get("task_id")
        payload = mutation.get("payload", {})
        task = snapshot_tasks.get(task_id)
        if operation in {"create", "update"}:
            reflected = task is not None and isinstance(payload, dict) and all(
                task.get(key) == value for key, value in payload.items()
            )
        elif operation in {"complete", "delete"}:
            reflected = task is None
        elif operation == "advance_tomatoes":
            target = payload.get("target_completed") if isinstance(payload, dict) else None
            completed = task.get("tomatoes_completed") if task else None
            reflected = isinstance(target, int) and isinstance(completed, int) and completed >= target
        else:
            reflected = False
        if not reflected:
            raise ValueError("exported snapshot does not reflect selected task mutations")
    before = len(state["mutations"])
    state["mutations"] = [item for item in state["mutations"] if item.get("mutation_id") not in selected]
    acknowledged = before - len(state["mutations"])
    if acknowledged:
        state["revision"] += 1
        state["updated_at"] = _now(timezone_name).isoformat(timespec="seconds")
        _save_state(output_root, state)
    return {"acknowledged": acknowledged, "effective": effective_state(context_path, output_root, timezone_name=timezone_name)}
