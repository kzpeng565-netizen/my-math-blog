import json
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from recent_context import create_note
from recent_context_selector import select_recent_context

TZ = ZoneInfo("Asia/Shanghai")
NOW = datetime(2026, 8, 6, 22, 0, 0, tzinfo=TZ)


def settings(selector_enabled=True):
    cfg = {
        "enabled": True,
        "direct_window_hours": 24,
        "preparation_window_days": 7,
        "review_after_days": 14,
        "parser_enabled": False,
        "selector_enabled": selector_enabled,
        "selector_model": "deepseek-v4-flash",
        "selector_thinking": False,
        "selector_candidate_limit": 20,
        "selector_output_limit": 6,
        "selector_timeout_seconds": 10,
        "card_limit": 3,
        "max_content_chars": 500,
        "max_impact_chars": 100,
    }
    return {
        "timezone": "Asia/Shanghai",
        "model": {"endpoint": "https://api.deepseek.com/chat/completions"},
        "recent_context": cfg,
    }


def make_note(note_id, content, impact, created, parse, archived=False, pinned=False):
    return {
        "id": note_id,
        "content": content,
        "impact_text": impact,
        "created_at": created,
        "updated_at": created,
        "confirmed_at": created,
        "archived": archived,
        "pinned": pinned,
        "parse": parse,
    }


def fake_generation():
    return {"usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}


class RecentContextSelectorTests(unittest.TestCase):
    def _tasks(self):
        return {
            "tasks": {
                "overdue": [],
                "today": [{"task_id": "^task1", "title": "完成实验汇报"}],
                "near_term": [],
                "later": [],
                "recurring": [],
            },
            "task_sync": {"revision": 3, "pending_mutation_count": 0},
        }

    def test_selector_receives_minimal_projection(self):
        notes = [
            make_note("rc_001", "明天下午临时要去实验室", "明天下午", "2026-08-06T21:30:00+08:00",
                      {"v": 1, "hash": "h", "type": "daypart", "date": "2026-08-07", "part": "afternoon", "confidence": "high"}),
            make_note("rc_002", "等老师回复", "直到老师回复", "2026-08-06T21:30:00+08:00",
                      {"v": 1, "hash": "h", "type": "event", "relation": "until", "confidence": "medium"}),
        ]
        captured = {}

        def fake(model, messages):
            captured["payload"] = json.loads(messages[-1]["content"])
            return {"selected": [{"id": "rc_001", "reason": "preparation"}]}, fake_generation()

        with patch("recent_context_selector._request_json_report", side_effect=fake):
            result = select_recent_context(notes, self._tasks(), NOW, settings())
        payload = captured["payload"]
        self.assertEqual(payload["now"], NOW.isoformat(timespec="seconds"))
        self.assertEqual(payload["tasks"][0]["title"], "完成实验汇报")
        item = payload["context"][0]
        self.assertIn("time", item)
        self.assertEqual(item["time"]["part"], "afternoon")
        # event/open/vague carry recorded_at; the daypart one does not.
        self.assertNotIn("recorded_at", payload["context"][0])
        self.assertEqual(payload["context"][1]["recorded_at"], "2026-08-06T21:30:00+08:00")
        self.assertNotIn("updated_at", payload["context"][0])
        self.assertNotIn("archived", payload["context"][0])
        self.assertNotIn("pinned", payload["context"][0])
        self.assertNotIn("hash", payload["context"][0])
        self.assertEqual(result["selection"]["selected_ids"], ["rc_001"])
        self.assertFalse(result["selection"]["fallback_used"])

    def test_forced_kept_even_when_ai_returns_empty(self):
        notes = [
            make_note("rc_force", "今天要去医院", "今天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-06", "confidence": "high"}),
            make_note("rc_opt", "下周出差", "下周", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-10", "confidence": "high"}),
        ]

        def fake(model, messages):
            return {"selected": []}, fake_generation()

        with patch("recent_context_selector._request_json_report", side_effect=fake):
            result = select_recent_context(notes, self._tasks(), NOW, settings())
        ids = [item["id"] for item in result["items"]]
        self.assertIn("rc_force", ids)
        self.assertIn("rc_force", result["selection"]["forced_ids"])
        self.assertIn("rc_force", result["selection"]["selected_ids"])

    def test_unknown_id_and_bad_reason_dropped(self):
        notes = [
            make_note("rc_ok", "明天考试", "明天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-07", "confidence": "high"}),
        ]

        def fake(model, messages):
            return {
                "selected": [
                    {"id": "rc_ok", "reason": "direct"},
                    {"id": "rc_fake", "reason": "direct"},
                    {"id": "rc_ok", "reason": "fabricated"},
                ]
            }, fake_generation()

        with patch("recent_context_selector._request_json_report", side_effect=fake):
            result = select_recent_context(notes, self._tasks(), NOW, settings())
        self.assertEqual([item["id"] for item in result["items"]], ["rc_ok"])
        self.assertFalse(result["selection"]["fallback_used"])

    def test_ai_failure_falls_back_locally(self):
        notes = [
            make_note("rc_a", "今天有事", "今天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-06", "confidence": "high"}),
            make_note("rc_b", "明天有事", "明天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-07", "confidence": "high"}),
            make_note("rc_c", "下月", "下个月", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-09-01", "confidence": "high"}),
        ]

        notes.append(make_note("rc_d", "等老师回复", "直到老师回复", "2026-08-06T08:00:00+08:00",
                               {"v": 1, "hash": "h", "type": "event", "relation": "until", "confidence": "medium"}))

        def fake(model, messages):
            raise RuntimeError("timeout")

        with patch("recent_context_selector._request_json_report", side_effect=fake):
            result = select_recent_context(notes, self._tasks(), NOW, settings())
        ids = [item["id"] for item in result["items"]]
        self.assertIn("rc_a", ids)
        self.assertIn("rc_b", ids)
        self.assertNotIn("rc_c", ids)
        self.assertTrue(result["selection"]["fallback_used"])

    def test_selector_disabled_falls_back(self):
        notes = [
            make_note("rc_a", "今天有事", "今天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "day", "date": "2026-08-06", "confidence": "high"}),
            make_note("rc_b", "等回复", "直到老师回复", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "event", "relation": "until", "confidence": "medium"}),
        ]
        result = select_recent_context(notes, self._tasks(), NOW, settings(selector_enabled=False))
        self.assertEqual([item["id"] for item in result["items"]], ["rc_a", "rc_b"])
        self.assertTrue(result["selection"]["fallback_used"])

    def test_output_capped_at_limit(self):
        notes = [
            make_note(f"rc_{i:03d}", f"动态{i}", "未来几天", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "vague", "confidence": "low"})
            for i in range(12)
        ]

        def fake(model, messages):
            return {"selected": [{"id": note["id"], "reason": "conditional"} for note in messages[1:2] and []] + []}, fake_generation()

        with patch("recent_context_selector._request_json_report", side_effect=fake):
            result = select_recent_context(notes, self._tasks(), NOW, settings())
        self.assertLessEqual(len(result["items"]), 6)
        self.assertLessEqual(len(result["selection"]["candidate_ids"]), 20)

    def test_conditional_item_has_condition_note(self):
        notes = [
            make_note("rc_x", "等老师回复", "直到老师回复", "2026-08-06T08:00:00+08:00",
                      {"v": 1, "hash": "h", "type": "event", "relation": "until", "confidence": "medium"}),
        ]
        result = select_recent_context(notes, self._tasks(), NOW, settings(selector_enabled=False))
        self.assertEqual(result["items"][0]["status"], "conditional")
        self.assertEqual(result["items"][0]["condition"], "事件状态尚未确认")


if __name__ == "__main__":
    import json
    unittest.main()