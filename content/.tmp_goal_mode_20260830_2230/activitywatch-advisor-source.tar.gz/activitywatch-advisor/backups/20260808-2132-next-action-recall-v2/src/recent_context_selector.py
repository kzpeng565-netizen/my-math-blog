"""Recent context relevance selector for Next Action.

Flow before the final decision model runs:
1. Code coarse filter (recent_context.coarse_candidates) removes archived, ended,
   needs_review and far-future notes, and forces notes that are active or within
   the direct window.
2. A lightweight DeepSeek V4 Flash call (thinking disabled, 10s timeout) judges
   whether each candidate affects the current action decision. Every candidate
   ID must come from the candidate set; invalid output falls back to local rules.
3. Forced notes are always kept; the final list is deduped, priority-sorted and
   capped at selector_output_limit (6).

A data-processing AI failure never breaks Next Action: any exception here falls
back to deterministic local selection.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from deepseek_client import _request_json_report
from recent_context import coarse_candidates, _status_for


SELECT_REASONS = {"direct", "preparation", "conditional"}
SELECTOR_PROMPT_VERSION = "recent-context-selector-v1"

SELECTOR_SYSTEM_PROMPT = (
    "你是\"近期动态相关性筛选器\"，只输出 JSON，不做任何行动建议。\n"
    "输入 now（当前时间）、tasks（有效任务最小投影）、context（近期动态候选）。\n"
    "你的任务：判断每条动态是否与用户此刻决定下一步行动相关。\n"
    "规则：\n"
    "1. 不要重新计算任何日期；now 和每条动态的 time/recorded_at 已经由系统给定。\n"
    "2. 不要改写动态原文。\n"
    "3. 只输出 selected 数组，每项含 id 与 reason；reason 只能是 "
    "direct（直接影响当前行动）、preparation（要求现在为近期事件准备）、"
    "conditional（是否相关取决于未确认条件）。\n"
    "4. 不要逐条解释排除原因。\n"
    "5. 只能引用输入中真实存在的 id。"
)


def _local_selection(
    notes: list[dict[str, Any]],
    now: datetime,
    cfg: dict[str, Any],
    limit: int,
) -> list[str]:
    """Deterministic fallback ordering used when the selector AI is unavailable."""
    review_days = int(cfg.get("review_after_days", 14))
    today = now.date()

    def rank(note: dict[str, Any]) -> tuple[int, Any]:
        status = _status_for(note, now, cfg)
        if status == "active":
            priority = 0
        elif status == "upcoming":
            priority = 1
        else:
            priority = 2
        anchor = note.get("confirmed_at") or note.get("created_at")
        try:
            anchor_date = datetime.fromisoformat(str(anchor)).date()
        except ValueError:
            anchor_date = today
        age = (today - anchor_date).days
        return (priority, age, -datetime.fromisoformat(str(note.get("created_at", ""))).timestamp())

    selected = sorted(notes, key=rank)[:limit]
    return [note["id"] for note in selected]


def _call_selector(
    candidates: list[dict[str, Any]],
    tasks: dict[str, Any],
    now: datetime,
    settings: dict[str, Any],
    cfg: dict[str, Any],
) -> list[str]:
    context: list[dict[str, Any]] = []
    for note in candidates:
        item: dict[str, Any] = {
            "id": note["id"],
            "text": note["content"],
            "impact": note["impact_text"],
            "status": _status_for(note, now, cfg),
        }
        parse = note.get("parse")
        if isinstance(parse, dict) and not parse.get("error"):
            time_info: dict[str, Any] = {}
            if parse.get("date"):
                time_info["date"] = parse["date"]
            if parse.get("part"):
                time_info["part"] = parse["part"]
            if parse.get("start"):
                time_info["start"] = parse["start"]
            if parse.get("end"):
                time_info["end"] = parse["end"]
            if time_info:
                item["time"] = time_info
        ptype = parse.get("type") if isinstance(parse, dict) else None
        if ptype in ("event", "open", "vague") or (isinstance(parse, dict) and parse.get("error")):
            item["recorded_at"] = note.get("created_at")
        context.append(item)
    task_items: list[dict[str, Any]] = []
    grouped = tasks.get("tasks", {}) if isinstance(tasks, dict) else tasks
    if isinstance(grouped, dict):
        for bucket in ("unassigned", "overdue", "today", "near_term", "later", "recurring"):
            for task in grouped.get(bucket, []) or []:
                if not isinstance(task, dict):
                    continue
                task_items.append(
                    {
                        "id": task.get("task_id"),
                        "title": task.get("title"),
                    }
                )
    payload = {
        "now": now.isoformat(timespec="seconds"),
        "tasks": task_items,
        "context": context,
    }
    base_model = settings.get("model", {})
    model = {
        "endpoint": base_model.get("endpoint", "https://api.deepseek.com/chat/completions"),
        "name": cfg.get("selector_model", "deepseek-v4-flash"),
        "thinking": "disabled",
        "max_tokens": 240,
        "timeout_seconds": int(cfg.get("selector_timeout_seconds", 10)),
        "retries": 0,
    }
    messages = [
        {"role": "system", "content": SELECTOR_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        },
    ]
    report, _generation = _request_json_report(model, messages)
    selected = report.get("selected", [])
    if not isinstance(selected, list):
        raise ValueError("selector output selected is not a list")
    candidate_ids = {note["id"] for note in candidates}
    chosen: list[str] = []
    seen: set[str] = set()
    for item in selected:
        if not isinstance(item, dict):
            continue
        note_id = str(item.get("id", "")).strip()
        reason = str(item.get("reason", "")).strip()
        if note_id not in candidate_ids or reason not in SELECT_REASONS:
            continue
        if note_id in seen:
            continue
        seen.add(note_id)
        chosen.append(note_id)
    # Return in candidate order for deterministic priority.
    return [note["id"] for note in candidates if note["id"] in seen]


def select_recent_context(
    notes: list[dict[str, Any]],
    effective_tasks: dict[str, Any],
    now: datetime,
    settings: dict[str, Any],
) -> dict[str, Any]:
    cfg = settings.get("recent_context", {})
    output_limit = int(cfg.get("selector_output_limit", 6))
    coarse = coarse_candidates(notes, now, settings)
    candidates = coarse["candidates"]
    forced_ids = set(coarse["forced_ids"])
    forced = [note for note in candidates if note["id"] in forced_ids]
    others = [note for note in candidates if note["id"] not in forced_ids]

    fallback_used = False
    selected_ids: list[str] = []
    if cfg.get("selector_enabled", True) and others:
        try:
            selected_ids = _call_selector(candidates, effective_tasks, now, settings, cfg)
        except Exception:
            fallback_used = True
    elif others:
        fallback_used = True

    if fallback_used:
        selected_ids = _local_selection(others, now, cfg, output_limit)

    selected_set = set(selected_ids)
    merged = forced + [note for note in others if note["id"] in selected_set]
    merged = _priority_sort(merged, now, cfg)
    merged = merged[:output_limit]
    items = []
    for note in merged:
        item: dict[str, Any] = {
            "id": note["id"],
            "content": note["content"],
            "impact": note["impact_text"],
            "status": _status_for(note, now, cfg),
        }
        if item["status"] in ("conditional", "needs_review"):
            item["condition"] = "事件状态尚未确认"
        items.append(item)
    return {
        "items": items,
        "selection": {
            "candidate_ids": [note["id"] for note in candidates],
            "forced_ids": coarse["forced_ids"],
            "selected_ids": [note["id"] for note in merged],
            "fallback_used": fallback_used,
        },
    }


def _priority_sort(
    notes: list[dict[str, Any]],
    now: datetime,
    cfg: dict[str, Any],
) -> list[dict[str, Any]]:
    def rank(note: dict[str, Any]) -> tuple[int, int, Any]:
        status = _status_for(note, now, cfg)
        if status == "active":
            priority = 0
        elif status == "upcoming":
            priority = 1
        else:
            priority = 2
        return (
            0 if note.get("pinned", False) else 1,
            priority,
            -datetime.fromisoformat(str(note.get("created_at", ""))).timestamp(),
        )

    return sorted(notes, key=rank)
