from __future__ import annotations

import json
import mimetypes
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlparse
from urllib.request import Request, urlopen

from .cold_turkey import ColdTurkeyController
from .database import GardenDatabase, utc_now
from .pi_sync import PiRewardSync

ALLOWED_FOCUS_MINUTES = {5, 20, 30, 40, 45, 60}
CONTINUOUS_FOCUS_MINUTES = {30, 40, 45, 60}
BRIDGE_STALE_SECONDS = 20 * 60


class NextActionProxy:
    """A deliberately small same-Pi bridge to the existing Next Action UI.

    The garden never reads the Next Action password or its data directory.  It
    forwards the browser's existing signed cookie only to the loopback service.
    """

    _PATHS = {
        "active": "/api/next-action/active",
        "reports": "/api/half-hour/reports",
        "report": "/api/half-hour/report",
        "issues": "/api/issue-feedback/recent",
        "login": "/api/login",
        "generate": "/api/next-action",
        "issue_feedback": "/api/issue-feedback",
        "report_feedback": "/api/half-hour/feedback",
    }
    _INTERVENTION_PATHS = {
        "manual_focus": "/api/interventions/manual-focus",
        "phone_pending": "/api/interventions/pending",
        "phone_decision": "/api/interventions/decision",
        "phone_event": "/api/interventions/event",
    }
    _TASK_SYNC_PATHS = {
        "state": "/api/task-sync/state",
        "mutations": "/api/task-sync/mutations",
    }

    def __init__(self, settings: dict[str, Any]):
        config = settings.get("next_action", {})
        self.enabled = bool(config.get("enabled", True))
        self.base_url = str(config.get("base_url", "http://127.0.0.1:8767")).rstrip("/")
        self.timeout_seconds = int(config.get("timeout_seconds", 90))
        parsed = urlparse(self.base_url)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Next Action must use a loopback HTTP endpoint")

    def request(self, target: str, method: str, *, body: dict[str, Any] | None = None,
                query: str = "", cookie: str = "", user_agent: str = "") -> tuple[int, Any, str]:
        if not self.enabled:
            raise ConnectionError("Next Action integration is disabled")
        if target not in self._PATHS:
            raise ValueError("unknown Next Action endpoint")
        return self._request_url(self.base_url + self._PATHS[target] + query, method, body, cookie, user_agent)

    def request_path(self, path: str, *, body: dict[str, Any], cookie: str = "",
                     user_agent: str = "") -> tuple[int, Any, str]:
        if not self.enabled:
            raise ConnectionError("Next Action integration is disabled")
        if not re.fullmatch(r"/api/next-action/[A-Za-z0-9_-]+/(response|outcome)", path):
            raise ValueError("invalid Next Action suggestion path")
        return self._request_url(self.base_url + path, "POST", body, cookie, user_agent)

    def intervention(self, target: str, method: str, *, body: dict[str, Any] | None = None,
                     query: str = "") -> tuple[int, Any, str]:
        """Call only fixed loopback intervention endpoints for the phone bridge."""
        if target not in self._INTERVENTION_PATHS:
            raise ValueError("unknown intervention endpoint")
        return self._request_url(
            self.base_url + self._INTERVENTION_PATHS[target] + query,
            method,
            body,
            "",
            "focus-garden-intervention-proxy/1",
            extra_headers={"X-Focus-Garden-Bridge": "1"},
        )

    def task_sync(self, target: str, method: str, *, body: dict[str, Any] | None = None) -> tuple[int, Any, str]:
        if target not in self._TASK_SYNC_PATHS:
            raise ValueError("unknown task-sync endpoint")
        return self._request_url(
            self.base_url + self._TASK_SYNC_PATHS[target],
            method,
            body,
            "",
            "focus-garden-task-sync/1",
            extra_headers={"X-Focus-Garden-Bridge": "1"},
        )

    def _request_url(self, url: str, method: str, body: dict[str, Any] | None,
                     cookie: str, user_agent: str,
                     extra_headers: dict[str, str] | None = None) -> tuple[int, Any, str]:
        raw_body = json.dumps(body or {}, ensure_ascii=False).encode("utf-8") if method == "POST" else None
        headers = {"Accept": "application/json"}
        if raw_body is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
        if cookie:
            headers["Cookie"] = cookie
        if user_agent:
            headers["User-Agent"] = user_agent
        if extra_headers:
            headers.update(extra_headers)
        request = Request(url, data=raw_body, headers=headers, method=method)
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                status, raw, set_cookie = response.status, response.read(), response.headers.get("Set-Cookie", "")
        except HTTPError as error:
            status, raw, set_cookie = error.code, error.read(), error.headers.get("Set-Cookie", "")
        except URLError as error:
            raise ConnectionError("Next Action 暂不可用，请检查 activitywatch-advisor-web.service") from error
        try:
            return status, json.loads(raw.decode("utf-8")), set_cookie
        except (UnicodeDecodeError, json.JSONDecodeError):
            return status, {"error": "Next Action returned an invalid response"}, set_cookie


class GardenService:
    def __init__(self, root: Path):
        self.root = root
        self.settings = json.loads((root / "config/settings.json").read_text(encoding="utf-8"))
        self.catalog = json.loads((root / "config/plants.json").read_text(encoding="utf-8"))["plants"]
        self.profiles = json.loads((root / "config/focus_profiles.json").read_text(encoding="utf-8"))["profiles"]
        self.catalog_ids = {x["id"] for x in self.catalog}
        self.catalog_tiers = {x["id"]: x.get("tier", "basic") for x in self.catalog}
        self.profile_map = {x["id"]: x for x in self.profiles}
        database_override = os.environ.get("FOCUS_GARDEN_DB")
        self.db = GardenDatabase(Path(database_override) if database_override else root / self.settings["database"], self.catalog_tiers)
        self.cold_turkey = ColdTurkeyController(self.settings)
        self.pi = PiRewardSync(self.settings)
        self.next_action = NextActionProxy(self.settings)

    def reconcile_focus(self) -> int:
        session = self.db.focus()
        if not session:
            return 0
        if datetime.fromisoformat(session["ends_at"]) <= datetime.now(timezone.utc):
            rewards = self.db.complete_focus(session["id"])
            self.db.advance_focus_plan_for_session(session["id"], utc_now())
            return rewards
        return 0

    def run_due_focus_plan(self) -> None:
        if self.db.focus():
            return
        plan = self.db.next_due_focus_plan(utc_now())
        if not plan:
            return
        try:
            session = self.start_focus(plan["profile_id"], int(plan["focus_minutes"]), plan["targets"])
            if session["status"] != "running":
                raise RuntimeError("unable to start the planned focus session")
            self.db.mark_focus_plan_started(plan["id"], session["id"])
        except Exception:
            # Do not silently retry a plan that could not be dispatched; the
            # retained plan state makes the problem observable in the UI.
            self.db.fail_focus_plan(plan["id"])

    def create_schedule(self, profile_id: str, duration: int, targets: list[str], starts_at: str) -> dict[str, Any]:
        start = datetime.fromisoformat(starts_at)
        if start.tzinfo is None:
            raise ValueError("scheduled time must include a timezone")
        if start <= datetime.now(start.tzinfo):
            raise ValueError("scheduled time must be in the future")
        self._validate_focus_request(profile_id, duration, targets)
        return self.db.create_focus_plan("scheduled", profile_id, duration, 0, 1, targets,
                                         start.astimezone(timezone.utc).isoformat(timespec="seconds"))

    def create_continuous_focus(self, profile_id: str, focus_minutes: int, rest_minutes: int,
                                rounds: int, targets: list[str]) -> dict[str, Any]:
        self._validate_focus_request(profile_id, focus_minutes, targets)
        if focus_minutes not in CONTINUOUS_FOCUS_MINUTES:
            raise ValueError("continuous focus must use 30, 40, 45, or 60 minutes")
        if not 1 <= rest_minutes <= 30 or not 2 <= rounds <= 8:
            raise ValueError("rest must be 1-30 minutes and rounds must be 2-8")
        return self.db.create_focus_plan("cycle", profile_id, focus_minutes, rest_minutes, rounds, targets, utc_now())

    def _validate_focus_request(self, profile_id: str, duration: int, targets: list[str]) -> None:
        if profile_id not in self.profile_map:
            raise ValueError("unknown focus profile")
        if duration not in ALLOWED_FOCUS_MINUTES:
            raise ValueError("focus duration must be 5, 20, 30, 40, 45, or 60 minutes")
        if not targets or not set(targets) <= {"windows", "phone"}:
            raise ValueError("targets must be computer, phone, or both")

    def start_focus(self, profile_id: str, duration: int, targets: list[str] | None = None) -> dict[str, Any]:
        selected_targets = set(targets or ["windows", "phone"])
        self._validate_focus_request(profile_id, duration, sorted(selected_targets))
        existing = self.db.focus()
        if existing:
            return existing
        now = datetime.now(timezone.utc)
        session = self.db.create_focus(profile_id, duration, now.isoformat(timespec="seconds"),
                                       (now + timedelta(minutes=duration)).isoformat(timespec="seconds"))
        try:
            if os.environ.get("FOCUS_GARDEN_DISPATCH_INTERVENTIONS") == "1":
                status, payload, _ = self.next_action.intervention(
                    "manual_focus",
                    "POST",
                    body={"duration": duration, "targets": sorted(selected_targets)},
                )
                if status != HTTPStatus.CREATED:
                    raise RuntimeError(str(payload.get("error", "intervention dispatcher rejected request")))
                self.db.set_focus_execution(
                    session["id"],
                    [{"status": "queued", "targets": sorted(selected_targets), "dispatcher": payload}],
                    failed=False,
                )
            else:
                # Local safe development remains deterministic and does not
                # require a reachable Pi Advisor service.
                executions = self.cold_turkey.start(self.profile_map[profile_id]["blocks"], duration)
                failed = any(x["status"] == "failed" for x in executions)
                self.db.set_focus_execution(session["id"], executions, failed=failed)
                if failed:
                    raise RuntimeError("Cold Turkey 未能启用全部封锁")
        except Exception:
            self.db.set_focus_execution(session["id"], [], failed=True)
            raise
        return self.db.focus(session["id"])  # type: ignore[return-value]

    def sync_rewards(self) -> dict[str, Any]:
        events = self.pi.fetch()
        inserted = self.db.import_rewards(events)
        return {"seen": len(events), "inserted": inserted, "pending": len(self.db.rewards("pending"))}

    def bootstrap(self) -> dict[str, Any]:
        self.reconcile_focus()
        health = self.db.bridge_health("android-main")
        age = None
        if health:
            age = max(0, int((datetime.now(timezone.utc) - datetime.fromisoformat(health["last_seen_at"])).total_seconds()))
        bridge = {"state": "never", "last_seen_at": None, "age_seconds": None}
        if health:
            bridge = {**health, "state": "online" if age is not None and age <= BRIDGE_STALE_SECONDS else "stale", "age_seconds": age}
        return {"catalog": self.catalog, "profiles": self.profiles, "garden": self.db.garden(),
                "pending_rewards": self.db.rewards("pending"), "reward_history": self.db.rewards(),
                "focus": self.db.focus(), "focus_history": self.db.focus_history(), "focus_plans": self.db.focus_plans(),
                "focus_bridge": bridge,
                "stats": self.db.stats(), "settings": {
                    "early_sleep_cutoff": self.settings["pi_sync"]["early_sleep_cutoff"],
                    "cold_turkey_mode": "dry_run" if os.environ.get("FOCUS_GARDEN_DRY_RUN") == "1"
                        else self.settings["cold_turkey"]["mode"],
                    "intervention_dispatch": os.environ.get("FOCUS_GARDEN_DISPATCH_INTERVENTIONS") == "1",
                }}


class GardenHandler(BaseHTTPRequestHandler):
    server_version = "MyFocusGarden/0.1"

    @property
    def service(self) -> GardenService:
        return self.server.service  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def _json(self, data: Any, status: int = 200, set_cookie: str = "") -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict[str, Any]:
        length = min(int(self.headers.get("Content-Length", "0")), 65536)
        return json.loads(self.rfile.read(length) or b"{}")

    def _error(self, exc: Exception) -> None:
        status = (
            HTTPStatus.SERVICE_UNAVAILABLE if isinstance(exc, ConnectionError)
            else HTTPStatus.NOT_FOUND if isinstance(exc, KeyError)
            else HTTPStatus.BAD_REQUEST
        )
        self._json({"error": str(exc).strip("'")}, status)

    def _next_action(self, target: str, method: str, body: dict[str, Any] | None = None,
                     query: str = "") -> None:
        try:
            status, data, set_cookie = self.service.next_action.request(
                target, method, body=body, query=query,
                cookie=self.headers.get("Cookie", ""), user_agent=self.headers.get("User-Agent", ""),
            )
            self._json(data, status, set_cookie)
        except Exception as exc:
            self._error(exc)

    def _intervention(self, target: str, method: str, body: dict[str, Any] | None = None,
                      query: str = "") -> None:
        try:
            status, data, _ = self.service.next_action.intervention(
                target, method, body=body, query=query
            )
            self._json(data, status)
        except Exception as exc:
            self._error(exc)

    def _task_sync(self, target: str, method: str, body: dict[str, Any] | None = None) -> None:
        try:
            status, data, _ = self.service.next_action.task_sync(target, method, body=body)
            self._json(data, status)
        except Exception as exc:
            self._error(exc)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            return self._json({"status": "ok"})
        if parsed.path == "/api/bootstrap":
            return self._json(self.service.bootstrap())
        if parsed.path == "/api/garden":
            return self._json(self.service.db.garden())
        if parsed.path == "/api/focus-bridge/pending":
            # The Android bridge is intentionally restricted to its one fixed
            # device identity; this is not a generic remote command channel.
            query = "?device_id=android-main"
            return self._intervention("phone_pending", "GET", query=query)
        if parsed.path == "/api/tasks":
            return self._task_sync("state", "GET")
        next_action_get = {
            "/api/next-action/active": "active",
            "/api/next-action/reports": "reports",
            "/api/next-action/report": "report",
            "/api/next-action/issues": "issues",
        }
        if parsed.path in next_action_get:
            query = ("?" + parsed.query) if parsed.path == "/api/next-action/report" and parsed.query else ""
            return self._next_action(next_action_get[parsed.path], "GET", query=query)
        if parsed.path.startswith("/api/"):
            return self._json({"error": "not found"}, 404)
        self._static(parsed.path)

    def do_POST(self) -> None:
        if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
            return self._json({"error": "application/json required"}, 415)
        try:
            body = self._body()
            if self.path == "/api/next-action/login":
                return self._next_action("login", "POST", body)
            if self.path == "/api/tasks/mutations":
                return self._task_sync("mutations", "POST", body)
            if self.path == "/api/next-action/generate":
                return self._next_action("generate", "POST", body)
            if self.path == "/api/next-action/issue-feedback":
                return self._next_action("issue_feedback", "POST", body)
            if self.path == "/api/next-action/report-feedback":
                return self._next_action("report_feedback", "POST", body)
            response_match = re.fullmatch(r"/api/next-action/suggestion/([^/]+)/response", self.path)
            if response_match:
                return self._next_action_path(f"/api/next-action/{response_match.group(1)}/response", body)
            outcome_match = re.fullmatch(r"/api/next-action/suggestion/([^/]+)/outcome", self.path)
            if outcome_match:
                return self._next_action_path(f"/api/next-action/{outcome_match.group(1)}/outcome", body)
            if self.path == "/api/rewards/sync":
                return self._json(self.service.sync_rewards())
            if self.path == "/api/focus-bridge/decision":
                return self._intervention(
                    "phone_decision",
                    "POST",
                    {**body, "device_id": "android-main"},
                )
            if self.path == "/api/focus-bridge/event":
                return self._intervention(
                    "phone_event",
                    "POST",
                    {**body, "computer_id": "android-main"},
                )
            if self.path == "/api/focus-bridge/heartbeat":
                status = str(body.get("status", ""))
                if status not in {"accessibility_connected", "running"}:
                    raise ValueError("invalid bridge heartbeat status")
                return self._json(self.service.db.record_bridge_heartbeat(
                    "android-main", status, str(body.get("detail", ""))
                ))
            if self.path == "/api/focus/start":
                targets = body.get("targets", ["windows", "phone"])
                if not isinstance(targets, list):
                    raise ValueError("targets must be a list")
                return self._json(
                    self.service.start_focus(
                        str(body.get("profile_id", "study")),
                        int(body["duration"]),
                        [str(target) for target in targets],
                    ),
                    201,
                )
            if self.path == "/api/focus/schedule":
                targets = body.get("targets", ["windows", "phone"])
                if not isinstance(targets, list):
                    raise ValueError("targets must be a list")
                return self._json(self.service.create_schedule(
                    str(body.get("profile_id", "study")), int(body["duration"]),
                    [str(target) for target in targets], str(body["starts_at"]),
                ), 201)
            if self.path == "/api/focus/continuous":
                targets = body.get("targets", ["windows", "phone"])
                if not isinstance(targets, list):
                    raise ValueError("targets must be a list")
                return self._json(self.service.create_continuous_focus(
                    str(body.get("profile_id", "study")), int(body["focus_minutes"]),
                    int(body["rest_minutes"]), int(body["rounds"]), [str(target) for target in targets],
                ), 201)
            if self.path == "/api/focus/cancel":
                focus = self.service.db.focus()
                if focus:
                    self.service.db.cancel_focus(focus["id"])
                    self.service.db.cancel_focus_plan_for_session(focus["id"])
                return self._json({"ok": True})
            if self.path == "/api/rewards/advanced-plant":
                species_id = str(body["species_id"])
                if species_id not in self.service.catalog_ids:
                    raise ValueError("未知植物种类")
                return self._json(
                    self.service.db.plant_advanced_from_basic(species_id, self.service.catalog_tiers[species_id]), 201
                )
            match = re.fullmatch(r"/api/rewards/([^/]+)/plant", self.path)
            if match:
                species_id = str(body["species_id"])
                if species_id not in self.service.catalog_ids:
                    raise ValueError("未知植物种类")
                reward_id = unquote(match.group(1))
                return self._json(self.service.db.plant_reward(reward_id, species_id, self.service.catalog_tiers[species_id]), 201)
            return self._json({"error": "not found"}, 404)
        except Exception as exc:
            self._error(exc)

    def _next_action_path(self, upstream_path: str, body: dict[str, Any]) -> None:
        """Forward the two ID-scoped endpoints after validating their exact shape."""
        try:
            status, data, set_cookie = self.service.next_action.request_path(
                upstream_path, body=body, cookie=self.headers.get("Cookie", ""),
                user_agent=self.headers.get("User-Agent", ""),
            )
            self._json(data, status, set_cookie)
        except Exception as exc:
            self._error(exc)

    def _static(self, path: str) -> None:
        relative = "index.html" if path in ("", "/") else path.lstrip("/")
        static_root = (self.service.root / "static").resolve()
        target = (static_root / relative).resolve()
        if static_root not in target.parents and target != static_root:
            self.send_error(404)
            return
        if not target.is_file():
            target = static_root / "index.html"
        body = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type + ("; charset=utf-8" if content_type.startswith("text/") else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)


class GardenHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], service: GardenService):
        super().__init__(address, GardenHandler)
        self.service = service


def start_reconciler(service: GardenService) -> threading.Thread:
    def loop() -> None:
        while True:
            try:
                service.reconcile_focus()
                service.run_due_focus_plan()
            except Exception as exc:
                print("focus reconcile error:", exc)
            time.sleep(2)
    thread = threading.Thread(target=loop, name="focus-reconciler", daemon=True)
    thread.start()
    return thread
