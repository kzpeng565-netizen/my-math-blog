import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from task_sync import acknowledge_mutations, compact_for_next_action, enqueue_mutation
from next_action import build_decision_state


class TaskSyncTests(unittest.TestCase):
    def _snapshot(self, root: Path) -> Path:
        path = root / "context_snapshot.json"
        path.write_text(
            json.dumps(
                {
                    "tasks": {
                        "overdue_tasks": [],
                        "today_tasks": [
                            {
                                "task_id": "^8m2kx7q4",
                                "title": "原任务",
                                "priority": "normal",
                                "scheduled_date": "2026-08-05",
                                "due_date": None,
                                "recurrence": None,
                                "tomatoes_completed": 0,
                                "tomatoes_total": 2,
                                "source_order": 1,
                            }
                        ],
                        "near_term_tasks": [],
                        "later_tasks": [],
                        "recurring_tasks": [],
                        "unassigned_tasks": [
                            {
                                "task_id": "^unassigned1",
                                "title": "待安排任务",
                                "priority": "high",
                                "scheduled_date": None,
                                "due_date": None,
                                "recurrence": None,
                                "tomatoes_completed": None,
                                "tomatoes_total": None,
                                "source_order": 2,
                                "task_source": "collection",
                            }
                        ],
                    }
                }
            ),
            encoding="utf-8",
        )
        return path

    def test_mutations_immediately_change_effective_view_then_ack(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context = self._snapshot(root)
            updated = enqueue_mutation(
                context,
                root,
                {
                    "operation": "update",
                    "task_id": "^8m2kx7q4",
                    "scheduled_date": "2026-08-07",
                },
            )
            self.assertTrue(any(task["task_id"] == "^8m2kx7q4" for group in updated["effective"]["tasks"].values() for task in group))
            created = enqueue_mutation(
                context,
                root,
                {
                    "operation": "create",
                    "task_id": "^2z7q1w8e",
                    "title": "网页新增",
                    "scheduled_date": "2026-08-05",
                    "priority": "high",
                },
            )
            compact = compact_for_next_action(created["effective"])
            self.assertEqual(compact["task_sync"]["pending_mutation_count"], 2)
            self.assertTrue(any(task["title"] == "网页新增" for group in compact["tasks"].values() for task in group))
            ack = acknowledge_mutations(
                context,
                root,
                {
                    "snapshot_sha256": created["effective"]["snapshot_sha256"],
                    "mutation_ids": [
                        item["mutation_id"] for item in created["effective"]["mutations"]
                    ],
                },
            )
            self.assertEqual(ack["acknowledged"], 2)
            self.assertEqual(ack["effective"]["pending_mutation_count"], 0)

    def test_rejects_non_block_ids_and_invalid_dates(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context = self._snapshot(root)
            with self.assertRaises(ValueError):
                enqueue_mutation(context, root, {"operation": "complete", "task_id": "bad"})
            with self.assertRaises(ValueError):
                enqueue_mutation(
                    context,
                    root,
                    {"operation": "update", "task_id": "^8m2kx7q4", "scheduled_date": "tomorrow"},
                )

    def test_rejects_existing_id_and_web_completion_of_recurrence(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context = self._snapshot(root)
            with self.assertRaises(ValueError):
                enqueue_mutation(
                    context,
                    root,
                    {"operation": "create", "task_id": "^8m2kx7q4", "title": "duplicate"},
                )
            snapshot = json.loads(context.read_text(encoding="utf-8"))
            snapshot["tasks"]["today_tasks"][0]["recurrence"] = "every week"
            context.write_text(json.dumps(snapshot), encoding="utf-8")
            with self.assertRaises(ValueError):
                enqueue_mutation(context, root, {"operation": "complete", "task_id": "^8m2kx7q4"})

    def test_unassigned_task_can_be_scheduled_or_deleted(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context = self._snapshot(root)
            initial = compact_for_next_action(enqueue_mutation(
                context, root, {"operation": "update", "task_id": "^unassigned1", "scheduled_date": "2026-08-08"}
            )["effective"])
            self.assertTrue(any(task["task_id"] == "^unassigned1" for group in initial["tasks"].values() for task in group))
            deleted = enqueue_mutation(context, root, {"operation": "delete", "task_id": "^unassigned1"})
            self.assertFalse(any(task["task_id"] == "^unassigned1" for group in deleted["effective"]["tasks"].values() for task in group))

    def test_next_action_receives_effective_tasks_and_explicit_current_time(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            context = self._snapshot(root)
            state = build_decision_state(
                {"timezone": "Asia/Shanghai", "obsidian_context_path": str(context)},
                root,
                now=datetime(2026, 8, 5, 13, 40, tzinfo=ZoneInfo("Asia/Shanghai")),
            )
            self.assertEqual(state["time_context"]["current_timestamp"], "2026-08-05T13:40:00+08:00")
            self.assertEqual(state["obsidian_context"]["tasks"]["today"][0]["task_id"], "^8m2kx7q4")


if __name__ == "__main__":
    unittest.main()
